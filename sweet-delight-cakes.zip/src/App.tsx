/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ShopProvider, useShop } from './context/ShopContext';
import { CartProvider } from './context/CartContext';
import { WishlistProvider } from './context/WishlistContext';
import { AuthProvider } from './context/AuthContext';
import { OrderProvider } from './context/OrderContext';
import { NotificationProvider } from './context/NotificationContext';

// Common Components
import { Header } from './components/common/Header';
import { Footer } from './components/common/Footer';
import { MobileBottomNav } from './components/common/MobileBottomNav';
import { FloatingActions } from './components/common/FloatingActions';
import { SearchModal } from './components/common/SearchModal';
import { ToastContainer } from './components/common/ToastContainer';
import { CartDrawer } from './components/cart/CartDrawer';

// Pages
import { HomePage } from './pages/HomePage';
import { ProductsPage } from './pages/ProductsPage';
import { ProductDetailsPage } from './pages/ProductDetailsPage';
import { CustomCakePage } from './pages/CustomCakePage';
import { PhotoCakePage } from './pages/PhotoCakePage';
import { OffersPage } from './pages/OffersPage';
import { GalleryPage } from './pages/GalleryPage';
import { BlogPage } from './pages/BlogPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { OrderConfirmationPage } from './pages/OrderConfirmationPage';
import { WishlistPage } from './pages/WishlistPage';
import { AccountPage } from './pages/AccountPage';
import { AdminDashboardPage } from './pages/AdminDashboardPage';

function AppContent() {
  const { products } = useShop();

  const [currentTab, setCurrentTab] = useState<string>('home');
  const [selectedProductId, setSelectedProductId] = useState<string>(products[0]?.id || 'cake-001');
  const [selectedOrderId, setSelectedOrderId] = useState<string | undefined>(undefined);
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>(undefined);
  const [selectedOccasion, setSelectedOccasion] = useState<string | undefined>(undefined);
  const [selectedPostId, setSelectedPostId] = useState<string | undefined>(undefined);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // Sync scroll on tab transition
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentTab]);

  const handleNavigate = (tab: string, params?: Record<string, string>) => {
    if (params?.category) {
      setSelectedCategory(params.category);
    } else if (tab === 'cakes' && !params?.category) {
      setSelectedCategory(undefined);
    }

    if (params?.occasion) {
      setSelectedOccasion(params.occasion);
    } else if (tab === 'cakes' && !params?.occasion) {
      setSelectedOccasion(undefined);
    }

    if (params?.productId) {
      setSelectedProductId(params.productId);
    }

    if (params?.orderId) {
      setSelectedOrderId(params.orderId);
    }

    if (params?.postId) {
      setSelectedPostId(params.postId);
    }

    setCurrentTab(tab);
  };

  const handleSelectProduct = (id: string) => {
    setSelectedProductId(id);
    setCurrentTab('cake-details');
  };

  const handleOrderCompleted = (orderId: string) => {
    setSelectedOrderId(orderId);
    setCurrentTab('order-success');
  };

  // Check if active page is admin (which has its own header/footer)
  const isAdminView = currentTab === 'admin';

  return (
    <div className="min-h-screen bg-[#FAF7F2] text-[#2D1B11] flex flex-col font-sans selection:bg-[#F3C488] selection:text-[#361F13]">
      {/* Storefront Header */}
      {!isAdminView && (
        <Header
          currentTab={currentTab}
          onNavigate={handleNavigate}
          onOpenSearch={() => setIsSearchOpen(true)}
        />
      )}

      {/* Main Page Content */}
      <main className="flex-1">
        {currentTab === 'home' && (
          <HomePage
            onNavigate={handleNavigate}
            onSelectProduct={handleSelectProduct}
            onOpenQuickView={(p) => handleSelectProduct(p.id)}
          />
        )}

        {currentTab === 'cakes' && (
          <ProductsPage
            initialCategory={selectedCategory}
            initialOccasion={selectedOccasion}
            onNavigate={handleNavigate}
            onSelectProduct={handleSelectProduct}
          />
        )}

        {currentTab === 'cake-details' && (
          <ProductDetailsPage
            productId={selectedProductId}
            onNavigate={handleNavigate}
            onSelectProduct={handleSelectProduct}
          />
        )}

        {currentTab === 'custom-cake' && (
          <CustomCakePage onNavigate={handleNavigate} />
        )}

        {currentTab === 'photo-cake' && (
          <PhotoCakePage onNavigate={handleNavigate} />
        )}

        {currentTab === 'offers' && (
          <OffersPage onNavigate={handleNavigate} />
        )}

        {currentTab === 'gallery' && (
          <GalleryPage onNavigate={handleNavigate} />
        )}

        {currentTab === 'blog' && (
          <BlogPage initialPostId={selectedPostId} onNavigate={handleNavigate} />
        )}

        {currentTab === 'about' && (
          <AboutPage onNavigate={handleNavigate} />
        )}

        {currentTab === 'contact' && (
          <ContactPage onNavigate={handleNavigate} />
        )}

        {currentTab === 'checkout' && (
          <CheckoutPage
            onNavigate={handleNavigate}
            onOrderCompleted={handleOrderCompleted}
          />
        )}

        {(currentTab === 'track-order' || currentTab === 'order-success') && (
          <OrderConfirmationPage
            orderId={selectedOrderId}
            onNavigate={handleNavigate}
          />
        )}

        {currentTab === 'wishlist' && (
          <WishlistPage
            onNavigate={handleNavigate}
            onSelectProduct={handleSelectProduct}
          />
        )}

        {currentTab === 'account' && (
          <AccountPage
            onNavigate={handleNavigate}
            onSelectOrder={(ordId) => {
              setSelectedOrderId(ordId);
              setCurrentTab('track-order');
            }}
          />
        )}

        {currentTab === 'admin' && (
          <AdminDashboardPage onNavigate={handleNavigate} />
        )}
      </main>

      {/* Storefront Footer */}
      {!isAdminView && <Footer onNavigate={handleNavigate} />}

      {/* Mobile Fixed Bottom Navigation */}
      {!isAdminView && (
        <MobileBottomNav
          currentTab={currentTab}
          onNavigate={handleNavigate}
          onOpenSearch={() => setIsSearchOpen(true)}
        />
      )}

      {/* Floating WhatsApp and Call buttons */}
      {!isAdminView && (
        <FloatingActions
          productContextName={
            currentTab === 'cake-details'
              ? products.find((p) => p.id === selectedProductId)?.name
              : undefined
          }
        />
      )}

      {/* Cart Drawer */}
      <CartDrawer
        onProceedToCheckout={() => handleNavigate('checkout')}
        onContinueShopping={() => handleNavigate('cakes')}
      />

      {/* Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectProduct={handleSelectProduct}
        onSelectCategory={(cat) => {
          setSelectedCategory(cat);
          setCurrentTab('cakes');
        }}
      />

      {/* Global Toast Alerts */}
      <ToastContainer />
    </div>
  );
}

export default function App() {
  return (
    <NotificationProvider>
      <ShopProvider>
        <AuthProvider>
          <CartProvider>
            <WishlistProvider>
              <OrderProvider>
                <AppContent />
              </OrderProvider>
            </WishlistProvider>
          </CartProvider>
        </AuthProvider>
      </ShopProvider>
    </NotificationProvider>
  );
}

import React, { useState } from 'react';
import { useOrder } from '../context/OrderContext';
import { useShop } from '../context/ShopContext';
import { OrderStatus } from '../types';
import { SafeImage } from '../components/common/SafeImage';
import {
  CheckCircle2,
  Clock,
  ChefHat,
  Truck,
  CheckCircle,
  Download,
  Search,
  ArrowRight,
  ShoppingBag,
  MapPin,
  Calendar,
  Phone,
  FileText,
} from 'lucide-react';

interface OrderConfirmationPageProps {
  orderId?: string;
  onNavigate: (tab: string) => void;
}

export const OrderConfirmationPage: React.FC<OrderConfirmationPageProps> = ({
  orderId,
  onNavigate,
}) => {
  const { getOrderById, findOrderBySearch, orders } = useOrder();
  const { settings } = useShop();

  const [lookupQuery, setLookupQuery] = useState(orderId || '');
  const [activeOrder, setActiveOrder] = useState(() => {
    if (orderId) return getOrderById(orderId);
    return orders[0] || null;
  });
  const [lookupError, setLookupError] = useState(false);

  const handleLookup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!lookupQuery.trim()) return;
    const found = findOrderBySearch(lookupQuery.trim());
    if (found) {
      setActiveOrder(found);
      setLookupError(false);
    } else {
      setLookupError(true);
    }
  };

  const statusSteps: { status: OrderStatus; label: string; icon: React.ReactNode }[] = [
    { status: 'Placed', label: 'Order Placed', icon: <CheckCircle className="w-4 h-4" /> },
    { status: 'Confirmed', label: 'Confirmed', icon: <Clock className="w-4 h-4" /> },
    { status: 'Baking', label: 'Baking In Oven', icon: <ChefHat className="w-4 h-4" /> },
    { status: 'Out for Delivery', label: 'Out For Delivery', icon: <Truck className="w-4 h-4" /> },
    { status: 'Delivered', label: 'Delivered', icon: <CheckCircle2 className="w-4 h-4" /> },
  ];

  const getStepIndex = (status: OrderStatus) => {
    return statusSteps.findIndex((s) => s.status === status);
  };

  const currentStepIdx = activeOrder ? getStepIndex(activeOrder.status) : 0;

  const handlePrintInvoice = () => {
    window.print();
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Lookup Bar if customer arrived from Header/Footer "Track Order" */}
      <div className="bg-white p-6 rounded-3xl border border-[#EDE3D6] shadow-xs mb-8">
        <h2 className="font-serif text-lg font-bold text-[#361F13] mb-1">
          Track Your Sweet Delivery
        </h2>
        <p className="text-xs text-[#715848] mb-4">
          Enter your Order ID (e.g. {orders[0]?.id || '#ORD-2025-8492'}) or customer 10-digit mobile number
        </p>

        <form onSubmit={handleLookup} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              placeholder="Search by Order ID or Mobile Number"
              value={lookupQuery}
              onChange={(e) => {
                setLookupQuery(e.target.value);
                setLookupError(false);
              }}
              className="w-full pl-10 pr-3 py-2.5 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
            />
          </div>
          <button
            type="submit"
            className="px-5 py-2.5 bg-[#361F13] hover:bg-[#22120A] text-white text-xs font-semibold rounded-xl transition-colors"
          >
            Track Status
          </button>
        </form>

        {lookupError && (
          <p className="text-xs text-rose-600 mt-2">
            No order found matching &quot;{lookupQuery}&quot;. Please check the number and try again.
          </p>
        )}
      </div>

      {activeOrder ? (
        <div className="bg-white rounded-3xl border border-[#EDE3D6] shadow-lg overflow-hidden">
          {/* Header Banner */}
          <div className="bg-[#FAF7F2] p-6 sm:p-8 border-b border-[#EBE3D7] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-100 text-emerald-800 rounded-full text-xs font-bold mb-2">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Order Confirmed & Received</span>
              </div>
              <h1 className="font-serif text-2xl sm:text-3xl font-bold text-[#361F13]">
                Order {activeOrder.id}
              </h1>
              <p className="text-xs text-stone-500 mt-1">
                Placed on {new Date(activeOrder.createdAt).toLocaleDateString()} at{' '}
                {new Date(activeOrder.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>

            <div className="flex gap-2">
              <button
                onClick={handlePrintInvoice}
                className="px-4 py-2.5 bg-white border border-[#D8C7B4] hover:bg-stone-50 text-[#361F13] text-xs font-semibold rounded-xl flex items-center gap-1.5 shadow-2xs transition-colors"
              >
                <Download className="w-3.5 h-3.5 text-[#8C4E28]" />
                <span>Download Invoice</span>
              </button>
            </div>
          </div>

          {/* Interactive Progress Stepper */}
          <div className="p-6 sm:p-8 border-b border-[#F2EAE0]">
            <h3 className="font-serif text-base font-bold text-[#361F13] mb-6">
              Live Bakery Progress
            </h3>

            <div className="relative">
              {/* Progress Line */}
              <div className="hidden sm:block absolute top-5 left-6 right-6 h-0.5 bg-stone-200 -z-0">
                <div
                  className="h-full bg-emerald-600 transition-all duration-500"
                  style={{ width: `${(currentStepIdx / (statusSteps.length - 1)) * 100}%` }}
                />
              </div>

              {/* Steps */}
              <div className="grid grid-cols-1 sm:grid-cols-5 gap-4 relative z-10">
                {statusSteps.map((step, idx) => {
                  const isDone = idx <= currentStepIdx;
                  const isCurrent = idx === currentStepIdx;

                  return (
                    <div
                      key={step.status}
                      className="flex sm:flex-col items-center gap-3 sm:gap-2 text-left sm:text-center"
                    >
                      <div
                        className={`w-10 h-10 rounded-full flex items-center justify-center transition-all shadow-xs ${
                          isDone
                            ? 'bg-emerald-600 text-white ring-4 ring-emerald-50'
                            : 'bg-stone-100 text-stone-400'
                        } ${isCurrent ? 'ring-4 ring-emerald-200 scale-105' : ''}`}
                      >
                        {step.icon}
                      </div>
                      <div>
                        <span
                          className={`text-xs font-semibold block ${
                            isDone ? 'text-[#361F13]' : 'text-stone-400'
                          }`}
                        >
                          {step.label}
                        </span>
                        {isCurrent && (
                          <span className="text-[10px] text-emerald-700 font-medium">In Progress</span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Details Grid */}
          <div className="p-6 sm:p-8 grid grid-cols-1 md:grid-cols-2 gap-8 border-b border-[#F2EAE0]">
            {/* Delivery Details */}
            <div className="space-y-3 text-xs">
              <h4 className="font-serif text-sm font-bold uppercase tracking-wider text-[#8C4E28]">
                Delivery Details
              </h4>
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-stone-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-[#361F13]">{activeOrder.customer.name}</strong>
                  <p className="text-stone-600">{activeOrder.customer.address}</p>
                  <p className="text-stone-600">
                    {activeOrder.customer.city} - {activeOrder.customer.pincode}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-stone-400 shrink-0" />
                <span className="text-stone-700">{activeOrder.customer.phone}</span>
              </div>

              <div className="flex items-center gap-2.5">
                <Calendar className="w-4 h-4 text-stone-400 shrink-0" />
                <span className="text-stone-700">
                  Scheduled Date: <strong>{activeOrder.deliveryDate}</strong>
                </span>
              </div>

              <div className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-stone-400 shrink-0" />
                <span className="text-stone-700">
                  Slot: <strong>{activeOrder.deliverySlot}</strong>
                </span>
              </div>

              {activeOrder.specialInstructions && (
                <div className="p-2.5 bg-[#FAF7F2] rounded-xl text-stone-600 border border-[#EDE3D6] italic">
                  Note: &quot;{activeOrder.specialInstructions}&quot;
                </div>
              )}
            </div>

            {/* Payment Summary */}
            <div className="space-y-3 text-xs">
              <h4 className="font-serif text-sm font-bold uppercase tracking-wider text-[#8C4E28]">
                Payment Breakdown
              </h4>
              <div className="space-y-1.5 text-stone-600">
                <div className="flex justify-between">
                  <span>Method</span>
                  <span className="font-bold text-[#361F13]">{activeOrder.paymentMethod}</span>
                </div>
                <div className="flex justify-between">
                  <span>Status</span>
                  <span className="font-bold text-emerald-700">{activeOrder.paymentStatus}</span>
                </div>
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>
                    {settings.currencySymbol}
                    {activeOrder.subtotal}
                  </span>
                </div>
                {((activeOrder.discount || activeOrder.discountAmount || 0) > 0) && (
                  <div className="flex justify-between text-emerald-700">
                    <span>Discount</span>
                    <span>
                      -{settings.currencySymbol}
                      {activeOrder.discount || activeOrder.discountAmount}
                    </span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Delivery Fee</span>
                  <span>
                    {activeOrder.deliveryFee === 0
                      ? 'FREE'
                      : `${settings.currencySymbol}${activeOrder.deliveryFee}`}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Taxes (5%)</span>
                  <span>
                    {settings.currencySymbol}
                    {activeOrder.tax}
                  </span>
                </div>
                <div className="flex justify-between pt-2 border-t border-stone-200 text-sm font-bold text-[#361F13]">
                  <span>Grand Total</span>
                  <span className="font-mono">
                    {settings.currencySymbol}
                    {activeOrder.grandTotal}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Ordered Cakes List */}
          <div className="p-6 sm:p-8 space-y-4">
            <h4 className="font-serif text-sm font-bold uppercase tracking-wider text-[#8C4E28]">
              Ordered Cakes ({activeOrder.items.length})
            </h4>

            <div className="space-y-3">
              {activeOrder.items.map((it, idx) => (
                <div
                  key={idx}
                  className="flex gap-4 p-3.5 bg-[#FAF7F2] rounded-2xl border border-[#EDE3D6]"
                >
                  <SafeImage
                    src={it.image}
                    alt={it.name}
                    className="w-16 h-16 rounded-xl object-cover shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h5 className="font-serif text-sm font-bold text-[#361F13]">{it.name}</h5>
                    <div className="flex flex-wrap gap-1 text-[11px] text-[#715848] mt-1">
                      <span>Size: {it.weight}</span>
                      <span>·</span>
                      <span>Flavor: {it.flavor}</span>
                      <span>·</span>
                      <span>{it.eggless ? 'Eggless' : 'With Egg'}</span>
                    </div>
                    {it.customMessage && (
                      <p className="text-[11px] text-[#8C4E28] italic mt-0.5">
                        Piping: &quot;{it.customMessage}&quot;
                      </p>
                    )}
                    {it.selectedAddOns && it.selectedAddOns.length > 0 && (
                      <p className="text-[10px] text-stone-500 mt-0.5">
                        + Addons: {it.selectedAddOns.map((a) => a.name).join(', ')}
                      </p>
                    )}
                  </div>
                  <div className="text-right">
                    <span className="font-mono text-sm font-bold text-[#361F13]">
                      {settings.currencySymbol}
                      {it.totalPrice}
                    </span>
                    <span className="text-[11px] text-stone-400 block">Qty: {it.quantity}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Action CTAs */}
          <div className="p-6 bg-[#FAF7F2] border-t border-[#EDE3D6] flex flex-col sm:flex-row items-center justify-between gap-4">
            <span className="text-xs text-stone-500">
              Need assistance? Call us directly at <strong>{settings.phone}</strong>
            </span>
            <button
              onClick={() => onNavigate('cakes')}
              className="px-6 py-2.5 bg-[#361F13] hover:bg-[#22120A] text-white text-xs font-semibold rounded-xl transition-colors flex items-center gap-1.5"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Continue Shopping</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="text-center py-12">
          <p className="text-stone-500 text-sm">Please search with a valid Order ID to view tracking.</p>
        </div>
      )}
    </div>
  );
};

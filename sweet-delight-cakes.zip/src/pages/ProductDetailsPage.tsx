import React, { useState, useMemo, useEffect } from 'react';
import { useShop } from '../context/ShopContext';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { SafeImage } from '../components/common/SafeImage';
import { Breadcrumbs } from '../components/common/Breadcrumbs';
import { ProductCard } from '../components/products/ProductCard';
import { WeightOption, FlavorOption, CakeAddOn } from '../types';
import { AVAILABLE_ADDONS, WEIGHT_PRICE_MULTIPLIERS } from '../config/shopConfig';
import {
  Heart,
  Star,
  ShoppingBag,
  Truck,
  ShieldCheck,
  Clock,
  Sparkles,
  MessageCircle,
  Share2,
  ZoomIn,
  Check,
  Send,
} from 'lucide-react';

interface ProductDetailsPageProps {
  productId: string;
  onNavigate: (tab: string) => void;
  onSelectProduct: (productId: string) => void;
}

export const ProductDetailsPage: React.FC<ProductDetailsPageProps> = ({
  productId,
  onNavigate,
  onSelectProduct,
}) => {
  const { products, settings, addRecentlyViewed, reviews, addReview } = useShop();
  const { addToCart, openCartDrawer } = useCart();
  const { isInWishlist, toggleWishlist } = useWishlist();

  const product = products.find((p) => p.id === productId) || products[0];

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [selectedWeight, setSelectedWeight] = useState<WeightOption>(product.defaultWeight || '500g');
  const [selectedFlavor, setSelectedFlavor] = useState<FlavorOption>(product.defaultFlavor || 'Chocolate');
  const [isEggless, setIsEggless] = useState<boolean>(product.eggless);
  const [customMessage, setCustomMessage] = useState('');
  const [selectedAddOns, setSelectedAddOns] = useState<CakeAddOn[]>([]);
  const [pincodeInput, setPincodeInput] = useState('');
  const [pincodeStatus, setPincodeStatus] = useState<string | null>(null);
  const [isZoomOpen, setIsZoomOpen] = useState(false);

  // Review Form state
  const [reviewName, setReviewName] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [showReviewSuccess, setShowReviewSuccess] = useState(false);

  // Record recently viewed
  useEffect(() => {
    if (product) {
      addRecentlyViewed(product);
      setSelectedWeight(product.defaultWeight || '500g');
      setSelectedFlavor(product.defaultFlavor || product.flavors[0] || 'Chocolate');
      setIsEggless(product.eggless);
      setActiveImageIndex(0);
      setCustomMessage('');
      setSelectedAddOns([]);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [product?.id]);

  const isLiked = isInWishlist(product.id);

  // Price calculations
  const weightMultiplier = WEIGHT_PRICE_MULTIPLIERS[selectedWeight] || 1;
  const baseDiscountedUnit = Math.round(
    product.basePrice * (1 - (product.discountPercent || 0) / 100)
  );
  const cakePrice = Math.round(baseDiscountedUnit * weightMultiplier);
  const addOnsTotal = selectedAddOns.reduce((sum, a) => sum + a.price, 0);
  const totalItemPrice = cakePrice + addOnsTotal;

  // Recommended products (similar category or flavor)
  const recommended = useMemo(() => {
    return products
      .filter((p) => p.id !== product.id && (p.category === product.category || p.flavors.some((f) => product.flavors.includes(f))))
      .slice(0, 4);
  }, [products, product]);

  const toggleAddOn = (addon: CakeAddOn) => {
    setSelectedAddOns((prev) => {
      const exists = prev.some((a) => a.id === addon.id);
      if (exists) {
        return prev.filter((a) => a.id !== addon.id);
      } else {
        return [...prev, addon];
      }
    });
  };

  const handleAddToCart = () => {
    addToCart({
      productId: product.id,
      name: product.name,
      image: product.images[activeImageIndex] || product.images[0],
      weight: selectedWeight,
      flavor: selectedFlavor,
      eggless: isEggless,
      customMessage: customMessage.trim() || undefined,
      selectedAddOns: selectedAddOns.map((a) => ({ id: a.id, name: a.name, price: a.price })),
      unitPrice: totalItemPrice,
      quantity: 1,
    });
    openCartDrawer();
  };

  const handlePincodeCheck = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pincodeInput.trim()) return;
    const isSupported = settings.supportedPincodes.includes(pincodeInput.trim());
    if (isSupported) {
      setPincodeStatus(`Available! Same-day delivery ready for ${pincodeInput.trim()}.`);
    } else {
      setPincodeStatus(`Delivery currently unavailable for ${pincodeInput.trim()}.`);
    }
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewName.trim() || !reviewComment.trim()) return;
    addReview({
      customerName: reviewName.trim(),
      rating: reviewRating,
      comment: reviewComment.trim(),
      cakePurchased: product.name,
      verifiedBuyer: true,
    });
    setReviewName('');
    setReviewComment('');
    setShowReviewSuccess(true);
    setTimeout(() => setShowReviewSuccess(false), 4000);
  };

  const whatsappMessage = encodeURIComponent(
    `Hello Sweet Delight Cakes! I am interested in ordering: ${product.name} (${selectedWeight}, ${selectedFlavor}). Is it available today?`
  );
  const whatsappUrl = `https://wa.me/${settings.whatsapp.replace(/[^0-9]/g, '')}?text=${whatsappMessage}`;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Breadcrumbs */}
      <Breadcrumbs
        items={[
          { label: 'Cakes', tab: 'cakes' },
          { label: product.category, tab: 'cakes' },
          { label: product.name, active: true },
        ]}
        onNavigate={onNavigate}
      />

      {/* Main PDP Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        {/* Left Column: Image Gallery (5 cols) */}
        <div className="lg:col-span-6 space-y-4">
          {/* Main Visual */}
          <div className="relative aspect-square rounded-3xl overflow-hidden bg-white border border-[#EDE3D6] shadow-sm group">
            <SafeImage
              src={product.images[activeImageIndex] || product.images[0]}
              alt={product.name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />

            {/* Zoom / Lightbox Trigger */}
            <button
              onClick={() => setIsZoomOpen(true)}
              className="absolute top-4 right-4 p-2.5 rounded-full bg-white/80 hover:bg-white text-stone-700 shadow-md backdrop-blur-xs transition-colors"
              aria-label="Zoom image"
            >
              <ZoomIn className="w-4 h-4" />
            </button>

            {/* Badges */}
            <div className="absolute top-4 left-4 flex flex-col gap-1.5">
              {product.bestseller && (
                <span className="bg-[#361F13] text-[#FAF7F2] text-xs uppercase font-bold tracking-wider px-2.5 py-1 rounded-md shadow-xs">
                  Bestseller
                </span>
              )}
              {product.discountPercent > 0 && (
                <span className="bg-[#C2872A] text-white text-xs font-bold px-2 py-0.5 rounded-md">
                  {product.discountPercent}% OFF
                </span>
              )}
            </div>
          </div>

          {/* Thumbnails */}
          {product.images.length > 1 && (
            <div className="flex gap-3 overflow-x-auto pb-2">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImageIndex(idx)}
                  className={`w-20 h-20 rounded-2xl overflow-hidden border-2 shrink-0 transition-all ${
                    activeImageIndex === idx
                      ? 'border-[#8C4E28] ring-2 ring-[#8C4E28]/20 scale-102'
                      : 'border-transparent opacity-75 hover:opacity-100'
                  }`}
                >
                  <SafeImage src={img} alt={`Thumbnail ${idx + 1}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}

          {/* Bakery Guarantee Card */}
          <div className="p-4 rounded-2xl bg-white border border-[#EDE3D6] shadow-2xs space-y-2.5 text-xs text-[#523B2D]">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#8C4E28] shrink-0" />
              <span>
                <strong>Same-Day Delivery:</strong> Available across Pune if placed before 2:00 PM.
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-emerald-700 shrink-0" />
              <span>
                <strong>FREE Shipping:</strong> On orders above ₹{settings.freeDeliveryThreshold}.
              </span>
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#8C4E28] shrink-0" />
              <span>
                <strong>100% Freshness Guarantee:</strong> Chilled transit packaging to prevent heat damage.
              </span>
            </div>
          </div>
        </div>

        {/* Right Column: Contiguous Purchase Module (6 cols) */}
        <div className="lg:col-span-6 space-y-6">
          <div>
            {/* Category & Wishlist */}
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-[#8C4E28]">
                {product.category}
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => toggleWishlist(product)}
                  className={`p-2 rounded-xl border transition-colors ${
                    isLiked
                      ? 'bg-rose-50 border-rose-200 text-rose-600'
                      : 'bg-white border-stone-200 text-stone-600 hover:text-rose-600'
                  }`}
                  aria-label="Wishlist"
                >
                  <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
                </button>

                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="p-2 rounded-xl border border-stone-200 bg-white text-emerald-700 hover:bg-emerald-50 transition-colors"
                  title="Ask on WhatsApp"
                >
                  <MessageCircle className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Product Title */}
            <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#361F13] mt-2">
              {product.name}
            </h1>

            {/* Rating & Reviews */}
            <div className="flex items-center gap-2 mt-2 text-xs text-stone-500">
              <div className="flex items-center gap-1 text-amber-500 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                <Star className="w-3.5 h-3.5 fill-current" />
                <span className="font-bold text-stone-900">{product.rating.toFixed(1)}</span>
              </div>
              <span>·</span>
              <span>{product.reviewCount} customer reviews</span>
              <span>·</span>
              <span className="text-emerald-700 font-semibold">In Stock ({product.stock} available)</span>
            </div>

            {/* Price Box */}
            <div className="mt-4 p-4 rounded-2xl bg-white border border-[#E9DFD3] flex items-baseline justify-between shadow-2xs">
              <div>
                <span className="text-xs text-stone-400 block mb-0.5">Price for {selectedWeight}:</span>
                <div className="flex items-baseline gap-2">
                  <span className="font-mono text-3xl font-bold text-[#361F13]">
                    {settings.currencySymbol}
                    {totalItemPrice}
                  </span>
                  {product.discountPercent > 0 && (
                    <span className="text-sm text-stone-400 line-through font-mono">
                      {settings.currencySymbol}
                      {Math.round(product.basePrice * weightMultiplier)}
                    </span>
                  )}
                  {addOnsTotal > 0 && (
                    <span className="text-xs text-[#8C4E28] font-semibold">
                      (Includes +{settings.currencySymbol}{addOnsTotal} add-ons)
                    </span>
                  )}
                </div>
              </div>
              <span className="text-xs text-stone-500">Taxes calculated at checkout</span>
            </div>

            <p className="text-xs sm:text-sm text-[#715848] mt-4 leading-relaxed">
              {product.description}
            </p>
          </div>

          {/* Customization 1: Cake Weight */}
          <div className="space-y-2 pt-2 border-t border-[#EBE3D7]">
            <div className="flex justify-between items-center">
              <label className="text-xs font-bold uppercase tracking-wider text-[#361F13]">
                1. Select Cake Size / Weight:
              </label>
              <span className="text-xs text-[#8C4E28] font-semibold">
                Serving: {selectedWeight === '500g' ? '4-6 guests' : selectedWeight === '1kg' ? '8-12 guests' : '15+ guests'}
              </span>
            </div>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {product.weights.map((wt) => {
                const mult = WEIGHT_PRICE_MULTIPLIERS[wt] || 1;
                const priceForWt = Math.round(baseDiscountedUnit * mult);
                return (
                  <button
                    key={wt}
                    onClick={() => setSelectedWeight(wt)}
                    className={`py-2 px-1 rounded-xl text-xs font-semibold border flex flex-col items-center gap-0.5 transition-all ${
                      selectedWeight === wt
                        ? 'bg-[#361F13] text-white border-[#361F13] shadow-xs'
                        : 'bg-white text-stone-700 border-stone-200 hover:border-stone-400'
                    }`}
                  >
                    <span>{wt}</span>
                    <span className={`text-[10px] font-mono ${selectedWeight === wt ? 'text-[#F3C488]' : 'text-stone-500'}`}>
                      {settings.currencySymbol}{priceForWt}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Customization 2: Flavor */}
          <div className="space-y-2 pt-2 border-t border-[#EBE3D7]">
            <label className="text-xs font-bold uppercase tracking-wider text-[#361F13] block">
              2. Choose Sponge / Frosting Flavor:
            </label>
            <div className="flex flex-wrap gap-2">
              {product.flavors.map((flv) => (
                <button
                  key={flv}
                  onClick={() => setSelectedFlavor(flv)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-medium border transition-colors ${
                    selectedFlavor === flv
                      ? 'bg-[#8C4E28] text-white border-[#8C4E28] shadow-xs'
                      : 'bg-white text-stone-700 border-stone-200 hover:border-stone-400'
                  }`}
                >
                  {flv}
                </button>
              ))}
            </div>
          </div>

          {/* Customization 3: Dietary (Egg / Eggless) */}
          <div className="space-y-2 pt-2 border-t border-[#EBE3D7]">
            <label className="text-xs font-bold uppercase tracking-wider text-[#361F13] block">
              3. Preparation Preference:
            </label>
            <div className="grid grid-cols-2 gap-3 max-w-sm">
              <button
                onClick={() => setIsEggless(true)}
                className={`py-2 px-3 rounded-xl text-xs font-semibold border flex items-center justify-center gap-2 transition-all ${
                  isEggless
                    ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                    : 'bg-white text-stone-700 border-stone-200 hover:border-stone-400'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                <span>100% Eggless (Vegetarian)</span>
              </button>

              <button
                onClick={() => setIsEggless(false)}
                className={`py-2 px-3 rounded-xl text-xs font-semibold border flex items-center justify-center gap-2 transition-all ${
                  !isEggless
                    ? 'bg-amber-800 text-white border-amber-800 shadow-xs'
                    : 'bg-white text-stone-700 border-stone-200 hover:border-stone-400'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                <span>Regular (Contains Egg)</span>
              </button>
            </div>
          </div>

          {/* Customization 4: Message on Cake */}
          <div className="space-y-2 pt-2 border-t border-[#EBE3D7]">
            <div className="flex justify-between items-center">
              <label htmlFor="cake-message" className="text-xs font-bold uppercase tracking-wider text-[#361F13]">
                4. Custom Message On Cake (Free):
              </label>
              <span className="text-[11px] text-stone-400">{customMessage.length} / 35 chars</span>
            </div>
            <input
              id="cake-message"
              type="text"
              maxLength={35}
              placeholder="e.g. Happy Birthday Rahul!"
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-white border border-[#E2D5C7] rounded-xl text-xs text-[#2D1B11] placeholder-stone-400 focus:outline-hidden focus:border-[#8C4E28]"
            />
          </div>

          {/* Customization 5: Add-ons */}
          <div className="space-y-2.5 pt-2 border-t border-[#EBE3D7]">
            <label className="text-xs font-bold uppercase tracking-wider text-[#361F13] block">
              5. Celebration Add-ons (Optional):
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {AVAILABLE_ADDONS.map((addon) => {
                const isSelected = selectedAddOns.some((a) => a.id === addon.id);
                return (
                  <button
                    key={addon.id}
                    onClick={() => toggleAddOn(addon)}
                    className={`p-2.5 rounded-xl border text-left flex items-center justify-between text-xs transition-all ${
                      isSelected
                        ? 'bg-[#FAF0E6] border-[#8C4E28] text-[#361F13]'
                        : 'bg-white border-stone-200 text-stone-700 hover:border-stone-300'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <div
                        className={`w-4 h-4 rounded-md border flex items-center justify-center shrink-0 ${
                          isSelected ? 'bg-[#8C4E28] border-[#8C4E28] text-white' : 'border-stone-300'
                        }`}
                      >
                        {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                      </div>
                      <span className="truncate max-w-[150px]">{addon.name}</span>
                    </div>
                    <span className="font-mono font-semibold text-[#8C4E28]">
                      +{settings.currencySymbol}
                      {addon.price}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quick Pincode Availability Form */}
          <div className="pt-2 border-t border-[#EBE3D7]">
            <form onSubmit={handlePincodeCheck} className="flex gap-2 max-w-sm">
              <input
                type="text"
                maxLength={6}
                placeholder="Pincode check (e.g. 411014)"
                value={pincodeInput}
                onChange={(e) => {
                  setPincodeInput(e.target.value.replace(/[^0-9]/g, ''));
                  setPincodeStatus(null);
                }}
                className="flex-1 px-3 py-2 bg-white border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
              />
              <button
                type="submit"
                className="px-3.5 py-2 bg-[#361F13] text-white text-xs font-semibold rounded-xl"
              >
                Check
              </button>
            </form>
            {pincodeStatus && (
              <p className="text-xs text-[#8C4E28] font-medium mt-1.5">{pincodeStatus}</p>
            )}
          </div>

          {/* Primary Buy CTA */}
          <div className="pt-4 flex flex-col sm:flex-row gap-3">
            <button
              onClick={handleAddToCart}
              className="flex-1 py-4 bg-[#361F13] hover:bg-[#22120A] text-white text-sm font-semibold rounded-2xl shadow-xl flex items-center justify-center gap-2 transition-all group"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>
                Add to Cart • {settings.currencySymbol}
                {totalItemPrice}
              </span>
            </button>

            <a
              href={whatsappUrl}
              target="_blank"
              rel="noreferrer"
              className="py-4 px-6 bg-[#25D366] hover:bg-[#20BA5A] text-white text-sm font-semibold rounded-2xl flex items-center justify-center gap-2 shadow-md transition-all shrink-0"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Enquire on WhatsApp</span>
            </a>
          </div>
        </div>
      </div>

      {/* Customer Reviews Section */}
      <section className="mt-16 pt-12 border-t border-[#EDE3D6]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-[#8C4E28]">
              Verified Feedback
            </span>
            <h3 className="font-serif text-2xl font-bold text-[#361F13]">Customer Reviews for this Cake</h3>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-amber-600 font-bold bg-amber-50 px-3 py-1.5 rounded-xl border border-amber-200">
            <Star className="w-4 h-4 fill-current text-amber-500" />
            <span>{product.rating} / 5 Rating</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Review List (8 cols) */}
          <div className="lg:col-span-8 space-y-4">
            {reviews.slice(0, 3).map((r) => (
              <div key={r.id} className="p-5 rounded-2xl bg-white border border-[#EDE3D6] shadow-2xs">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex text-amber-500">
                    {[...Array(r.rating)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-current" />
                    ))}
                  </div>
                  <span className="text-[11px] text-stone-400">{r.date}</span>
                </div>
                <p className="text-xs sm:text-sm text-[#4A3225] leading-relaxed italic">
                  &quot;{r.comment}&quot;
                </p>
                <div className="mt-3 flex items-center justify-between text-xs">
                  <span className="font-bold text-[#361F13]">{r.customerName}</span>
                  <span className="text-[11px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    Verified Buyer
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Add a Review Form (4 cols) */}
          <div className="lg:col-span-4 bg-white p-6 rounded-2xl border border-[#EDE3D6] shadow-2xs">
            <h4 className="font-serif text-lg font-bold text-[#361F13] mb-1">Leave a Review</h4>
            <p className="text-xs text-[#715848] mb-4">Share your taste experience with other cake lovers.</p>

            {showReviewSuccess ? (
              <div className="p-4 bg-emerald-50 text-emerald-800 rounded-xl text-xs border border-emerald-200 text-center">
                Thank you! Your review has been added. 🍰
              </div>
            ) : (
              <form onSubmit={handleReviewSubmit} className="space-y-3">
                <div>
                  <label htmlFor="review-name" className="text-xs font-semibold text-[#361F13] block mb-1">Your Name</label>
                  <input
                    id="review-name"
                    type="text"
                    required
                    placeholder="e.g. Priya M."
                    value={reviewName}
                    onChange={(e) => setReviewName(e.target.value)}
                    className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-[#361F13] block mb-1">Rating</label>
                  <div className="flex gap-1.5">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <button
                        type="button"
                        key={s}
                        onClick={() => setReviewRating(s)}
                        className="p-1 text-amber-500 hover:scale-110 transition-transform"
                      >
                        <Star className={`w-5 h-5 ${s <= reviewRating ? 'fill-current' : 'text-stone-300'}`} />
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label htmlFor="review-comments" className="text-xs font-semibold text-[#361F13] block mb-1">Comments</label>
                  <textarea
                    id="review-comments"
                    rows={3}
                    required
                    placeholder="How was the sponge freshness, flavor balance, and presentation?"
                    value={reviewComment}
                    onChange={(e) => setReviewComment(e.target.value)}
                    className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-[#361F13] text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Submit Review</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* Recommended Cakes ("You May Also Like" - Item #53) */}
      {recommended.length > 0 && (
        <section className="mt-16 pt-12 border-t border-[#EDE3D6]">
          <div className="flex items-center justify-between mb-8">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-[#8C4E28]">
                Handpicked Pairing
              </span>
              <h3 className="font-serif text-2xl font-bold text-[#361F13]">You May Also Like</h3>
            </div>
            <button
              onClick={() => onNavigate('cakes')}
              className="text-xs font-semibold text-[#8C4E28] hover:underline"
            >
              View More
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {recommended.map((cake) => (
              <ProductCard
                key={cake.id}
                product={cake}
                onOpenDetails={onSelectProduct}
              />
            ))}
          </div>
        </section>
      )}

      {/* Lightbox / Zoom Modal */}
      {isZoomOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in"
          onClick={() => setIsZoomOpen(false)}
        >
          <div className="relative max-w-4xl max-h-[90vh]">
            <SafeImage
              src={product.images[activeImageIndex] || product.images[0]}
              alt={product.name}
              className="max-h-[85vh] rounded-2xl object-contain shadow-2xl"
            />
            <button
              onClick={() => setIsZoomOpen(false)}
              className="absolute top-4 right-4 bg-white/20 text-white hover:bg-white hover:text-black p-2 rounded-full transition-colors"
            >
              ✕
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

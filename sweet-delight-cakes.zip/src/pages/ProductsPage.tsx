import React, { useState, useMemo } from 'react';
import { useShop } from '../context/ShopContext';
import { ProductCard } from '../components/products/ProductCard';
import { QuickViewModal } from '../components/products/QuickViewModal';
import { FilterSidebar, FilterState } from '../components/products/FilterSidebar';
import { Breadcrumbs } from '../components/common/Breadcrumbs';
import { Product } from '../types';
import { SlidersHorizontal, ArrowUpDown, Cake, RotateCcw } from 'lucide-react';

interface ProductsPageProps {
  initialCategory?: string;
  initialOccasion?: string;
  onNavigate: (tab: string) => void;
  onSelectProduct: (productId: string) => void;
}

type SortOption = 'popularity' | 'price-asc' | 'price-desc' | 'rating' | 'newest' | 'discount';

export const ProductsPage: React.FC<ProductsPageProps> = ({
  initialCategory,
  initialOccasion,
  onNavigate,
  onSelectProduct,
}) => {
  const { products } = useShop();

  const [filters, setFilters] = useState<FilterState>({
    category: initialCategory || 'all',
    flavor: 'all',
    dietary: 'all',
    priceRange: 'all',
    minRating: 0,
    weight: 'all',
  });

  const [sortBy, setSortBy] = useState<SortOption>('popularity');
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);

  // Extract unique categories & flavors
  const categoriesList = useMemo(() => {
    return Array.from(new Set(products.map((p) => p.category)));
  }, [products]);

  const flavorsList = useMemo(() => {
    const flvs = new Set<string>();
    products.forEach((p) => p.flavors.forEach((f) => flvs.add(f)));
    return Array.from(flvs);
  }, [products]);

  const handleFilterChange = (updated: Partial<FilterState>) => {
    setFilters((prev) => ({ ...prev, ...updated }));
  };

  const handleClearFilters = () => {
    setFilters({
      category: 'all',
      flavor: 'all',
      dietary: 'all',
      priceRange: 'all',
      minRating: 0,
      weight: 'all',
    });
  };

  // Filtered & Sorted cakes
  const filteredProducts = useMemo(() => {
    return products.filter((cake) => {
      // Category filter
      if (filters.category !== 'all' && cake.category.toLowerCase() !== filters.category.toLowerCase()) {
        return false;
      }
      // Occasion filter if passed
      if (initialOccasion && cake.occasion && !cake.occasion.some((o) => o.toLowerCase().includes(initialOccasion.toLowerCase()))) {
        return false;
      }
      // Flavor filter
      if (filters.flavor !== 'all' && !cake.flavors.some((f) => f.toLowerCase() === filters.flavor.toLowerCase())) {
        return false;
      }
      // Dietary filter
      if (filters.dietary === 'eggless' && !cake.eggless) return false;
      if (filters.dietary === 'egg' && cake.eggless) return false;

      // Price range
      if (filters.priceRange === 'under500' && cake.basePrice >= 500) return false;
      if (filters.priceRange === '500-750' && (cake.basePrice < 500 || cake.basePrice > 750)) return false;
      if (filters.priceRange === '750-1000' && (cake.basePrice < 750 || cake.basePrice > 1000)) return false;
      if (filters.priceRange === 'above1000' && cake.basePrice <= 1000) return false;

      // Rating
      if (filters.minRating > 0 && cake.rating < filters.minRating) return false;

      // Weight
      if (filters.weight !== 'all' && !cake.weights.includes(filters.weight as any)) return false;

      return true;
    }).sort((a, b) => {
      const discountedA = a.basePrice * (1 - a.discountPercent / 100);
      const discountedB = b.basePrice * (1 - b.discountPercent / 100);

      switch (sortBy) {
        case 'price-asc':
          return discountedA - discountedB;
        case 'price-desc':
          return discountedB - discountedA;
        case 'rating':
          return b.rating - a.rating;
        case 'discount':
          return b.discountPercent - a.discountPercent;
        case 'newest':
          return (b.newArrival ? 1 : 0) - (a.newArrival ? 1 : 0);
        case 'popularity':
        default:
          return (b.bestseller ? 1 : 0) - (a.bestseller ? 1 : 0) || b.reviewCount - a.reviewCount;
      }
    });
  }, [products, filters, initialOccasion, sortBy]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Breadcrumbs */}
      <Breadcrumbs
        items={[
          { label: 'Cakes', tab: 'cakes' },
          filters.category !== 'all'
            ? { label: filters.category, active: true }
            : { label: 'All Catalog', active: true },
        ]}
        onNavigate={onNavigate}
      />

      {/* Page Title & Mobile Filter Trigger */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="font-serif text-3xl font-bold text-[#361F13]">
            {filters.category !== 'all'
              ? filters.category
              : initialOccasion
              ? `${initialOccasion} Cakes`
              : 'Our Complete Cake Catalog'}
          </h1>
          <p className="text-xs text-[#715848] mt-1">
            Showing <strong className="text-[#361F13]">{filteredProducts.length}</strong> freshly baked artisan cakes
          </p>
        </div>

        {/* Sorting & Filter toggle for mobile */}
        <div className="flex items-center gap-2 self-end sm:self-auto">
          {/* Mobile Filter Button */}
          <button
            onClick={() => setIsMobileFilterOpen(true)}
            className="lg:hidden px-3.5 py-2 bg-white border border-[#E2D5C7] rounded-xl text-xs font-semibold text-[#361F13] flex items-center gap-1.5 shadow-2xs"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-[#8C4E28]" />
            <span>Filters</span>
          </button>

          {/* Sort Dropdown */}
          <div className="flex items-center gap-2 bg-white border border-[#E2D5C7] px-3 py-2 rounded-xl text-xs shadow-2xs">
            <ArrowUpDown className="w-3.5 h-3.5 text-[#8C4E28] shrink-0" />
            <label htmlFor="sort-select" className="text-stone-500 font-medium">Sort:</label>
            <select
              id="sort-select"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              className="bg-transparent font-semibold text-[#361F13] focus:outline-hidden cursor-pointer"
            >
              <option value="popularity">Popularity</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Top Rated</option>
              <option value="newest">New Arrivals</option>
              <option value="discount">Highest Discount</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Layout: Sidebar Left, Products Right */}
      <div className="flex gap-8 items-start">
        {/* Desktop Filter Sidebar */}
        <div className="hidden lg:block">
          <FilterSidebar
            filters={filters}
            onChange={handleFilterChange}
            onClear={handleClearFilters}
            categoriesList={categoriesList}
            flavorsList={flavorsList}
          />
        </div>

        {/* Mobile Filter Drawer */}
        {isMobileFilterOpen && (
          <FilterSidebar
            filters={filters}
            onChange={handleFilterChange}
            onClear={handleClearFilters}
            categoriesList={categoriesList}
            flavorsList={flavorsList}
            isMobileDrawer
            onCloseMobileDrawer={() => setIsMobileFilterOpen(false)}
          />
        )}

        {/* Products Grid */}
        <div className="flex-1">
          {filteredProducts.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-[#EDE3D6] my-6">
              <div className="w-16 h-16 rounded-full bg-[#FAF7F2] text-[#8C4E28] mx-auto flex items-center justify-center mb-4">
                <Cake className="w-8 h-8 stroke-[1.5]" />
              </div>
              <h3 className="font-serif text-xl font-bold text-[#361F13]">No cakes match your filters</h3>
              <p className="text-xs text-[#715848] max-w-sm mx-auto mt-2 leading-relaxed">
                Try widening your price range, clearing flavor filters, or exploring our full catalog.
              </p>
              <button
                onClick={handleClearFilters}
                className="mt-6 px-5 py-2.5 bg-[#361F13] text-white text-xs font-semibold rounded-xl hover:bg-[#22120A] transition-colors inline-flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset All Filters</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
              {filteredProducts.map((cake) => (
                <ProductCard
                  key={cake.id}
                  product={cake}
                  onOpenDetails={onSelectProduct}
                  onOpenQuickView={(prod) => setQuickViewProduct(prod)}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Quick View Modal */}
      <QuickViewModal
        product={quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
        onViewFullDetails={(id) => {
          setQuickViewProduct(null);
          onSelectProduct(id);
        }}
      />
    </div>
  );
};

import React from 'react';
import { useWishlist } from '../context/WishlistContext';
import { useCart } from '../context/CartContext';
import { useShop } from '../context/ShopContext';
import { ProductCard } from '../components/products/ProductCard';
import { Breadcrumbs } from '../components/common/Breadcrumbs';
import { Heart, ShoppingBag, ArrowRight } from 'lucide-react';

interface WishlistPageProps {
  onNavigate: (tab: string) => void;
  onSelectProduct: (productId: string) => void;
}

export const WishlistPage: React.FC<WishlistPageProps> = ({
  onNavigate,
  onSelectProduct,
}) => {
  const { wishlistItems, clearWishlist } = useWishlist();
  const { settings } = useShop();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <Breadcrumbs
        items={[
          { label: 'Cakes', tab: 'cakes' },
          { label: 'My Wishlist', active: true },
        ]}
        onNavigate={onNavigate}
      />

      <div className="flex items-center justify-between mb-8 pb-4 border-b border-[#EDE3D6]">
        <div>
          <h1 className="font-serif text-3xl font-bold text-[#361F13]">Saved Cakes</h1>
          <p className="text-xs text-[#715848] mt-1">
            {wishlistItems.length} {wishlistItems.length === 1 ? 'cake' : 'cakes'} saved for upcoming celebrations
          </p>
        </div>

        {wishlistItems.length > 0 && (
          <button
            onClick={clearWishlist}
            className="text-xs font-semibold text-rose-600 hover:text-rose-800 transition-colors"
          >
            Clear Wishlist
          </button>
        )}
      </div>

      {wishlistItems.length === 0 ? (
        <div className="bg-white rounded-3xl p-16 text-center border border-[#EDE3D6] max-w-lg mx-auto my-8">
          <div className="w-16 h-16 rounded-full bg-[#FAF7F2] text-[#8C4E28] mx-auto flex items-center justify-center mb-4">
            <Heart className="w-8 h-8 stroke-[1.5]" />
          </div>
          <h2 className="font-serif text-xl font-bold text-[#361F13]">Your wishlist is empty</h2>
          <p className="text-xs text-[#715848] mt-2 leading-relaxed">
            Tap the heart icon on any cake to save it here for birthdays, anniversaries, or future surprise parties!
          </p>
          <button
            onClick={() => onNavigate('cakes')}
            className="mt-6 px-6 py-3 bg-[#361F13] text-white text-xs font-semibold rounded-xl hover:bg-[#22120A] transition-colors inline-flex items-center gap-2"
          >
            <span>Explore Delicious Cakes</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {wishlistItems.map((cake) => (
            <ProductCard
              key={cake.id}
              product={cake}
              onOpenDetails={onSelectProduct}
            />
          ))}
        </div>
      )}
    </div>
  );
};

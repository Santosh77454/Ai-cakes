import React, { useState } from 'react';
import { Breadcrumbs } from '../components/common/Breadcrumbs';
import { useShop } from '../context/ShopContext';
import { useNotification } from '../context/NotificationContext';
import { Phone, Mail, MapPin, Clock, MessageCircle, Send, CheckCircle2 } from 'lucide-react';

interface ContactPageProps {
  onNavigate: (tab: string) => void;
}

export const ContactPage: React.FC<ContactPageProps> = ({ onNavigate }) => {
  const { settings } = useShop();
  const { showToast } = useNotification();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [subject, setSubject] = useState('Custom Cake Consultation');
  const [message, setMessage] = useState('');
  const [isSent, setIsSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || !message.trim()) return;
    setIsSent(true);
    showToast('Thank you! Our head baker will contact you shortly.', 'success');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-12">
      <Breadcrumbs
        items={[
          { label: 'Home', tab: 'home' },
          { label: 'Contact Us', active: true },
        ]}
        onNavigate={onNavigate}
      />

      <div className="text-center max-w-xl mx-auto">
        <span className="text-xs font-bold uppercase tracking-wider text-[#8C4E28] block mb-1">
          We&apos;re Here To Help
        </span>
        <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#361F13]">
          Get in Touch With Our Bakery
        </h1>
        <p className="text-xs sm:text-sm text-[#715848] mt-2">
          Planning a wedding cake tasting, corporate bulk order, or urgent custom creation? Reach out directly.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        {/* Contact Info (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-[#EDE3D6] shadow-xs space-y-6">
            <h3 className="font-serif text-xl font-bold text-[#361F13]">Bakery Headquarters</h3>

            <div className="space-y-4 text-xs text-[#523B2D]">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#FAF0E6] text-[#8C4E28] flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <strong className="block text-[#361F13] text-sm">Store Location</strong>
                  <p className="mt-0.5 leading-relaxed">{settings.address}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#FAF0E6] text-[#8C4E28] flex items-center justify-center shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <strong className="block text-[#361F13] text-sm">Phone Support</strong>
                  <a href={`tel:${settings.phone}`} className="mt-0.5 block hover:text-[#8C4E28]">
                    {settings.phone}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#FAF0E6] text-[#8C4E28] flex items-center justify-center shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <strong className="block text-[#361F13] text-sm">Email Inquiries</strong>
                  <a href={`mailto:${settings.email}`} className="mt-0.5 block hover:text-[#8C4E28]">
                    {settings.email}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#FAF0E6] text-[#8C4E28] flex items-center justify-center shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <strong className="block text-[#361F13] text-sm">Bakery & Delivery Hours</strong>
                  <p className="mt-0.5">Monday – Saturday: 9:00 AM – 10:00 PM</p>
                  <p>Sunday: 10:00 AM – 10:00 PM</p>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-[#F2EAE0]">
              <a
                href={`https://wa.me/${settings.whatsapp.replace(/[^0-9]/g, '')}`}
                target="_blank"
                rel="noreferrer"
                className="w-full py-3 bg-[#25D366] hover:bg-[#20BA5A] text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 shadow-md transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Chat Instantly on WhatsApp</span>
              </a>
            </div>
          </div>
        </div>

        {/* Contact Form (7 cols) */}
        <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-[#EDE3D6] shadow-xs">
          <h3 className="font-serif text-xl font-bold text-[#361F13] mb-1">Send Us a Message</h3>
          <p className="text-xs text-stone-500 mb-6">
            We respond to all online inquiries within 30 minutes during shop hours.
          </p>

          {isSent ? (
            <div className="p-8 text-center bg-emerald-50 rounded-2xl border border-emerald-200 space-y-3">
              <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
              <h4 className="font-serif text-lg font-bold text-emerald-900">Message Received!</h4>
              <p className="text-xs text-emerald-700">
                Thank you, {name}! Our customer coordinator will call you back shortly on {phone}.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="contact-name" className="text-xs font-semibold text-[#361F13] block mb-1">Your Name *</label>
                  <input
                    id="contact-name"
                    type="text"
                    required
                    placeholder="e.g. Rahul Patil"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
                  />
                </div>

                <div>
                  <label htmlFor="contact-phone" className="text-xs font-semibold text-[#361F13] block mb-1">Mobile Phone *</label>
                  <input
                    id="contact-phone"
                    type="tel"
                    required
                    placeholder="10-digit number"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="contact-email" className="text-xs font-semibold text-[#361F13] block mb-1">Email Address</label>
                <input
                  id="contact-email"
                  type="email"
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-[#361F13] block mb-1">Subject</label>
                <select
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
                >
                  <option value="Custom Cake Consultation">Custom Cake Consultation</option>
                  <option value="Wedding Cake Tasting">Wedding Cake Tasting & Appointment</option>
                  <option value="Corporate Bulk Order">Corporate Bulk Order</option>
                  <option value="Delivery Status Inquiry">Delivery Status Inquiry</option>
                  <option value="Other Feedback">Other Feedback</option>
                </select>
              </div>

              <div>
                <label htmlFor="contact-message" className="text-xs font-semibold text-[#361F13] block mb-1">
                  Message / Cake Requirements *
                </label>
                <textarea
                  id="contact-message"
                  rows={4}
                  required
                  placeholder="Tell us about your event date, expected guest count, preferred flavor, or any dietary allergies..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
                ></textarea>
              </div>

              <button
                type="submit"
                className="px-6 py-3 bg-[#361F13] hover:bg-[#22120A] text-white text-xs font-semibold rounded-xl flex items-center gap-2 transition-colors shadow-md"
              >
                <Send className="w-4 h-4" />
                <span>Send Message</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

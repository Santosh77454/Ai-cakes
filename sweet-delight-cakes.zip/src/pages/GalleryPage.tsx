import React, { useState } from 'react';
import { Breadcrumbs } from '../components/common/Breadcrumbs';
import { SafeImage } from '../components/common/SafeImage';
import { X, ZoomIn } from 'lucide-react';

interface GalleryPageProps {
  onNavigate: (tab: string) => void;
}

interface GalleryItem {
  id: string;
  title: string;
  category: string;
  image: string;
  description: string;
}

export const GalleryPage: React.FC<GalleryPageProps> = ({ onNavigate }) => {
  const [activeFilter, setActiveFilter] = useState('All');
  const [selectedImage, setSelectedImage] = useState<GalleryItem | null>(null);

  const galleryItems: GalleryItem[] = [
    {
      id: 'g-1',
      title: 'Four-Tier Vintage Rose Wedding Cake',
      category: 'Wedding',
      image: 'https://images.unsplash.com/photo-1535141192574-5d4897c13136?auto=format&fit=crop&w=800&q=80',
      description: 'Crafted with hand-piped Swiss meringue buttercream and fresh botanical roses.',
    },
    {
      id: 'g-2',
      title: 'Dark Chocolate Truffle Celebration Cake',
      category: 'Birthday',
      image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80',
      description: 'Layered with 70% dark Belgian ganache and chocolate curls.',
    },
    {
      id: 'g-3',
      title: 'Princess Castle Fondant Birthday Cake',
      category: 'Kids Cakes',
      image: 'https://images.unsplash.com/photo-1535254973040-607b474cb50d?auto=format&fit=crop&w=800&q=80',
      description: 'Sugar craft castle towers with soft pastel watercolor frosting.',
    },
    {
      id: 'g-4',
      title: 'Golden Drip French Macaron Cake',
      category: 'Designer',
      image: 'https://images.unsplash.com/photo-1565958011703-44f9829ba187?auto=format&fit=crop&w=800&q=80',
      description: 'Gold-leaf decorated vanilla bean cake crowned with pistachio and raspberry macarons.',
    },
    {
      id: 'g-5',
      title: 'Artisan Berry Cupcake Carousel',
      category: 'Cupcakes',
      image: 'https://images.unsplash.com/photo-1587668178277-295251f900ce?auto=format&fit=crop&w=800&q=80',
      description: 'Whipped vanilla bean frosting and fresh organic blueberries.',
    },
    {
      id: 'g-6',
      title: 'Rustic Lambeth Heart Anniversary Cake',
      category: 'Designer',
      image: 'https://images.unsplash.com/photo-1588195538326-c5b1e9f80a1b?auto=format&fit=crop&w=800&q=80',
      description: 'Vintage 1950s Lambeth frills and piped borders with edible glitter.',
    },
    {
      id: 'g-7',
      title: 'Fresh Exotic Mango Gateau',
      category: 'Birthday',
      image: 'https://images.unsplash.com/photo-1562440499-64c9a111f713?auto=format&fit=crop&w=800&q=80',
      description: 'Sweet Alphonso mango pulp layered inside light chiffon sponge.',
    },
    {
      id: 'g-8',
      title: 'Ivory Floral Engagement Cake',
      category: 'Wedding',
      image: 'https://images.unsplash.com/photo-1519869325930-281384150729?auto=format&fit=crop&w=800&q=80',
      description: 'Three-tiered ivory velvet cake with edible gold stenciling.',
    },
  ];

  const categories = ['All', 'Birthday', 'Wedding', 'Designer', 'Cupcakes', 'Kids Cakes'];

  const filteredItems =
    activeFilter === 'All'
      ? galleryItems
      : galleryItems.filter((i) => i.category === activeFilter);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <Breadcrumbs
        items={[
          { label: 'Cakes', tab: 'cakes' },
          { label: 'Celebration Gallery', active: true },
        ]}
        onNavigate={onNavigate}
      />

      <div className="text-center max-w-xl mx-auto mb-10">
        <span className="text-xs font-bold uppercase tracking-wider text-[#8C4E28] block mb-1">
          Visual Inspiration
        </span>
        <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#361F13]">
          Bakery Gallery & Past Works
        </h1>
        <p className="text-xs sm:text-sm text-[#715848] mt-2">
          Explore handcrafted cakes designed for unforgettable weddings, milestone birthdays, and joyful family gatherings.
        </p>
      </div>

      {/* Category Pills */}
      <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveFilter(cat)}
            className={`px-4 py-2 rounded-xl text-xs font-medium border transition-colors ${
              activeFilter === cat
                ? 'bg-[#361F13] text-white border-[#361F13]'
                : 'bg-white text-stone-700 border-stone-200 hover:border-stone-400'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Gallery Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            onClick={() => setSelectedImage(item)}
            className="group relative rounded-2xl overflow-hidden bg-white border border-[#EDE3D6] shadow-2xs hover:shadow-lg cursor-pointer transition-all duration-300"
          >
            <div className="aspect-4/3 overflow-hidden bg-stone-100">
              <SafeImage
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
            </div>
            <div className="p-4">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#8C4E28] block mb-0.5">
                {item.category}
              </span>
              <h4 className="font-serif text-sm font-bold text-[#361F13] line-clamp-1">
                {item.title}
              </h4>
              <p className="text-xs text-stone-500 mt-1 line-clamp-2">{item.description}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Lightbox Modal */}
      {selectedImage && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in"
          onClick={() => setSelectedImage(null)}
        >
          <div
            className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute top-4 right-4 z-10 w-9 h-9 rounded-full bg-white/80 hover:bg-white text-stone-700 flex items-center justify-center shadow-md"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="aspect-4/3 bg-stone-100">
              <SafeImage
                src={selectedImage.image}
                alt={selectedImage.title}
                className="w-full h-full object-cover"
              />
            </div>

            <div className="p-6">
              <span className="text-xs font-bold uppercase tracking-wider text-[#8C4E28] block mb-1">
                {selectedImage.category}
              </span>
              <h3 className="font-serif text-2xl font-bold text-[#361F13]">
                {selectedImage.title}
              </h3>
              <p className="text-xs sm:text-sm text-[#715848] mt-2 leading-relaxed">
                {selectedImage.description}
              </p>

              <div className="mt-6 pt-4 border-t border-[#F2EAE0] flex justify-end">
                <button
                  onClick={() => {
                    setSelectedImage(null);
                    onNavigate('custom-cake');
                  }}
                  className="px-5 py-2.5 bg-[#361F13] text-white text-xs font-semibold rounded-xl"
                >
                  Order a Cake Like This
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

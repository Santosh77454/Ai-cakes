import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useOrder } from '../context/OrderContext';
import { useCart } from '../context/CartContext';
import { useShop } from '../context/ShopContext';
import { useNotification } from '../context/NotificationContext';
import { Breadcrumbs } from '../components/common/Breadcrumbs';
import { SafeImage } from '../components/common/SafeImage';
import { WeightOption, FlavorOption } from '../types';
import {
  User,
  MapPin,
  Package,
  Heart,
  Plus,
  Trash2,
  CheckCircle,
  Clock,
  ShieldCheck,
  LogOut,
  ArrowRight,
} from 'lucide-react';

interface AccountPageProps {
  onNavigate: (tab: string, params?: Record<string, string>) => void;
  onSelectOrder: (orderId: string) => void;
}

export const AccountPage: React.FC<AccountPageProps> = ({
  onNavigate,
  onSelectOrder,
}) => {
  const { user, loginAsCustomer, updateProfile, addAddress, removeAddress, isAdmin, loginAsAdmin } = useAuth();
  const { orders } = useOrder();
  const { addToCart, openCartDrawer } = useCart();
  const { settings } = useShop();
  const { showToast } = useNotification();

  const [activeTab, setActiveTab] = useState<'orders' | 'addresses' | 'profile'>('orders');

  // New address form modal state
  const [showAddAddressModal, setShowAddAddressModal] = useState(false);
  const [addressLabel, setAddressLabel] = useState<'Home' | 'Office' | 'Other'>('Home');
  const [streetAddress, setStreetAddress] = useState('');
  const [addressPincode, setAddressPincode] = useState('411014');

  // Profile update form state
  const [name, setName] = useState(user?.name || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [email, setEmail] = useState(user?.email || '');

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({ name, phone, email });
    showToast('Profile information saved!', 'success');
  };

  const handleAddNewAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!streetAddress.trim() || !addressPincode.trim()) return;
    addAddress({
      label: addressLabel,
      street: streetAddress.trim(),
      city: 'Pune',
      pincode: addressPincode.trim(),
      isDefault: false,
    });
    setStreetAddress('');
    setShowAddAddressModal(false);
    showToast('New delivery address saved!', 'success');
  };

  const handleReorder = (order: typeof orders[0]) => {
    order.items.forEach((it) => {
      addToCart({
        productId: it.productId,
        name: it.name,
        image: it.image,
        weight: (it.weight as WeightOption) || '500g',
        flavor: (it.flavor as FlavorOption) || 'Chocolate',
        eggless: it.eggless,
        selectedAddOns: it.selectedAddOns || [],
        unitPrice: it.unitPrice,
        quantity: it.quantity,
      });
    });
    showToast('Cakes added to cart!', 'success');
    openCartDrawer();
  };

  if (!user) {
    return (
      <div className="max-w-md mx-auto py-16 px-4 text-center">
        <div className="w-16 h-16 rounded-full bg-[#FAF0E6] text-[#8C4E28] mx-auto flex items-center justify-center mb-4">
          <User className="w-8 h-8" />
        </div>
        <h2 className="font-serif text-2xl font-bold text-[#361F13] mb-2">Welcome to Sweet Delight</h2>
        <p className="text-xs text-stone-500 mb-6">
          Sign in instantly to view your past celebration orders, saved addresses, and reward coupons.
        </p>
        <button
          onClick={() => {
            loginAsCustomer();
            showToast('Signed in successfully!', 'success');
          }}
          className="w-full py-3 bg-[#361F13] hover:bg-[#22120A] text-white text-xs font-semibold rounded-xl transition-colors shadow-md"
        >
          Sign In (1-Click Demo Profile)
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <Breadcrumbs
        items={[
          { label: 'Home', tab: 'home' },
          { label: 'My Account', active: true },
        ]}
        onNavigate={onNavigate}
      />

      {/* Account Hero Banner */}
      <div className="bg-[#FAF7F2] p-6 sm:p-8 rounded-3xl border border-[#EDE3D6] mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-[#361F13] text-[#F3C488] font-serif text-2xl font-bold flex items-center justify-center shadow-md">
            {user.name.charAt(0)}
          </div>
          <div>
            <h1 className="font-serif text-2xl font-bold text-[#361F13]">{user.name}</h1>
            <p className="text-xs text-stone-500">{user.email} · {user.phone}</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              if (!isAdmin) loginAsAdmin();
              onNavigate('admin');
            }}
            className="px-4 py-2 bg-white border border-[#D8C7B4] hover:bg-stone-50 text-[#8C4E28] text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors shadow-2xs"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Bakery Admin Panel</span>
          </button>
        </div>
      </div>

      {/* Account Tabs */}
      <div className="flex border-b border-stone-200 mb-8 gap-6 text-sm font-semibold">
        <button
          onClick={() => setActiveTab('orders')}
          className={`pb-3 flex items-center gap-2 transition-colors relative ${
            activeTab === 'orders'
              ? 'text-[#8C4E28] border-b-2 border-[#8C4E28]'
              : 'text-stone-500 hover:text-stone-800'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>My Orders ({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('addresses')}
          className={`pb-3 flex items-center gap-2 transition-colors relative ${
            activeTab === 'addresses'
              ? 'text-[#8C4E28] border-b-2 border-[#8C4E28]'
              : 'text-stone-500 hover:text-stone-800'
          }`}
        >
          <MapPin className="w-4 h-4" />
          <span>Saved Addresses ({(user.savedAddresses || user.addresses || []).length})</span>
        </button>

        <button
          onClick={() => setActiveTab('profile')}
          className={`pb-3 flex items-center gap-2 transition-colors relative ${
            activeTab === 'profile'
              ? 'text-[#8C4E28] border-b-2 border-[#8C4E28]'
              : 'text-stone-500 hover:text-stone-800'
          }`}
        >
          <User className="w-4 h-4" />
          <span>Profile Settings</span>
        </button>
      </div>

      {/* Tab 1: Orders History */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          {orders.length === 0 ? (
            <div className="bg-white p-12 rounded-3xl border border-[#EDE3D6] text-center">
              <Package className="w-12 h-12 text-stone-300 mx-auto mb-3" />
              <h3 className="font-serif text-lg font-bold text-[#361F13]">No orders yet</h3>
              <p className="text-xs text-stone-500 mt-1">Once you order cakes, they will appear here with live tracking.</p>
            </div>
          ) : (
            orders.map((ord) => (
              <div
                key={ord.id}
                className="bg-white rounded-3xl p-6 border border-[#EDE3D6] shadow-2xs space-y-4"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#F2EAE0]">
                  <div>
                    <span className="font-serif text-base font-bold text-[#361F13] mr-3">
                      {ord.id}
                    </span>
                    <span className="text-xs text-stone-400">
                      Placed on {new Date(ord.createdAt).toLocaleDateString()}
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <span
                      className={`text-xs px-2.5 py-0.5 rounded-full font-semibold ${
                        ord.status === 'Delivered'
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          : 'bg-amber-50 text-amber-800 border border-amber-200'
                      }`}
                    >
                      {ord.status}
                    </span>
                    <span className="font-mono text-sm font-bold text-[#361F13]">
                      {settings.currencySymbol}
                      {ord.grandTotal}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {ord.items.map((it, idx) => (
                    <div key={idx} className="flex gap-3 items-center bg-[#FAF7F2] p-2.5 rounded-2xl">
                      <SafeImage
                        src={it.image}
                        alt={it.name}
                        className="w-12 h-12 rounded-xl object-cover"
                      />
                      <div className="flex-1 min-w-0 text-xs">
                        <p className="font-bold text-[#361F13] truncate">{it.name}</p>
                        <p className="text-[11px] text-stone-500">
                          {it.weight} · Qty {it.quantity}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-3 border-t border-[#F2EAE0]">
                  <span className="text-xs text-stone-500">
                    Delivery Scheduled: <strong>{ord.deliveryDate} ({ord.deliverySlot})</strong>
                  </span>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onSelectOrder(ord.id)}
                      className="px-4 py-2 bg-white border border-[#D8C7B4] hover:bg-stone-50 text-[#361F13] text-xs font-semibold rounded-xl transition-colors"
                    >
                      Track Order Details
                    </button>
                    <button
                      onClick={() => handleReorder(ord)}
                      className="px-4 py-2 bg-[#361F13] hover:bg-[#22120A] text-white text-xs font-semibold rounded-xl transition-colors"
                    >
                      Reorder Cake
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Tab 2: Saved Addresses */}
      {activeTab === 'addresses' && (
        <div className="space-y-6">
          <div className="flex justify-end">
            <button
              onClick={() => setShowAddAddressModal(true)}
              className="px-4 py-2.5 bg-[#361F13] hover:bg-[#22120A] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Address</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {(user.savedAddresses || user.addresses || []).map((addr, idx) => (
              <div
                key={addr.id || idx}
                className="bg-white p-5 rounded-2xl border border-[#EDE3D6] shadow-2xs relative flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-[#8C4E28] bg-[#FAF0E6] px-2.5 py-0.5 rounded-md">
                      {addr.label || 'Delivery'}
                    </span>
                    {addr.isDefault && (
                      <span className="text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-bold border border-emerald-200">
                        Default
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-[#361F13] leading-relaxed mt-2 font-medium">
                    {addr.street || `${addr.houseFlat || ''} ${addr.building || ''}`}
                  </p>
                  <p className="text-xs text-stone-500 mt-0.5">
                    {addr.city}, Pune - {addr.pincode}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-[#F2EAE0] flex justify-end">
                  <button
                    onClick={() => removeAddress(addr.id || idx)}
                    className="text-stone-400 hover:text-rose-600 p-1 text-xs flex items-center gap-1 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete</span>
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Add Address Modal */}
          {showAddAddressModal && (
            <div
              role="dialog"
              aria-modal="true"
              className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4"
            >
              <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
                <h3 className="font-serif text-lg font-bold text-[#361F13]">Add New Address</h3>

                <form onSubmit={handleAddNewAddress} className="space-y-3">
                  <div>
                    <label className="text-xs font-semibold text-[#361F13] block mb-1">Address Label</label>
                    <div className="grid grid-cols-3 gap-2">
                      {(['Home', 'Office', 'Other'] as const).map((lbl) => (
                        <button
                          type="button"
                          key={lbl}
                          onClick={() => setAddressLabel(lbl)}
                          className={`py-1.5 text-xs font-semibold rounded-lg border ${
                            addressLabel === lbl
                              ? 'bg-[#361F13] text-white border-[#361F13]'
                              : 'border-stone-200 text-stone-700'
                          }`}
                        >
                          {lbl}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label htmlFor="modal-street-address" className="text-xs font-semibold text-[#361F13] block mb-1">
                      Street Address & Flat / Building No.
                    </label>
                    <input
                      id="modal-street-address"
                      type="text"
                      required
                      placeholder="e.g. Flat 301, Gera Emerald, Kharadi"
                      value={streetAddress}
                      onChange={(e) => setStreetAddress(e.target.value)}
                      className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs"
                    />
                  </div>

                  <div>
                    <label htmlFor="modal-pincode" className="text-xs font-semibold text-[#361F13] block mb-1">Pincode</label>
                    <input
                      id="modal-pincode"
                      type="text"
                      required
                      maxLength={6}
                      value={addressPincode}
                      onChange={(e) => setAddressPincode(e.target.value.replace(/[^0-9]/g, ''))}
                      className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs"
                    />
                  </div>

                  <div className="flex gap-2 pt-3">
                    <button
                      type="button"
                      onClick={() => setShowAddAddressModal(false)}
                      className="flex-1 py-2 text-xs font-semibold text-stone-600 border border-stone-200 rounded-xl"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="flex-1 py-2 text-xs font-semibold bg-[#361F13] text-white rounded-xl"
                    >
                      Save Address
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Profile Settings */}
      {activeTab === 'profile' && (
        <div className="max-w-xl bg-white p-6 sm:p-8 rounded-3xl border border-[#EDE3D6] shadow-xs">
          <h3 className="font-serif text-lg font-bold text-[#361F13] mb-4">Edit Profile</h3>

          <form onSubmit={handleSaveProfile} className="space-y-4">
            <div>
              <label htmlFor="profile-full-name" className="text-xs font-semibold text-[#361F13] block mb-1">Full Name</label>
              <input
                id="profile-full-name"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
              />
            </div>

            <div>
              <label htmlFor="profile-phone" className="text-xs font-semibold text-[#361F13] block mb-1">Mobile Phone Number</label>
              <input
                id="profile-phone"
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
              />
            </div>

            <div>
              <label htmlFor="profile-email" className="text-xs font-semibold text-[#361F13] block mb-1">Email Address</label>
              <input
                id="profile-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
              />
            </div>

            <button
              type="submit"
              className="px-6 py-2.5 bg-[#361F13] hover:bg-[#22120A] text-white text-xs font-semibold rounded-xl transition-colors"
            >
              Save Profile Changes
            </button>
          </form>
        </div>
      )}
    </div>
  );
};

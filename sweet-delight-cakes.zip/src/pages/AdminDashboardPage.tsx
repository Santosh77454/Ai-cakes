import React, { useState, useMemo } from 'react';
import { useShop } from '../context/ShopContext';
import { useOrder } from '../context/OrderContext';
import { useAuth } from '../context/AuthContext';
import { Product, OrderStatus, Coupon, Order } from '../types';
import { SafeImage } from '../components/common/SafeImage';
import { useNotification } from '../context/NotificationContext';
import {
  LayoutDashboard,
  Cake,
  ShoppingBag,
  Tag,
  Truck,
  Settings,
  Star,
  Plus,
  Trash2,
  Edit,
  Eye,
  CheckCircle,
  Clock,
  TrendingUp,
  Search,
  X,
  Save,
  Check,
  RotateCcw,
} from 'lucide-react';

interface AdminDashboardPageProps {
  onNavigate: (tab: string) => void;
}

type AdminTab =
  | 'overview'
  | 'products'
  | 'orders'
  | 'coupons'
  | 'delivery'
  | 'reviews'
  | 'settings';

export const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({ onNavigate }) => {
  const {
    products,
    categories,
    coupons,
    reviews,
    settings,
    addProduct,
    updateProduct,
    deleteProduct,
    addCoupon,
    deleteCoupon,
    deleteReview,
    updateSettings,
    addSupportedPincode,
    removeSupportedPincode,
  } = useShop();

  const { orders, updateOrderStatus } = useOrder();
  const { logoutAdmin } = useAuth();
  const { showToast } = useNotification();

  const [currentTab, setCurrentTab] = useState<AdminTab>('overview');

  // Search & Filters in Admin
  const [productSearch, setProductSearch] = useState('');
  const [orderSearch, setOrderSearch] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>('all');

  // Product Edit / Create Modal state
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isNewProductModalOpen, setIsNewProductModalOpen] = useState(false);

  // Form states for Product
  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState(categories[0]?.name || 'Birthday Cakes');
  const [formDesc, setFormDesc] = useState('');
  const [formBasePrice, setFormBasePrice] = useState(699);
  const [formDiscount, setFormDiscount] = useState(0);
  const [formEggless, setFormEggless] = useState(true);
  const [formStock, setFormStock] = useState(15);
  const [formImageUrl, setFormImageUrl] = useState('');

  // Coupon Creation state
  const [showCouponModal, setShowCouponModal] = useState(false);
  const [newCouponCode, setNewCouponCode] = useState('');
  const [newCouponType, setNewCouponType] = useState<'percent' | 'flat'>('percent');
  const [newCouponVal, setNewCouponVal] = useState(10);
  const [newCouponMin, setNewCouponMin] = useState(499);
  const [newCouponDesc, setNewCouponDesc] = useState('');

  // Delivery Setting states
  const [newPincode, setNewPincode] = useState('');

  // Shop Settings form state
  const [shopName, setShopName] = useState(settings.shopName);
  const [tagline, setTagline] = useState(settings.tagline);
  const [phone, setPhone] = useState(settings.phone);
  const [email, setEmail] = useState(settings.email);
  const [whatsapp, setWhatsapp] = useState(settings.whatsapp);
  const [announcementMsg, setAnnouncementMsg] = useState(settings.announcementBarMessage);
  const [announcementActive, setAnnouncementActive] = useState(settings.announcementActive);
  const [freeThreshold, setFreeThreshold] = useState(settings.freeDeliveryThreshold);

  // Order Details Modal
  const [inspectedOrder, setInspectedOrder] = useState<Order | null>(null);

  // Overview metrics calculations
  const totalRevenue = useMemo(() => {
    return orders.reduce((sum, o) => sum + o.grandTotal, 0);
  }, [orders]);

  const pendingDeliveries = useMemo(() => {
    return orders.filter((o) => o.status !== 'Delivered' && o.status !== 'Cancelled').length;
  }, [orders]);

  const openEditModal = (p: Product) => {
    setEditingProduct(p);
    setFormName(p.name);
    setFormCategory(p.category);
    setFormDesc(p.description);
    setFormBasePrice(p.basePrice);
    setFormDiscount(p.discountPercent);
    setFormEggless(p.eggless);
    setFormStock(p.stock);
    setFormImageUrl(p.images[0] || '');
    setIsNewProductModalOpen(true);
  };

  const openCreateModal = () => {
    setEditingProduct(null);
    setFormName('');
    setFormCategory(categories[0]?.name || 'Birthday Cakes');
    setFormDesc('');
    setFormBasePrice(699);
    setFormDiscount(0);
    setFormEggless(true);
    setFormStock(20);
    setFormImageUrl(
      'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80'
    );
    setIsNewProductModalOpen(true);
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formImageUrl.trim()) return;

    if (editingProduct) {
      updateProduct(editingProduct.id, {
        name: formName.trim(),
        category: formCategory,
        description: formDesc.trim(),
        basePrice: Number(formBasePrice),
        discountPercent: Number(formDiscount),
        eggless: formEggless,
        stock: Number(formStock),
        images: [formImageUrl.trim(), ...(editingProduct.images.slice(1))],
      });
      showToast('Cake product updated successfully!', 'success');
    } else {
      addProduct({
        name: formName.trim(),
        slug: formName.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-'),
        category: formCategory,
        description: formDesc.trim(),
        basePrice: Number(formBasePrice),
        discountPercent: Number(formDiscount),
        weights: ['500g', '1kg', '1.5kg', '2kg'],
        flavors: ['Chocolate', 'Vanilla', 'Red Velvet'],
        defaultWeight: '500g',
        defaultFlavor: 'Chocolate',
        eggless: formEggless,
        rating: 4.8,
        reviewCount: 1,
        stock: Number(formStock),
        tags: ['Fresh', formCategory],
        bestseller: false,
        featured: false,
        newArrival: true,
        images: [formImageUrl.trim()],
      });
      showToast('New cake added to live catalog!', 'success');
    }
    setIsNewProductModalOpen(false);
  };

  const handleCreateCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCouponCode.trim() || !newCouponDesc.trim()) return;
    addCoupon({
      code: newCouponCode.trim().toUpperCase(),
      discountType: newCouponType === 'percent' ? 'percentage' : 'fixed',
      discountValue: Number(newCouponVal),
      minOrderValue: Number(newCouponMin),
      expiryDate: '2026-12-31',
      validTill: '2026-12-31',
      description: newCouponDesc.trim(),
      isActive: true,
      active: true,
    });
    setNewCouponCode('');
    setNewCouponDesc('');
    setShowCouponModal(false);
    showToast('New coupon code created!', 'success');
  };

  const handleSaveShopSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      shopName,
      tagline,
      phone,
      email,
      whatsapp,
      announcementBarMessage: announcementMsg,
      announcementActive,
      freeDeliveryThreshold: Number(freeThreshold),
    });
    showToast('Bakery store settings saved!', 'success');
  };

  const handleAddPincode = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPincode.length === 6) {
      addSupportedPincode(newPincode);
      setNewPincode('');
      showToast(`Pincode ${newPincode} enabled for delivery!`, 'success');
    }
  };

  // Filtered orders
  const filteredOrders = useMemo(() => {
    return orders.filter((o) => {
      const matchSearch =
        o.id.toLowerCase().includes(orderSearch.toLowerCase()) ||
        o.customer.name.toLowerCase().includes(orderSearch.toLowerCase()) ||
        o.customer.phone.includes(orderSearch);
      const matchStatus =
        orderStatusFilter === 'all' || o.status.toLowerCase() === orderStatusFilter.toLowerCase();
      return matchSearch && matchStatus;
    });
  }, [orders, orderSearch, orderStatusFilter]);

  // Filtered products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      return (
        p.name.toLowerCase().includes(productSearch.toLowerCase()) ||
        p.category.toLowerCase().includes(productSearch.toLowerCase())
      );
    });
  }, [products, productSearch]);

  return (
    <div className="min-h-screen bg-[#FAF7F2] pb-16">
      {/* Admin Top Navigation */}
      <header className="bg-[#361F13] text-white sticky top-0 z-30 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#F3C488] text-[#361F13] flex items-center justify-center font-bold">
              <Cake className="w-4 h-4" />
            </div>
            <div>
              <span className="font-serif text-base font-bold tracking-tight">
                {settings.shopName} · Admin Console
              </span>
              <span className="hidden sm:inline-block text-[11px] text-emerald-400 ml-2">● Live Bakery Store</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('home')}
              className="text-xs text-[#D8C7B4] hover:text-white transition-colors"
            >
              View Storefront
            </button>
            <button
              onClick={() => {
                logoutAdmin();
                onNavigate('home');
              }}
              className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-lg text-xs font-semibold transition-colors"
            >
              Exit Admin
            </button>
          </div>
        </div>
      </header>

      {/* Admin Navigation Tabs */}
      <div className="bg-white border-b border-[#EBE3D7] shadow-xs sticky top-16 z-20 overflow-x-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex gap-6 text-xs font-semibold">
          {[
            { id: 'overview', label: 'Overview', icon: LayoutDashboard },
            { id: 'orders', label: `Orders (${orders.length})`, icon: ShoppingBag },
            { id: 'products', label: `Products (${products.length})`, icon: Cake },
            { id: 'coupons', label: `Coupons (${coupons.length})`, icon: Tag },
            { id: 'delivery', label: 'Delivery & Pincodes', icon: Truck },
            { id: 'reviews', label: `Reviews (${reviews.length})`, icon: Star },
            { id: 'settings', label: 'Shop Settings', icon: Settings },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setCurrentTab(tab.id as AdminTab)}
              className={`py-3.5 flex items-center gap-1.5 whitespace-nowrap transition-colors border-b-2 ${
                currentTab === tab.id
                  ? 'border-[#8C4E28] text-[#8C4E28]'
                  : 'border-transparent text-stone-500 hover:text-stone-900'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        {/* TAB 1: OVERVIEW */}
        {currentTab === 'overview' && (
          <div className="space-y-8">
            {/* Metric Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white p-5 rounded-2xl border border-[#EDE3D6] shadow-xs">
                <span className="text-[11px] font-semibold text-stone-400 uppercase tracking-wider block">
                  Total Orders
                </span>
                <span className="font-serif text-3xl font-bold text-[#361F13] mt-1 block">
                  {orders.length}
                </span>
                <span className="text-[11px] text-emerald-700 font-medium">100% Fulfilled / Live</span>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-[#EDE3D6] shadow-xs">
                <span className="text-[11px] font-semibold text-stone-400 uppercase tracking-wider block">
                  Total Revenue
                </span>
                <span className="font-serif text-3xl font-bold text-[#361F13] mt-1 block font-mono">
                  {settings.currencySymbol}
                  {totalRevenue.toLocaleString()}
                </span>
                <span className="text-[11px] text-emerald-700 font-medium">Includes Tax & Delivery</span>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-[#EDE3D6] shadow-xs">
                <span className="text-[11px] font-semibold text-stone-400 uppercase tracking-wider block">
                  Pending Deliveries
                </span>
                <span className="font-serif text-3xl font-bold text-[#8C4E28] mt-1 block">
                  {pendingDeliveries}
                </span>
                <span className="text-[11px] text-amber-700 font-medium">Scheduled for today</span>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-[#EDE3D6] shadow-xs">
                <span className="text-[11px] font-semibold text-stone-400 uppercase tracking-wider block">
                  Active Cake Varieties
                </span>
                <span className="font-serif text-3xl font-bold text-[#361F13] mt-1 block">
                  {products.length}
                </span>
                <span className="text-[11px] text-stone-500 font-medium">Across 12 Categories</span>
              </div>
            </div>

            {/* Recent Orders Overview */}
            <div className="bg-white p-6 rounded-3xl border border-[#EDE3D6] shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#F2EAE0]">
                <h3 className="font-serif text-lg font-bold text-[#361F13]">Recent Customer Orders</h3>
                <button
                  onClick={() => setCurrentTab('orders')}
                  className="text-xs font-semibold text-[#8C4E28] hover:underline"
                >
                  Manage All Orders →
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-stone-100 text-stone-400 font-semibold uppercase tracking-wider">
                      <th className="py-2.5">Order ID</th>
                      <th className="py-2.5">Customer</th>
                      <th className="py-2.5">Delivery Slot</th>
                      <th className="py-2.5">Amount</th>
                      <th className="py-2.5">Status</th>
                      <th className="py-2.5 text-right">Quick Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {orders.slice(0, 5).map((ord) => (
                      <tr key={ord.id} className="hover:bg-[#FAF7F2]">
                        <td className="py-3 font-semibold text-[#361F13]">{ord.id}</td>
                        <td className="py-3">
                          <span className="font-bold text-[#361F13] block">{ord.customer.name}</span>
                          <span className="text-[11px] text-stone-400">{ord.customer.phone}</span>
                        </td>
                        <td className="py-3 text-stone-600">
                          {ord.deliveryDate} ({ord.deliverySlot})
                        </td>
                        <td className="py-3 font-bold text-[#361F13] font-mono">
                          {settings.currencySymbol}
                          {ord.grandTotal}
                        </td>
                        <td className="py-3">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                              ord.status === 'Delivered'
                                ? 'bg-emerald-50 text-emerald-800'
                                : 'bg-amber-50 text-amber-800'
                            }`}
                          >
                            {ord.status}
                          </span>
                        </td>
                        <td className="py-3 text-right">
                          <button
                            onClick={() => setInspectedOrder(ord)}
                            className="px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-md font-medium"
                          >
                            View Details
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: PRODUCTS */}
        {currentTab === 'products' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="relative flex-1 max-w-md">
                <Search className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                <input
                  type="text"
                  placeholder="Search products by title or category..."
                  value={productSearch}
                  onChange={(e) => setProductSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-white border border-[#E2D5C7] rounded-xl text-xs"
                />
              </div>

              <button
                onClick={openCreateModal}
                className="px-4 py-2 bg-[#361F13] hover:bg-[#22120A] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 shadow-md transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Cake</span>
              </button>
            </div>

            <div className="bg-white rounded-3xl border border-[#EDE3D6] shadow-xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#FAF7F2] border-b border-[#EDE3D6] text-stone-500 font-semibold uppercase tracking-wider">
                    <tr>
                      <th className="p-3.5">Cake</th>
                      <th className="p-3.5">Category</th>
                      <th className="p-3.5">Base Price</th>
                      <th className="p-3.5">Stock</th>
                      <th className="p-3.5">Eggless</th>
                      <th className="p-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#F2EAE0]">
                    {filteredProducts.map((cake) => (
                      <tr key={cake.id} className="hover:bg-[#FAF7F2]/60">
                        <td className="p-3.5 flex items-center gap-3">
                          <SafeImage
                            src={cake.images[0]}
                            alt={cake.name}
                            className="w-10 h-10 rounded-lg object-cover"
                          />
                          <div>
                            <span className="font-bold text-[#361F13] block">{cake.name}</span>
                            <span className="text-[10px] text-stone-400">{cake.weights.join(', ')}</span>
                          </div>
                        </td>
                        <td className="p-3.5 text-stone-600">{cake.category}</td>
                        <td className="p-3.5 font-bold font-mono text-[#361F13]">
                          {settings.currencySymbol}
                          {cake.basePrice}
                          {cake.discountPercent > 0 && (
                            <span className="text-[10px] text-emerald-700 ml-1">
                              ({cake.discountPercent}% off)
                            </span>
                          )}
                        </td>
                        <td className="p-3.5">
                          <button
                            onClick={() =>
                              updateProduct(cake.id, { stock: cake.stock > 0 ? 0 : 20 })
                            }
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              cake.stock > 0
                                ? 'bg-emerald-50 text-emerald-800'
                                : 'bg-rose-50 text-rose-800'
                            }`}
                          >
                            {cake.stock > 0 ? `In Stock (${cake.stock})` : 'Out of Stock'}
                          </button>
                        </td>
                        <td className="p-3.5">
                          <span
                            className={`text-[10px] px-1.5 py-0.5 rounded font-semibold ${
                              cake.eggless ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-800'
                            }`}
                          >
                            {cake.eggless ? 'Eggless' : 'With Egg'}
                          </span>
                        </td>
                        <td className="p-3.5 text-right space-x-2">
                          <button
                            onClick={() => openEditModal(cake)}
                            className="p-1.5 hover:bg-stone-100 text-stone-600 rounded-md transition-colors"
                            title="Edit"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              if (window.confirm(`Delete ${cake.name}?`)) {
                                deleteProduct(cake.id);
                                showToast(`Deleted ${cake.name}`, 'info');
                              }
                            }}
                            className="p-1.5 hover:bg-rose-50 text-stone-400 hover:text-rose-600 rounded-md transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: ORDERS */}
        {currentTab === 'orders' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="relative flex-1 max-w-md">
                <Search className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                <input
                  type="text"
                  placeholder="Search order ID, customer name or phone..."
                  value={orderSearch}
                  onChange={(e) => setOrderSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-white border border-[#E2D5C7] rounded-xl text-xs"
                />
              </div>

              {/* Status Filter */}
              <div className="flex items-center gap-2">
                <label htmlFor="admin-order-status" className="text-xs text-stone-500 font-semibold">Filter Status:</label>
                <select
                  id="admin-order-status"
                  value={orderStatusFilter}
                  onChange={(e) => setOrderStatusFilter(e.target.value)}
                  className="px-3 py-2 bg-white border border-[#E2D5C7] rounded-xl text-xs font-semibold"
                >
                  <option value="all">All Orders ({orders.length})</option>
                  <option value="placed">Placed</option>
                  <option value="confirmed">Confirmed</option>
                  <option value="baking">Baking</option>
                  <option value="out for delivery">Out for Delivery</option>
                  <option value="delivered">Delivered</option>
                </select>
              </div>
            </div>

            <div className="bg-white rounded-3xl border border-[#EDE3D6] shadow-xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#FAF7F2] border-b border-[#EDE3D6] text-stone-500 font-semibold uppercase tracking-wider">
                    <tr>
                      <th className="p-3.5">Order</th>
                      <th className="p-3.5">Customer & Address</th>
                      <th className="p-3.5">Scheduled Delivery</th>
                      <th className="p-3.5">Amount</th>
                      <th className="p-3.5">Change Status</th>
                      <th className="p-3.5 text-right">Details</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#F2EAE0]">
                    {filteredOrders.map((ord) => (
                      <tr key={ord.id} className="hover:bg-[#FAF7F2]/60">
                        <td className="p-3.5">
                          <span className="font-bold text-[#361F13] block">{ord.id}</span>
                          <span className="text-[10px] text-stone-400">
                            {ord.items.length} items · {ord.paymentMethod}
                          </span>
                        </td>
                        <td className="p-3.5">
                          <strong className="text-[#361F13]">{ord.customer.name}</strong>
                          <span className="text-stone-500 block truncate max-w-[200px]">
                            {ord.customer.address}, {ord.customer.pincode}
                          </span>
                        </td>
                        <td className="p-3.5 text-stone-600">
                          {ord.deliveryDate}
                          <span className="block text-[11px] text-[#8C4E28] font-medium">
                            {ord.deliverySlot}
                          </span>
                        </td>
                        <td className="p-3.5 font-bold font-mono text-[#361F13]">
                          {settings.currencySymbol}
                          {ord.grandTotal}
                        </td>
                        <td className="p-3.5">
                          <select
                            value={ord.status}
                            onChange={(e) => {
                              updateOrderStatus(ord.id, e.target.value as OrderStatus);
                              showToast(`Updated ${ord.id} status to ${e.target.value}`, 'success');
                            }}
                            className="bg-white border border-stone-200 rounded-lg px-2 py-1 text-xs font-semibold text-[#361F13] focus:outline-hidden"
                          >
                            <option value="Placed">Placed</option>
                            <option value="Confirmed">Confirmed</option>
                            <option value="Baking">Baking In Oven</option>
                            <option value="Out for Delivery">Out for Delivery</option>
                            <option value="Delivered">Delivered</option>
                            <option value="Cancelled">Cancelled</option>
                          </select>
                        </td>
                        <td className="p-3.5 text-right">
                          <button
                            onClick={() => setInspectedOrder(ord)}
                            className="px-3 py-1 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg text-xs font-medium"
                          >
                            Inspect
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: COUPONS */}
        {currentTab === 'coupons' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-serif text-lg font-bold text-[#361F13]">Bakery Promotional Coupons</h3>
                <p className="text-xs text-stone-500">Active vouchers shown to customers on checkout</p>
              </div>
              <button
                onClick={() => setShowCouponModal(true)}
                className="px-4 py-2 bg-[#361F13] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>Create New Coupon</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {coupons.map((c) => (
                <div
                  key={c.code}
                  className="bg-white p-5 rounded-2xl border border-[#EDE3D6] shadow-2xs flex flex-col justify-between"
                >
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-mono text-sm font-bold text-[#361F13] bg-[#FAF0E6] px-2.5 py-1 rounded-md">
                        {c.code}
                      </span>
                      <span className="text-xs font-bold text-emerald-700">
                        {c.discountType === 'percent' || c.discountType === 'percentage'
                          ? `${c.discountValue}%`
                          : `₹${c.discountValue}`}
                      </span>
                    </div>
                    <p className="text-xs text-stone-700 font-medium">{c.description}</p>
                    <p className="text-[11px] text-stone-400 mt-1">Min Order: ₹{c.minOrderValue}</p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-stone-100 flex justify-end">
                    <button
                      onClick={() => deleteCoupon(c.code)}
                      className="text-xs text-rose-600 hover:underline flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Remove</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5: DELIVERY & PINCODES */}
        {currentTab === 'delivery' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div className="lg:col-span-6 bg-white p-6 rounded-3xl border border-[#EDE3D6] shadow-xs space-y-4">
              <h3 className="font-serif text-lg font-bold text-[#361F13]">Supported Delivery Pincodes</h3>
              <p className="text-xs text-stone-500">
                Customers entering these pincodes can place same-day and scheduled cake orders.
              </p>

              <form onSubmit={handleAddPincode} className="flex gap-2">
                <input
                  type="text"
                  maxLength={6}
                  placeholder="Enter 6-digit Pincode (e.g. 411038)"
                  value={newPincode}
                  onChange={(e) => setNewPincode(e.target.value.replace(/[^0-9]/g, ''))}
                  className="flex-1 px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#361F13] text-white text-xs font-semibold rounded-xl"
                >
                  Add Pincode
                </button>
              </form>

              <div className="flex flex-wrap gap-2 pt-2">
                {settings.supportedPincodes.map((pin) => (
                  <span
                    key={pin}
                    className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#FAF7F2] border border-[#EDE3D6] rounded-lg text-xs font-mono font-medium text-[#361F13]"
                  >
                    <span>{pin}</span>
                    <button
                      onClick={() => removeSupportedPincode(pin)}
                      className="text-stone-400 hover:text-rose-600"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            </div>

            <div className="lg:col-span-6 bg-white p-6 rounded-3xl border border-[#EDE3D6] shadow-xs space-y-4">
              <h3 className="font-serif text-lg font-bold text-[#361F13]">Popular Delivery Hubs</h3>
              <div className="flex flex-wrap gap-2">
                {settings.deliveryAreas.map((area) => (
                  <span
                    key={area}
                    className="px-3 py-1.5 bg-[#FAF0E6] text-[#8C4E28] rounded-xl text-xs font-semibold border border-[#E9DFD3]"
                  >
                    {area}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: REVIEWS MODERATION */}
        {currentTab === 'reviews' && (
          <div className="space-y-6">
            <h3 className="font-serif text-lg font-bold text-[#361F13]">Customer Reviews Moderation</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {reviews.map((rev) => (
                <div
                  key={rev.id}
                  className="bg-white p-5 rounded-2xl border border-[#EDE3D6] shadow-2xs flex flex-col justify-between"
                >
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <strong className="text-xs text-[#361F13]">{rev.customerName}</strong>
                      <div className="flex text-amber-500">
                        {[...Array(rev.rating)].map((_, i) => (
                          <Star key={i} className="w-3.5 h-3.5 fill-current" />
                        ))}
                      </div>
                    </div>
                    <p className="text-xs text-stone-600 italic">&quot;{rev.comment}&quot;</p>
                    <span className="text-[11px] text-[#8C4E28] mt-1 block">
                      Cake: {rev.cakePurchased}
                    </span>
                  </div>

                  <div className="mt-4 pt-3 border-t border-stone-100 flex justify-end">
                    <button
                      onClick={() => deleteReview(rev.id)}
                      className="text-xs text-rose-600 hover:underline flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Remove Review</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 7: SETTINGS */}
        {currentTab === 'settings' && (
          <div className="max-w-2xl bg-white p-6 sm:p-8 rounded-3xl border border-[#EDE3D6] shadow-xs space-y-6">
            <h3 className="font-serif text-xl font-bold text-[#361F13]">Bakery Store Settings</h3>

            <form onSubmit={handleSaveShopSettings} className="space-y-4">
              <div>
                <label htmlFor="settings-shop-name" className="text-xs font-semibold text-[#361F13] block mb-1">Bakery Shop Name</label>
                <input
                  id="settings-shop-name"
                  type="text"
                  value={shopName}
                  onChange={(e) => setShopName(e.target.value)}
                  className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs"
                />
              </div>

              <div>
                <label htmlFor="settings-tagline" className="text-xs font-semibold text-[#361F13] block mb-1">Tagline</label>
                <input
                  id="settings-tagline"
                  type="text"
                  value={tagline}
                  onChange={(e) => setTagline(e.target.value)}
                  className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="settings-phone" className="text-xs font-semibold text-[#361F13] block mb-1">Support Phone</label>
                  <input
                    id="settings-phone"
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs"
                  />
                </div>
                <div>
                  <label htmlFor="settings-whatsapp" className="text-xs font-semibold text-[#361F13] block mb-1">WhatsApp Number</label>
                  <input
                    id="settings-whatsapp"
                    type="text"
                    value={whatsapp}
                    onChange={(e) => setWhatsapp(e.target.value)}
                    className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="settings-email" className="text-xs font-semibold text-[#361F13] block mb-1">Email</label>
                <input
                  id="settings-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs"
                />
              </div>

              <div>
                <label htmlFor="settings-free-threshold" className="text-xs font-semibold text-[#361F13] block mb-1">
                  Free Delivery Threshold (₹)
                </label>
                <input
                  id="settings-free-threshold"
                  type="number"
                  value={freeThreshold}
                  onChange={(e) => setFreeThreshold(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs"
                />
              </div>

              <div className="pt-2 border-t border-[#F2EAE0]">
                <label className="flex items-center gap-2 text-xs font-semibold text-[#361F13] cursor-pointer mb-2">
                  <input
                    type="checkbox"
                    checked={announcementActive}
                    onChange={(e) => setAnnouncementActive(e.target.checked)}
                    className="text-[#8C4E28] focus:ring-[#8C4E28]"
                  />
                  <span>Show Top Announcement Banner</span>
                </label>
                <input
                  type="text"
                  value={announcementMsg}
                  onChange={(e) => setAnnouncementMsg(e.target.value)}
                  className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs"
                />
              </div>

              <button
                type="submit"
                className="px-6 py-2.5 bg-[#361F13] hover:bg-[#22120A] text-white text-xs font-semibold rounded-xl flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                <span>Save Bakery Settings</span>
              </button>
            </form>
          </div>
        )}
      </div>

      {/* Modal: Create / Edit Product */}
      {isNewProductModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in"
        >
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl max-h-[90vh] overflow-y-auto space-y-4">
            <div className="flex justify-between items-center pb-3 border-b border-stone-200">
              <h3 className="font-serif text-lg font-bold text-[#361F13]">
                {editingProduct ? 'Edit Cake Product' : 'Add New Artisan Cake'}
              </h3>
              <button
                onClick={() => setIsNewProductModalOpen(false)}
                className="text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-4">
              <div>
                <label htmlFor="cake-name-modal" className="text-xs font-semibold text-[#361F13] block mb-1">Cake Name</label>
                <input
                  id="cake-name-modal"
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor="cake-category-modal" className="text-xs font-semibold text-[#361F13] block mb-1">Category</label>
                  <select
                    id="cake-category-modal"
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.name}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label htmlFor="cake-base-price-modal" className="text-xs font-semibold text-[#361F13] block mb-1">Base Price (500g)</label>
                  <input
                    id="cake-base-price-modal"
                    type="number"
                    required
                    value={formBasePrice}
                    onChange={(e) => setFormBasePrice(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor="cake-discount-modal" className="text-xs font-semibold text-[#361F13] block mb-1">Discount %</label>
                  <input
                    id="cake-discount-modal"
                    type="number"
                    value={formDiscount}
                    onChange={(e) => setFormDiscount(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs"
                  />
                </div>

                <div>
                  <label htmlFor="cake-stock-modal" className="text-xs font-semibold text-[#361F13] block mb-1">Stock Count</label>
                  <input
                    id="cake-stock-modal"
                    type="number"
                    value={formStock}
                    onChange={(e) => setFormStock(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="cake-image-url-modal" className="text-xs font-semibold text-[#361F13] block mb-1">Image URL</label>
                <input
                  id="cake-image-url-modal"
                  type="text"
                  required
                  value={formImageUrl}
                  onChange={(e) => setFormImageUrl(e.target.value)}
                  className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs"
                />
              </div>

              <div>
                <label htmlFor="cake-desc-modal" className="text-xs font-semibold text-[#361F13] block mb-1">Description</label>
                <textarea
                  id="cake-desc-modal"
                  rows={3}
                  value={formDesc}
                  onChange={(e) => setFormDesc(e.target.value)}
                  className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs"
                ></textarea>
              </div>

              <div className="flex items-center gap-3">
                <label className="flex items-center gap-2 text-xs font-semibold text-[#361F13] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formEggless}
                    onChange={(e) => setFormEggless(e.target.checked)}
                    className="text-emerald-700"
                  />
                  <span>100% Eggless</span>
                </label>
              </div>

              <div className="flex gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsNewProductModalOpen(false)}
                  className="flex-1 py-2.5 text-xs font-semibold text-stone-600 border border-stone-200 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 text-xs font-semibold bg-[#361F13] text-white rounded-xl"
                >
                  Save Cake
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Order Inspection */}
      {inspectedOrder && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in"
        >
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl max-h-[90vh] overflow-y-auto space-y-4">
            <div className="flex justify-between items-center pb-3 border-b border-stone-200">
              <div>
                <h3 className="font-serif text-lg font-bold text-[#361F13]">
                  Order {inspectedOrder.id}
                </h3>
                <span className="text-xs text-stone-400">
                  Customer: {inspectedOrder.customer.name} ({inspectedOrder.customer.phone})
                </span>
              </div>
              <button
                onClick={() => setInspectedOrder(null)}
                className="text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-[#FAF7F2] rounded-xl border border-stone-200">
                <p>
                  <strong>Address:</strong> {inspectedOrder.customer.address}, {inspectedOrder.customer.city} - {inspectedOrder.customer.pincode}
                </p>
                <p className="mt-1">
                  <strong>Slot:</strong> {inspectedOrder.deliveryDate} ({inspectedOrder.deliverySlot})
                </p>
                {inspectedOrder.specialInstructions && (
                  <p className="mt-1 italic text-[#8C4E28]">
                    Note: &quot;{inspectedOrder.specialInstructions}&quot;
                  </p>
                )}
              </div>

              <div>
                <strong className="block text-[#361F13] mb-1">Items in this Order:</strong>
                <div className="space-y-2">
                  {inspectedOrder.items.map((it, i) => (
                    <div key={i} className="flex gap-2 items-center justify-between p-2 bg-stone-50 rounded-lg">
                      <div className="flex gap-2 items-center">
                        <SafeImage src={it.image} alt={it.name} className="w-8 h-8 rounded-md object-cover" />
                        <div>
                          <span className="font-semibold block">{it.name}</span>
                          <span className="text-[10px] text-stone-500">
                            {it.weight} · {it.flavor} {it.eggless ? '(Eggless)' : ''} · Qty {it.quantity}
                          </span>
                          {it.customMessage && (
                            <span className="text-[10px] text-[#8C4E28] block italic">
                              &quot;{it.customMessage}&quot;
                            </span>
                          )}
                        </div>
                      </div>
                      <span className="font-bold font-mono">₹{it.totalPrice}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-2 border-t border-stone-200 flex justify-between font-bold text-sm">
                <span>Total Amount</span>
                <span>₹{inspectedOrder.grandTotal} ({inspectedOrder.paymentMethod})</span>
              </div>
            </div>

            <div className="pt-3">
              <button
                onClick={() => setInspectedOrder(null)}
                className="w-full py-2.5 bg-[#361F13] text-white text-xs font-semibold rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: New Coupon */}
      {showCouponModal && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in"
        >
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-stone-200">
              <h3 className="font-serif text-lg font-bold text-[#361F13]">Create Coupon Code</h3>
              <button onClick={() => setShowCouponModal(false)} className="text-stone-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCoupon} className="space-y-3">
              <div>
                <label htmlFor="coupon-code-modal" className="text-xs font-semibold text-[#361F13] block mb-1">Coupon Code</label>
                <input
                  id="coupon-code-modal"
                  type="text"
                  required
                  placeholder="e.g. FESTIVE20"
                  value={newCouponCode}
                  onChange={(e) => setNewCouponCode(e.target.value.toUpperCase())}
                  className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs uppercase"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor="coupon-type-modal" className="text-xs font-semibold text-[#361F13] block mb-1">Discount Type</label>
                  <select
                    id="coupon-type-modal"
                    value={newCouponType}
                    onChange={(e) => setNewCouponType(e.target.value as any)}
                    className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs"
                  >
                    <option value="percent">Percentage (%)</option>
                    <option value="flat">Flat Amount (₹)</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="coupon-val-modal" className="text-xs font-semibold text-[#361F13] block mb-1">Discount Value</label>
                  <input
                    id="coupon-val-modal"
                    type="number"
                    required
                    value={newCouponVal}
                    onChange={(e) => setNewCouponVal(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="coupon-min-order-modal" className="text-xs font-semibold text-[#361F13] block mb-1">Minimum Order Value (₹)</label>
                <input
                  id="coupon-min-order-modal"
                  type="number"
                  required
                  value={newCouponMin}
                  onChange={(e) => setNewCouponMin(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs"
                />
              </div>

              <div>
                <label htmlFor="coupon-desc-modal" className="text-xs font-semibold text-[#361F13] block mb-1">Description</label>
                <input
                  id="coupon-desc-modal"
                  type="text"
                  required
                  placeholder="e.g. Flat 15% discount for festival weekend"
                  value={newCouponDesc}
                  onChange={(e) => setNewCouponDesc(e.target.value)}
                  className="w-full px-3 py-2 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCouponModal(false)}
                  className="flex-1 py-2 text-xs font-semibold text-stone-600 border border-stone-200 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 text-xs font-semibold bg-[#361F13] text-white rounded-xl"
                >
                  Save Coupon
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

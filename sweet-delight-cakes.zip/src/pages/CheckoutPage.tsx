import React, { useState } from 'react';
import { useCart } from '../context/CartContext';
import { useShop } from '../context/ShopContext';
import { useOrder } from '../context/OrderContext';
import { useAuth } from '../context/AuthContext';
import { Breadcrumbs } from '../components/common/Breadcrumbs';
import { SafeImage } from '../components/common/SafeImage';
import { DeliverySlot, PaymentMethod } from '../types';
import {
  ShieldCheck,
  Truck,
  CreditCard,
  QrCode,
  Banknote,
  CheckCircle,
  AlertCircle,
  Clock,
  Moon,
  Calendar,
} from 'lucide-react';

interface CheckoutPageProps {
  onNavigate: (tab: string, params?: Record<string, string>) => void;
  onOrderCompleted: (orderId: string) => void;
}

export const CheckoutPage: React.FC<CheckoutPageProps> = ({
  onNavigate,
  onOrderCompleted,
}) => {
  const {
    items,
    subtotal,
    discountAmount,
    deliveryFee,
    taxAmount,
    grandTotal,
    appliedCoupon,
    clearCart,
  } = useCart();

  const { settings, checkPincodeDelivery } = useShop();
  const { createOrder } = useOrder();
  const { user } = useAuth();

  // Customer Details Form
  const [customerName, setCustomerName] = useState(user?.name || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [email, setEmail] = useState(user?.email || '');
  const defaultAddr = user?.savedAddresses?.[0] || user?.addresses?.[0];
  const [address, setAddress] = useState(
    defaultAddr?.street || `${defaultAddr?.houseFlat || ''} ${defaultAddr?.building || ''}`.trim() || ''
  );
  const [landmark, setLandmark] = useState(defaultAddr?.landmark || '');
  const [city] = useState('Pune');
  const [pincode, setPincode] = useState(defaultAddr?.pincode || '411014');
  const [pincodeValid, setPincodeValid] = useState<boolean | null>(true);

  // Delivery Scheduling
  const todayStr = new Date().toISOString().split('T')[0];
  const [deliveryDate, setDeliveryDate] = useState(todayStr);
  const [deliverySlot, setDeliverySlot] = useState<DeliverySlot>('Evening (3 PM - 7 PM)');
  const [specialInstructions, setSpecialInstructions] = useState('');

  // Payment Selection
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('UPI');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Card details mockup state
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');

  const midnightSurcharge = deliverySlot === 'Midnight (11 PM - 12 AM)' ? 150 : 0;
  const finalPayable = grandTotal + midnightSurcharge;

  const handlePincodeBlur = () => {
    if (!pincode.trim()) {
      setPincodeValid(null);
      return;
    }
    const check = checkPincodeDelivery(pincode.trim());
    setPincodeValid(check.available);
  };

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (items.length === 0) {
      setFormError('Your cart is empty. Please add cakes to place an order.');
      return;
    }

    if (!customerName.trim() || !phone.trim() || !address.trim() || !pincode.trim()) {
      setFormError('Please fill in all required customer and delivery address fields.');
      return;
    }

    if (pincodeValid === false) {
      setFormError('We currently do not deliver to this pincode. Please try an address in Pune.');
      return;
    }

    setIsSubmitting(true);

    // Simulate short processing delay
    setTimeout(() => {
      const newOrder = createOrder({
        customer: {
          name: customerName.trim(),
          phone: phone.trim(),
          email: email.trim() || undefined,
          address: `${address.trim()}${landmark ? `, Near ${landmark.trim()}` : ''}`,
          city,
          pincode: pincode.trim(),
        },
        items: [...items],
        subtotal,
        discount: discountAmount,
        couponCode: appliedCoupon?.code,
        deliveryFee: deliveryFee + midnightSurcharge,
        tax: taxAmount,
        grandTotal: finalPayable,
        paymentMethod,
        paymentStatus: paymentMethod === 'COD' ? 'Pending' : 'Completed',
        deliveryDate,
        deliverySlot,
        specialInstructions: specialInstructions.trim() || undefined,
      });

      clearCart();
      setIsSubmitting(false);
      onOrderCompleted(newOrder.id);
    }, 800);
  };

  if (items.length === 0) {
    return (
      <div className="max-w-2xl mx-auto py-20 px-4 text-center">
        <h2 className="font-serif text-2xl font-bold text-[#361F13] mb-2">No Items In Cart</h2>
        <p className="text-xs text-stone-500 mb-6">
          Your cart is empty. Pick a cake from our bakery catalog to proceed to checkout.
        </p>
        <button
          onClick={() => onNavigate('cakes')}
          className="px-6 py-3 bg-[#361F13] text-white text-xs font-semibold rounded-xl"
        >
          Browse Cakes Catalog
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <Breadcrumbs
        items={[
          { label: 'Cart', tab: 'home' },
          { label: 'Secure Checkout', active: true },
        ]}
        onNavigate={onNavigate}
      />

      <h1 className="font-serif text-3xl font-bold text-[#361F13] mb-8">Secure Checkout</h1>

      {formError && (
        <div className="mb-6 p-4 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-2xl flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{formError}</span>
        </div>
      )}

      <form onSubmit={handleSubmitOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        {/* Left Column: Checkout Forms (7 cols) */}
        <div className="lg:col-span-7 space-y-8">
          {/* Section 1: Customer Contact */}
          <div className="bg-white p-6 sm:p-7 rounded-3xl border border-[#EDE3D6] shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-[#F2EAE0]">
              <span className="w-6 h-6 rounded-full bg-[#361F13] text-white text-xs font-bold flex items-center justify-center">
                1
              </span>
              <h2 className="font-serif text-lg font-bold text-[#361F13]">Customer Details</h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="customer-name" className="text-xs font-semibold text-[#361F13] block mb-1">
                  Recipient / Contact Full Name *
                </label>
                <input
                  id="customer-name"
                  type="text"
                  required
                  placeholder="e.g. Priya Sharma"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
                />
              </div>

              <div>
                <label htmlFor="customer-phone" className="text-xs font-semibold text-[#361F13] block mb-1">
                  Mobile Phone Number *
                </label>
                <input
                  id="customer-phone"
                  type="tel"
                  required
                  placeholder="10-digit mobile number"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/[^0-9+]/g, ''))}
                  className="w-full px-3.5 py-2.5 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
                />
              </div>

              <div className="sm:col-span-2">
                <label htmlFor="customer-email" className="text-xs font-semibold text-[#361F13] block mb-1">
                  Email Address (For Order Updates & Invoice)
                </label>
                <input
                  id="customer-email"
                  type="email"
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Delivery Address & Pincode */}
          <div className="bg-white p-6 sm:p-7 rounded-3xl border border-[#EDE3D6] shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-[#F2EAE0]">
              <span className="w-6 h-6 rounded-full bg-[#361F13] text-white text-xs font-bold flex items-center justify-center">
                2
              </span>
              <h2 className="font-serif text-lg font-bold text-[#361F13]">Delivery Location</h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label htmlFor="delivery-address" className="text-xs font-semibold text-[#361F13] block mb-1">
                  Complete Street Address / Society / Flat No. *
                </label>
                <input
                  id="delivery-address"
                  type="text"
                  required
                  placeholder="Flat 402, Marvel Orchid, Kharadi Main Road"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
                />
              </div>

              <div>
                <label htmlFor="delivery-landmark" className="text-xs font-semibold text-[#361F13] block mb-1">
                  Nearby Landmark (Optional)
                </label>
                <input
                  id="delivery-landmark"
                  type="text"
                  placeholder="Opposite EON Free Zone Gate 2"
                  value={landmark}
                  onChange={(e) => setLandmark(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
                />
              </div>

              <div>
                <label htmlFor="delivery-pincode" className="text-xs font-semibold text-[#361F13] block mb-1">
                  6-Digit Pincode *
                </label>
                <input
                  id="delivery-pincode"
                  type="text"
                  required
                  maxLength={6}
                  placeholder="e.g. 411014"
                  value={pincode}
                  onBlur={handlePincodeBlur}
                  onChange={(e) => {
                    setPincode(e.target.value.replace(/[^0-9]/g, ''));
                    setPincodeValid(null);
                  }}
                  className="w-full px-3.5 py-2.5 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
                />
                {pincodeValid === true && (
                  <p className="text-[11px] text-emerald-700 mt-1 flex items-center gap-1 font-medium">
                    <CheckCircle className="w-3 h-3" /> Delivery service active in this zone
                  </p>
                )}
                {pincodeValid === false && (
                  <p className="text-[11px] text-rose-600 mt-1 flex items-center gap-1 font-medium">
                    <AlertCircle className="w-3 h-3" /> Currently outside our direct delivery zone
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Section 3: Delivery Schedule & Time Slot */}
          <div className="bg-white p-6 sm:p-7 rounded-3xl border border-[#EDE3D6] shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-[#F2EAE0]">
              <span className="w-6 h-6 rounded-full bg-[#361F13] text-white text-xs font-bold flex items-center justify-center">
                3
              </span>
              <h2 className="font-serif text-lg font-bold text-[#361F13]">Delivery Date & Slot</h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="delivery-date" className="text-xs font-semibold text-[#361F13] block mb-1">
                  Choose Delivery Date *
                </label>
                <input
                  id="delivery-date"
                  type="date"
                  min={todayStr}
                  required
                  value={deliveryDate}
                  onChange={(e) => setDeliveryDate(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-[#361F13] block mb-1">
                  Select Preferred Time Slot *
                </label>
                <select
                  value={deliverySlot}
                  onChange={(e) => setDeliverySlot(e.target.value as DeliverySlot)}
                  className="w-full px-3.5 py-2.5 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
                >
                  <option value="Morning (9 AM - 12 PM)">Morning (9 AM – 12 PM)</option>
                  <option value="Afternoon (12 PM - 3 PM)">Afternoon (12 PM – 3 PM)</option>
                  <option value="Evening (3 PM - 7 PM)">Evening (3 PM – 7 PM)</option>
                  <option value="Midnight (11 PM - 12 AM)">Midnight Surprise (11 PM – 12 AM) [+₹150]</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label htmlFor="special-instructions" className="text-xs font-semibold text-[#361F13] block mb-1">
                  Delivery Notes / Gate Code / Call Instructions:
                </label>
                <input
                  id="special-instructions"
                  type="text"
                  placeholder="e.g. Please ring bell twice or leave at security desk"
                  value={specialInstructions}
                  onChange={(e) => setSpecialInstructions(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
                />
              </div>
            </div>
          </div>

          {/* Section 4: Payment Method */}
          <div className="bg-white p-6 sm:p-7 rounded-3xl border border-[#EDE3D6] shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-[#F2EAE0]">
              <span className="w-6 h-6 rounded-full bg-[#361F13] text-white text-xs font-bold flex items-center justify-center">
                4
              </span>
              <h2 className="font-serif text-lg font-bold text-[#361F13]">Payment Method</h2>
            </div>

            <div className="space-y-3">
              {[
                {
                  id: 'UPI',
                  title: 'UPI / Google Pay / PhonePe / Paytm',
                  desc: 'Instant QR code or VPA payment with zero transaction fee',
                  icon: QrCode,
                },
                {
                  id: 'Card',
                  title: 'Credit or Debit Card',
                  desc: 'Visa, MasterCard, RuPay with 256-bit bank encryption',
                  icon: CreditCard,
                },
                {
                  id: 'NetBanking',
                  title: 'Net Banking',
                  desc: 'HDFC, ICICI, SBI, Axis, Kotak and all major Indian banks',
                  icon: ShieldCheck,
                },
                {
                  id: 'COD',
                  title: 'Cash on Delivery (COD)',
                  desc: 'Pay cash or UPI upon cake arrival at your doorstep',
                  icon: Banknote,
                },
              ].map((m) => (
                <label
                  key={m.id}
                  className={`p-3.5 rounded-2xl border flex items-start gap-3 cursor-pointer transition-all ${
                    paymentMethod === m.id
                      ? 'bg-[#FAF0E6] border-[#8C4E28] ring-1 ring-[#8C4E28]'
                      : 'border-stone-200 hover:border-stone-300 bg-white'
                  }`}
                >
                  <input
                    type="radio"
                    name="paymentOption"
                    checked={paymentMethod === m.id}
                    onChange={() => setPaymentMethod(m.id as PaymentMethod)}
                    className="mt-1 text-[#8C4E28] focus:ring-[#8C4E28]"
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <m.icon className="w-4 h-4 text-[#8C4E28]" />
                      <span className="text-xs font-bold text-[#361F13]">{m.title}</span>
                    </div>
                    <p className="text-[11px] text-stone-500 mt-0.5">{m.desc}</p>
                  </div>
                </label>
              ))}
            </div>

            {/* Simulated Card Inputs if Card chosen */}
            {paymentMethod === 'Card' && (
              <div className="mt-4 p-4 rounded-2xl bg-[#FAF7F2] border border-[#E9DFD3] space-y-3 text-xs">
                <div>
                  <label htmlFor="card-number" className="block text-stone-600 mb-1 font-medium">Card Number</label>
                  <input
                    id="card-number"
                    type="text"
                    maxLength={19}
                    placeholder="4111 2222 3333 4444"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#E2D5C7] rounded-xl text-xs"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="card-expiry" className="block text-stone-600 mb-1 font-medium">Expiry MM/YY</label>
                    <input
                      id="card-expiry"
                      type="text"
                      maxLength={5}
                      placeholder="12/28"
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-[#E2D5C7] rounded-xl text-xs"
                    />
                  </div>
                  <div>
                    <label htmlFor="card-cvv" className="block text-stone-600 mb-1 font-medium">CVV</label>
                    <input
                      id="card-cvv"
                      type="password"
                      maxLength={3}
                      placeholder="•••"
                      value={cardCvv}
                      onChange={(e) => setCardCvv(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-[#E2D5C7] rounded-xl text-xs"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Order Summary Sidebar (5 cols) */}
        <div className="lg:col-span-5 sticky top-24 space-y-4">
          <div className="bg-white p-6 rounded-3xl border border-[#EDE3D6] shadow-lg space-y-4">
            <h3 className="font-serif text-lg font-bold text-[#361F13] pb-3 border-b border-[#F2EAE0]">
              Order Summary ({items.length} {items.length === 1 ? 'item' : 'items'})
            </h3>

            {/* Items Mini List */}
            <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
              {items.map((it) => (
                <div key={it.id} className="flex gap-3 text-xs">
                  <SafeImage
                    src={it.image}
                    alt={it.name}
                    className="w-12 h-12 rounded-xl object-cover shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-[#361F13] truncate">{it.name}</p>
                    <p className="text-[11px] text-stone-500">
                      {it.weight} · {it.flavor} {it.eggless ? '(Eggless)' : ''}
                    </p>
                    {it.customMessage && (
                      <p className="text-[10px] text-[#8C4E28] italic truncate">
                        &quot;{it.customMessage}&quot;
                      </p>
                    )}
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-[#361F13] font-mono tabular-nums">
                      {settings.currencySymbol}
                      {it.totalPrice}
                    </span>
                    <span className="text-[10px] text-stone-400 block">Qty: {it.quantity}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Calculations Breakdown */}
            <div className="space-y-2 pt-3 border-t border-[#F2EAE0] text-xs text-[#523B2D]">
              <div className="flex justify-between">
                <span>Items Subtotal</span>
                <span className="font-mono tabular-nums">
                  {settings.currencySymbol}
                  {subtotal}
                </span>
              </div>

              {discountAmount > 0 && (
                <div className="flex justify-between text-emerald-700 font-medium">
                  <span>Coupon Discount</span>
                  <span className="font-mono tabular-nums">
                    -{settings.currencySymbol}
                    {discountAmount}
                  </span>
                </div>
              )}

              <div className="flex justify-between">
                <span>Standard Delivery Fee</span>
                <span className="font-mono tabular-nums">
                  {deliveryFee === 0 ? (
                    <span className="text-emerald-700 font-semibold">FREE</span>
                  ) : (
                    `${settings.currencySymbol}${deliveryFee}`
                  )}
                </span>
              </div>

              {midnightSurcharge > 0 && (
                <div className="flex justify-between text-[#8C4E28]">
                  <span>Midnight Delivery Surcharge</span>
                  <span className="font-mono tabular-nums">
                    +{settings.currencySymbol}
                    {midnightSurcharge}
                  </span>
                </div>
              )}

              <div className="flex justify-between">
                <span>GST ({settings.taxRatePercent}%)</span>
                <span className="font-mono tabular-nums">
                  {settings.currencySymbol}
                  {taxAmount}
                </span>
              </div>

              <div className="flex justify-between pt-3 border-t border-[#EDE3D6] text-base font-bold text-[#361F13]">
                <span>Total Payable</span>
                <span className="font-mono tabular-nums">
                  {settings.currencySymbol}
                  {finalPayable}
                </span>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-4 bg-[#361F13] hover:bg-[#22120A] text-white text-sm font-semibold rounded-2xl shadow-xl flex items-center justify-center gap-2 transition-all disabled:opacity-50"
            >
              <ShieldCheck className="w-4 h-4 text-[#F3C488]" />
              <span>
                {isSubmitting
                  ? 'Confirming Order...'
                  : `Place Order • ${settings.currencySymbol}${finalPayable}`}
              </span>
            </button>

            <p className="text-[11px] text-stone-400 text-center">
              Safe & secure 256-bit encrypted bakery ordering
            </p>
          </div>
        </div>
      </form>
    </div>
  );
};

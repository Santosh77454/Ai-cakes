import React, { useState } from 'react';
import { useCart } from '../context/CartContext';
import { useShop } from '../context/ShopContext';
import { Breadcrumbs } from '../components/common/Breadcrumbs';
import { WeightOption, FlavorOption } from '../types';
import { SafeImage } from '../components/common/SafeImage';
import {
  Cake,
  Heart,
  Square,
  Sparkles,
  ShoppingBag,
  Upload,
  Check,
  CheckCircle2,
  AlertCircle,
  Eye,
} from 'lucide-react';

interface CustomCakePageProps {
  onNavigate: (tab: string) => void;
}

type ShapeOption = 'Round' | 'Square' | 'Heart' | 'Rectangle';

export const CustomCakePage: React.FC<CustomCakePageProps> = ({ onNavigate }) => {
  const { addToCart, openCartDrawer } = useCart();
  const { settings } = useShop();

  // Step 1: Shape
  const [shape, setShape] = useState<ShapeOption>('Round');

  // Step 2: Size
  const [weight, setWeight] = useState<WeightOption>('1kg');

  // Step 3: Flavor
  const [flavor, setFlavor] = useState<FlavorOption>('Chocolate');

  // Step 4: Cream Color/Style
  const creamStyles = [
    { id: 'white', name: 'Pure White Vanilla Cream', colorClass: 'bg-white border-stone-300' },
    { id: 'blush', name: 'Soft Blush Pink Cream', colorClass: 'bg-[#FCEBEB] border-rose-200' },
    { id: 'lavender', name: 'Pastel Lavender Swirls', colorClass: 'bg-[#EFE9F4] border-purple-200' },
    { id: 'ivory', name: 'Warm Ivory Buttercream', colorClass: 'bg-[#FBF8EF] border-amber-200' },
    { id: 'ganache', name: 'Decadent Dark Ganache', colorClass: 'bg-[#361F13] text-white border-[#361F13]' },
    { id: 'mint', name: 'Pistachio Mint Frosting', colorClass: 'bg-[#EBF7EE] border-emerald-200' },
  ];
  const [creamStyle, setCreamStyle] = useState(creamStyles[0].name);

  // Step 5: Decoration Theme
  const decorations = [
    { id: 'berries', name: 'Fresh Seasonal Berries & Botanical Herbs', price: 150 },
    { id: 'gold-macarons', name: '24K Edible Gold Leaf & French Macarons', price: 200 },
    { id: 'choco-drip', name: 'Belgian Chocolate Ganache Drip Waterfall', price: 120 },
    { id: 'pearls', name: 'Artisan Sugar Pearls & Golden Stars', price: 80 },
    { id: 'lambeth', name: 'Vintage Lambeth Ruffle Frill Piping', price: 180 },
    { id: 'minimalist', name: 'Modern Minimalist Smooth Texture', price: 0 },
  ];
  const [selectedDecoration, setSelectedDecoration] = useState(decorations[0]);

  // Step 6: Custom Message & Dietary
  const [message, setMessage] = useState('Happy Birthday!');
  const [isEggless, setIsEggless] = useState(true);

  // Step 7: Reference Image
  const [referenceImage, setReferenceImage] = useState<string | null>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setReferenceImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Price Calculation Engine
  const basePriceByWeight: Record<WeightOption, number> = {
    '500g': 599,
    '1kg': 999,
    '1.5kg': 1449,
    '2kg': 1899,
    '3kg': 2699,
    '5kg': 4299,
  };

  const shapeSurcharge: Record<ShapeOption, number> = {
    Round: 0,
    Square: 50,
    Heart: 100,
    Rectangle: 80,
  };

  const calculatedTotal =
    basePriceByWeight[weight] +
    shapeSurcharge[shape] +
    selectedDecoration.price;

  const handleAddToCart = () => {
    addToCart({
      productId: 'custom-cake-builder',
      name: `Custom ${shape} ${flavor} Cake`,
      image: referenceImage || 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80',
      weight,
      flavor,
      eggless: isEggless,
      customMessage: message.trim() || undefined,
      customPhoto: referenceImage || undefined,
      selectedAddOns: [
        { id: 'addon-decor', name: `Decor: ${selectedDecoration.name}`, price: selectedDecoration.price },
        { id: 'addon-style', name: `Style: ${creamStyle}`, price: 0 },
      ],
      unitPrice: calculatedTotal,
      quantity: 1,
    });
    openCartDrawer();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <Breadcrumbs
        items={[
          { label: 'Cakes', tab: 'cakes' },
          { label: 'Custom Cake Builder', active: true },
        ]}
        onNavigate={onNavigate}
      />

      <div className="text-center max-w-2xl mx-auto mb-10">
        <span className="text-xs font-bold uppercase tracking-wider text-[#8C4E28] block mb-1">
          Interactive Design Studio
        </span>
        <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#361F13]">
          Design Your Own Cake
        </h1>
        <p className="text-xs sm:text-sm text-[#715848] mt-2 leading-relaxed">
          Follow our 7-step builder to craft your customized celebration centerpiece. Our master bakers will bring your vision to life.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        {/* Left Column: 7 Steps (8 cols) */}
        <div className="lg:col-span-8 space-y-8 bg-white p-6 sm:p-8 rounded-3xl border border-[#EDE3D6] shadow-xs">
          {/* Step 1: Shape */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="w-6 h-6 rounded-full bg-[#361F13] text-white text-xs font-bold flex items-center justify-center">
                1
              </span>
              <h3 className="font-serif text-lg font-bold text-[#361F13]">Select Cake Shape</h3>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { name: 'Round', icon: Cake, fee: 0 },
                { name: 'Square', icon: Square, fee: 50 },
                { name: 'Heart', icon: Heart, fee: 100 },
                { name: 'Rectangle', icon: Square, fee: 80 },
              ].map((item) => (
                <button
                  key={item.name}
                  onClick={() => setShape(item.name as ShapeOption)}
                  className={`p-4 rounded-2xl border text-center flex flex-col items-center gap-2 transition-all ${
                    shape === item.name
                      ? 'bg-[#FAF0E6] border-[#8C4E28] text-[#361F13] shadow-xs ring-1 ring-[#8C4E28]'
                      : 'border-stone-200 hover:border-stone-400 text-stone-700'
                  }`}
                >
                  <item.icon className="w-6 h-6 text-[#8C4E28]" />
                  <span className="text-xs font-bold">{item.name}</span>
                  <span className="text-[10px] text-stone-500">
                    {item.fee === 0 ? 'Standard' : `+₹${item.fee}`}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Step 2: Size */}
          <div className="pt-6 border-t border-[#F2EAE0]">
            <div className="flex items-center gap-2 mb-3">
              <span className="w-6 h-6 rounded-full bg-[#361F13] text-white text-xs font-bold flex items-center justify-center">
                2
              </span>
              <h3 className="font-serif text-lg font-bold text-[#361F13]">Select Weight / Size</h3>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
              {(['500g', '1kg', '1.5kg', '2kg', '3kg', '5kg'] as WeightOption[]).map((wt) => (
                <button
                  key={wt}
                  onClick={() => setWeight(wt)}
                  className={`py-3 px-2 rounded-xl text-xs font-semibold border flex flex-col items-center gap-1 transition-all ${
                    weight === wt
                      ? 'bg-[#361F13] text-white border-[#361F13] shadow-xs'
                      : 'border-stone-200 hover:border-stone-400 text-stone-700'
                  }`}
                >
                  <span>{wt}</span>
                  <span className={`text-[10px] font-mono ${weight === wt ? 'text-[#F3C488]' : 'text-stone-500'}`}>
                    ₹{basePriceByWeight[wt]}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Step 3: Flavor */}
          <div className="pt-6 border-t border-[#F2EAE0]">
            <div className="flex items-center gap-2 mb-3">
              <span className="w-6 h-6 rounded-full bg-[#361F13] text-white text-xs font-bold flex items-center justify-center">
                3
              </span>
              <h3 className="font-serif text-lg font-bold text-[#361F13]">Choose Sponge Flavor</h3>
            </div>
            <div className="flex flex-wrap gap-2">
              {[
                'Chocolate',
                'Vanilla',
                'Strawberry',
                'Red Velvet',
                'Butterscotch',
                'Black Forest',
                'Pineapple',
                'Mango',
                'Coffee Mousse',
                'Pistachio Rose',
              ].map((flv) => (
                <button
                  key={flv}
                  onClick={() => setFlavor(flv as FlavorOption)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-medium border transition-colors ${
                    flavor === flv
                      ? 'bg-[#8C4E28] text-white border-[#8C4E28] shadow-xs'
                      : 'border-stone-200 hover:border-stone-400 text-stone-700'
                  }`}
                >
                  {flv}
                </button>
              ))}
            </div>
          </div>

          {/* Step 4: Cream Color / Style */}
          <div className="pt-6 border-t border-[#F2EAE0]">
            <div className="flex items-center gap-2 mb-3">
              <span className="w-6 h-6 rounded-full bg-[#361F13] text-white text-xs font-bold flex items-center justify-center">
                4
              </span>
              <h3 className="font-serif text-lg font-bold text-[#361F13]">Select Cream Color & Style</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {creamStyles.map((cs) => (
                <button
                  key={cs.id}
                  onClick={() => setCreamStyle(cs.name)}
                  className={`p-3 rounded-xl border flex items-center justify-between text-xs text-left transition-all ${
                    creamStyle === cs.name
                      ? 'bg-[#FAF0E6] border-[#8C4E28] text-[#361F13] font-semibold'
                      : 'border-stone-200 hover:border-stone-400 text-stone-700'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <span className={`w-5 h-5 rounded-full border shadow-2xs ${cs.colorClass}`} />
                    <span>{cs.name}</span>
                  </div>
                  {creamStyle === cs.name && <Check className="w-4 h-4 text-[#8C4E28]" />}
                </button>
              ))}
            </div>
          </div>

          {/* Step 5: Decoration */}
          <div className="pt-6 border-t border-[#F2EAE0]">
            <div className="flex items-center gap-2 mb-3">
              <span className="w-6 h-6 rounded-full bg-[#361F13] text-white text-xs font-bold flex items-center justify-center">
                5
              </span>
              <h3 className="font-serif text-lg font-bold text-[#361F13]">Select Handcrafted Decoration</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {decorations.map((dec) => (
                <button
                  key={dec.id}
                  onClick={() => setSelectedDecoration(dec)}
                  className={`p-3 rounded-xl border flex items-center justify-between text-xs text-left transition-all ${
                    selectedDecoration.id === dec.id
                      ? 'bg-[#FAF0E6] border-[#8C4E28] text-[#361F13] font-semibold'
                      : 'border-stone-200 hover:border-stone-400 text-stone-700'
                  }`}
                >
                  <span className="truncate max-w-[200px]">{dec.name}</span>
                  <span className="font-mono text-[#8C4E28] shrink-0 ml-2">
                    {dec.price === 0 ? 'Included' : `+₹${dec.price}`}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Step 6: Custom Message & Dietary */}
          <div className="pt-6 border-t border-[#F2EAE0] space-y-4">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[#361F13] text-white text-xs font-bold flex items-center justify-center">
                6
              </span>
              <h3 className="font-serif text-lg font-bold text-[#361F13]">Custom Message & Dietary</h3>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <label htmlFor="custom-cake-message" className="text-xs font-semibold text-[#361F13]">Piped Message on Cake:</label>
                <span className="text-[11px] text-stone-400">{message.length}/35 chars</span>
              </div>
              <input
                id="custom-cake-message"
                type="text"
                maxLength={35}
                placeholder="e.g. Happy 10th Anniversary Priya & Rahul!"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
              />
            </div>

            <div className="flex gap-4">
              <label className="flex items-center gap-2 text-xs font-semibold text-[#361F13] cursor-pointer">
                <input
                  type="radio"
                  name="customEggless"
                  checked={isEggless}
                  onChange={() => setIsEggless(true)}
                  className="text-emerald-700 focus:ring-emerald-700"
                />
                <span className="text-emerald-700 font-bold">100% Eggless (Vegetarian)</span>
              </label>

              <label className="flex items-center gap-2 text-xs font-semibold text-[#361F13] cursor-pointer">
                <input
                  type="radio"
                  name="customEggless"
                  checked={!isEggless}
                  onChange={() => setIsEggless(false)}
                  className="text-amber-800 focus:ring-amber-800"
                />
                <span>With Egg</span>
              </label>
            </div>
          </div>

          {/* Step 7: Upload Reference Image */}
          <div className="pt-6 border-t border-[#F2EAE0]">
            <div className="flex items-center gap-2 mb-3">
              <span className="w-6 h-6 rounded-full bg-[#361F13] text-white text-xs font-bold flex items-center justify-center">
                7
              </span>
              <h3 className="font-serif text-lg font-bold text-[#361F13]">Upload Reference Photo (Optional)</h3>
            </div>
            <p className="text-xs text-stone-500 mb-3">
              Have a Pinterest photo or sketch? Upload a clear JPG or PNG image. Our head decorator will follow your layout.
            </p>

            <div className="flex items-center gap-4">
              <label className="cursor-pointer px-4 py-2.5 bg-[#FAF7F2] hover:bg-[#F3ECE1] border border-[#D8C7B4] rounded-xl text-xs font-semibold text-[#361F13] flex items-center gap-2 transition-colors">
                <Upload className="w-4 h-4 text-[#8C4E28]" />
                <span>Upload Image</span>
                <input
                  type="file"
                  accept="image/png, image/jpeg"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </label>

              {referenceImage && (
                <div className="flex items-center gap-2">
                  <img
                    src={referenceImage}
                    alt="Uploaded Reference"
                    className="w-12 h-12 rounded-lg object-cover border border-stone-300"
                  />
                  <button
                    onClick={() => setReferenceImage(null)}
                    className="text-xs text-rose-600 hover:underline"
                  >
                    Remove
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Live Summary Card (4 cols) */}
        <div className="lg:col-span-4 sticky top-24">
          <div className="bg-white p-6 rounded-3xl border border-[#EDE3D6] shadow-lg space-y-6">
            <div className="border-b border-[#F2EAE0] pb-4">
              <span className="text-xs font-bold uppercase tracking-wider text-[#8C4E28] block mb-1">
                Live Specification
              </span>
              <h3 className="font-serif text-xl font-bold text-[#361F13]">Your Custom Cake</h3>
            </div>

            <div className="space-y-3 text-xs text-[#523B2D]">
              <div className="flex justify-between py-1 border-b border-stone-100">
                <span className="text-stone-400">Shape</span>
                <span className="font-semibold text-[#361F13]">{shape}</span>
              </div>

              <div className="flex justify-between py-1 border-b border-stone-100">
                <span className="text-stone-400">Size / Weight</span>
                <span className="font-semibold text-[#361F13]">{weight}</span>
              </div>

              <div className="flex justify-between py-1 border-b border-stone-100">
                <span className="text-stone-400">Flavor</span>
                <span className="font-semibold text-[#361F13]">{flavor}</span>
              </div>

              <div className="flex justify-between py-1 border-b border-stone-100">
                <span className="text-stone-400">Cream Style</span>
                <span className="font-semibold text-[#361F13] truncate max-w-[170px]">{creamStyle}</span>
              </div>

              <div className="flex justify-between py-1 border-b border-stone-100">
                <span className="text-stone-400">Decoration</span>
                <span className="font-semibold text-[#361F13] truncate max-w-[170px]">{selectedDecoration.name}</span>
              </div>

              <div className="flex justify-between py-1 border-b border-stone-100">
                <span className="text-stone-400">Dietary</span>
                <span className={`font-semibold ${isEggless ? 'text-emerald-700' : 'text-stone-800'}`}>
                  {isEggless ? '100% Eggless' : 'With Egg'}
                </span>
              </div>

              {message && (
                <div className="py-1">
                  <span className="text-stone-400 block mb-0.5">Message:</span>
                  <span className="italic text-[#8C4E28] font-medium block bg-[#FAF7F2] p-2 rounded-lg border border-[#EDE3D6]">
                    &quot;{message}&quot;
                  </span>
                </div>
              )}

              {referenceImage && (
                <div className="py-1 flex items-center justify-between">
                  <span className="text-stone-400">Reference Photo</span>
                  <span className="text-emerald-700 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Attached
                  </span>
                </div>
              )}
            </div>

            {/* Estimated Price */}
            <div className="p-4 rounded-2xl bg-[#FAF0E6] border border-[#E8DDD1]">
              <span className="text-xs text-stone-500 block mb-0.5">Estimated Price:</span>
              <div className="font-mono text-3xl font-bold text-[#361F13]">
                {settings.currencySymbol}
                {calculatedTotal}
              </div>
              <span className="text-[11px] text-[#8C4E28]">Includes all chosen toppings and custom piping</span>
            </div>

            <button
              onClick={handleAddToCart}
              className="w-full py-3.5 bg-[#361F13] hover:bg-[#22120A] text-white text-sm font-semibold rounded-2xl shadow-xl flex items-center justify-center gap-2 transition-all group"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Add Custom Cake to Cart</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

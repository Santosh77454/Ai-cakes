import React, { useState } from 'react';
import { BLOG_POSTS } from '../data/blogs';
import { Breadcrumbs } from '../components/common/Breadcrumbs';
import { SafeImage } from '../components/common/SafeImage';
import { Clock, Calendar, User, ArrowLeft, ArrowRight, Cake } from 'lucide-react';

interface BlogPageProps {
  initialPostId?: string;
  onNavigate: (tab: string) => void;
}

export const BlogPage: React.FC<BlogPageProps> = ({ initialPostId, onNavigate }) => {
  const [selectedPostId, setSelectedPostId] = useState<string | null>(initialPostId || null);

  const activePost = selectedPostId
    ? BLOG_POSTS.find((p) => p.id === selectedPostId)
    : null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <Breadcrumbs
        items={[
          { label: 'Home', tab: 'home' },
          { label: 'Cake Journal & Guides', tab: 'blog' },
          ...(activePost ? [{ label: activePost.title, active: true }] : []),
        ]}
        onNavigate={onNavigate}
      />

      {activePost ? (
        /* Single Post View */
        <article className="max-w-3xl mx-auto bg-white p-6 sm:p-10 rounded-3xl border border-[#EDE3D6] shadow-xs">
          <button
            onClick={() => setSelectedPostId(null)}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#8C4E28] hover:text-[#361F13] mb-6 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to All Articles</span>
          </button>

          <span className="text-xs font-bold uppercase tracking-wider text-[#8C4E28] bg-[#FAF0E6] px-3 py-1 rounded-full">
            {activePost.category}
          </span>

          <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#361F13] mt-3 leading-tight">
            {activePost.title}
          </h1>

          <div className="flex items-center gap-4 text-xs text-stone-500 mt-4 pb-6 border-b border-[#F2EAE0]">
            <span className="flex items-center gap-1">
              <User className="w-3.5 h-3.5 text-stone-400" />
              {activePost.author}
            </span>
            <span>·</span>
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-stone-400" />
              {activePost.publishedDate}
            </span>
            <span>·</span>
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-stone-400" />
              {activePost.readTime}
            </span>
          </div>

          <div className="aspect-16/9 rounded-2xl overflow-hidden my-6 bg-stone-100">
            <SafeImage
              src={activePost.coverImage}
              alt={activePost.title}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="prose prose-stone max-w-none text-sm text-[#4A3225] leading-relaxed whitespace-pre-line space-y-4">
            {activePost.content}
          </div>

          <div className="mt-10 p-6 rounded-2xl bg-[#FAF7F2] border border-[#EDE3D6] flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <h4 className="font-serif text-base font-bold text-[#361F13]">
                Inspired to celebrate?
              </h4>
              <p className="text-xs text-stone-500">
                Explore our catalog of freshly baked cakes delivered anywhere in Pune.
              </p>
            </div>
            <button
              onClick={() => onNavigate('cakes')}
              className="px-5 py-2.5 bg-[#361F13] text-white text-xs font-semibold rounded-xl shrink-0"
            >
              Shop All Cakes
            </button>
          </div>
        </article>
      ) : (
        /* All Posts Grid */
        <div>
          <div className="text-center max-w-xl mx-auto mb-10">
            <span className="text-xs font-bold uppercase tracking-wider text-[#8C4E28] block mb-1">
              Bakery Journal
            </span>
            <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#361F13]">
              Cake Ideas & Expert Guides
            </h1>
            <p className="text-xs sm:text-sm text-[#715848] mt-2">
              Tips on pairing flavors, cake sizing guidelines, celebration setups, and the science of artisan baking.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {BLOG_POSTS.map((post) => (
              <div
                key={post.id}
                onClick={() => setSelectedPostId(post.id)}
                className="bg-white rounded-3xl border border-[#EDE3D6] overflow-hidden hover:shadow-lg transition-all duration-300 cursor-pointer flex flex-col group"
              >
                <div className="aspect-16/9 overflow-hidden bg-stone-100">
                  <SafeImage
                    src={post.coverImage}
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-2 text-[11px] text-[#8C4E28] font-semibold uppercase tracking-wider mb-2">
                      <span>{post.category}</span>
                      <span>·</span>
                      <span>{post.readTime}</span>
                    </div>
                    <h3 className="font-serif text-lg font-bold text-[#361F13] group-hover:text-[#8C4E28] transition-colors line-clamp-2">
                      {post.title}
                    </h3>
                    <p className="text-xs text-[#715848] mt-2 line-clamp-3 leading-relaxed">
                      {post.excerpt}
                    </p>
                  </div>

                  <div className="mt-5 pt-3 border-t border-[#F2EAE0] flex items-center justify-between text-xs text-stone-400">
                    <span>{post.publishedDate}</span>
                    <span className="text-[#8C4E28] font-semibold group-hover:underline flex items-center gap-1">
                      Read Full Story <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

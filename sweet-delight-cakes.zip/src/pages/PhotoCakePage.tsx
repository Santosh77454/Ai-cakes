import React, { useState } from 'react';
import { useCart } from '../context/CartContext';
import { useShop } from '../context/ShopContext';
import { Breadcrumbs } from '../components/common/Breadcrumbs';
import { WeightOption, FlavorOption } from '../types';
import { SafeImage } from '../components/common/SafeImage';
import { Upload, ShoppingBag, CheckCircle, Sparkles, Image as ImageIcon } from 'lucide-react';

interface PhotoCakePageProps {
  onNavigate: (tab: string) => void;
}

export const PhotoCakePage: React.FC<PhotoCakePageProps> = ({ onNavigate }) => {
  const { addToCart, openCartDrawer } = useCart();
  const { settings } = useShop();

  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [cakeMessage, setCakeMessage] = useState('Happy Birthday Princess!');
  const [selectedWeight, setSelectedWeight] = useState<WeightOption>('1kg');
  const [selectedFlavor, setSelectedFlavor] = useState<FlavorOption>('Chocolate');
  const [isEggless, setIsEggless] = useState<boolean>(true);

  const priceByWeight: Record<string, number> = {
    '1kg': 999,
    '1.5kg': 1499,
    '2kg': 1999,
    '3kg': 2899,
  };

  const calculatedPrice = priceByWeight[selectedWeight] || 999;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddToCart = () => {
    addToCart({
      productId: 'cake-008',
      name: `Edible Photo Cake (${selectedFlavor})`,
      image: uploadedImage || 'https://images.unsplash.com/photo-1558301211-0d8c8ddee6ec?auto=format&fit=crop&w=800&q=80',
      weight: selectedWeight,
      flavor: selectedFlavor,
      eggless: isEggless,
      customMessage: cakeMessage.trim() || undefined,
      customPhoto: uploadedImage || undefined,
      selectedAddOns: [],
      unitPrice: calculatedPrice,
      quantity: 1,
    });
    openCartDrawer();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <Breadcrumbs
        items={[
          { label: 'Cakes', tab: 'cakes' },
          { label: 'Edible Photo Cake', active: true },
        ]}
        onNavigate={onNavigate}
      />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        {/* Left Column: Interactive Photo Cake Frame Mockup (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white p-6 rounded-3xl border border-[#EDE3D6] shadow-md flex flex-col items-center">
            <span className="text-xs font-bold uppercase tracking-wider text-[#8C4E28] mb-3">
              Live Edible Print Preview
            </span>

            {/* Circular Cake Visual with Sugar Print in Center */}
            <div className="relative w-64 h-64 sm:w-72 sm:h-72 rounded-full border-8 border-[#F5ECE1] shadow-xl overflow-hidden bg-gradient-to-br from-[#FAF0E6] to-[#FFFDF9] flex items-center justify-center p-6">
              {uploadedImage ? (
                <div className="relative w-full h-full rounded-full overflow-hidden border-2 border-dashed border-[#8C4E28]/40 shadow-inner">
                  <img
                    src={uploadedImage}
                    alt="Edible Print Preview"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent flex items-end justify-center pb-3">
                    <span className="text-white text-xs font-bold drop-shadow-md text-center px-2">
                      {cakeMessage}
                    </span>
                  </div>
                </div>
              ) : (
                <label className="cursor-pointer text-center flex flex-col items-center justify-center p-4">
                  <div className="w-12 h-12 rounded-full bg-[#FAF0E6] text-[#8C4E28] flex items-center justify-center mb-2">
                    <ImageIcon className="w-6 h-6" />
                  </div>
                  <span className="text-xs font-bold text-[#361F13] block">
                    Upload Your Photo Here
                  </span>
                  <span className="text-[10px] text-stone-500 mt-1">
                    Upload a clear JPG or PNG image.
                  </span>
                  <input
                    type="file"
                    accept="image/png, image/jpeg"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </label>
              )}
            </div>

            {uploadedImage && (
              <div className="mt-4 flex gap-3">
                <label className="cursor-pointer text-xs text-[#8C4E28] font-semibold hover:underline">
                  Replace Photo
                  <input
                    type="file"
                    accept="image/png, image/jpeg"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </label>
                <button
                  onClick={() => setUploadedImage(null)}
                  className="text-xs text-rose-600 hover:underline"
                >
                  Remove
                </button>
              </div>
            )}
          </div>

          <div className="bg-[#FAF0E6] p-4 rounded-2xl border border-[#E9DFD3] text-xs text-[#523B2D] space-y-1.5">
            <span className="font-bold block text-[#361F13]">Certified Food-Grade Technology:</span>
            <p>
              Printed on 100% vegetarian, edible sugar icing sheets using certified organic vegetable ink. Does not alter cake flavor or texture!
            </p>
          </div>
        </div>

        {/* Right Column: Options & Controls (7 cols) */}
        <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-[#EDE3D6] shadow-xs space-y-6">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-[#8C4E28]">
              Cherish Memories
            </span>
            <h1 className="font-serif text-3xl font-bold text-[#361F13] mt-1">
              Personalized Edible Photo Cake
            </h1>
            <p className="text-xs sm:text-sm text-[#715848] mt-2">
              Transform your favorite photos into delicious, edible celebration centerpieces.
            </p>

            <div className="mt-4 p-4 rounded-2xl bg-[#FAF7F2] border border-[#EDE3D6] flex items-baseline justify-between">
              <div>
                <span className="text-xs text-stone-400">Total Price:</span>
                <div className="font-mono text-3xl font-bold text-[#361F13]">
                  {settings.currencySymbol}
                  {calculatedPrice}
                </div>
              </div>
              <span className="text-xs text-emerald-700 font-semibold bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
                Sugar Sheet Included
              </span>
            </div>
          </div>

          {/* Size */}
          <div className="space-y-2 pt-2 border-t border-[#F2EAE0]">
            <label className="text-xs font-bold uppercase tracking-wider text-[#361F13] block">
              1. Select Weight / Size (Minimum 1kg for Photo Clarity):
            </label>
            <div className="grid grid-cols-4 gap-2">
              {(['1kg', '1.5kg', '2kg', '3kg'] as WeightOption[]).map((wt) => (
                <button
                  key={wt}
                  onClick={() => setSelectedWeight(wt)}
                  className={`py-2 px-1 rounded-xl text-xs font-semibold border flex flex-col items-center gap-0.5 transition-all ${
                    selectedWeight === wt
                      ? 'bg-[#361F13] text-white border-[#361F13] shadow-xs'
                      : 'border-stone-200 hover:border-stone-400 text-stone-700'
                  }`}
                >
                  <span>{wt}</span>
                  <span className={`text-[10px] font-mono ${selectedWeight === wt ? 'text-[#F3C488]' : 'text-stone-500'}`}>
                    ₹{priceByWeight[wt]}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Flavor */}
          <div className="space-y-2 pt-2 border-t border-[#F2EAE0]">
            <label className="text-xs font-bold uppercase tracking-wider text-[#361F13] block">
              2. Select Sponge Base Flavor:
            </label>
            <div className="flex flex-wrap gap-2">
              {['Chocolate', 'Vanilla', 'Butterscotch', 'Pineapple', 'Black Forest'].map((flv) => (
                <button
                  key={flv}
                  onClick={() => setSelectedFlavor(flv as FlavorOption)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-medium border transition-colors ${
                    selectedFlavor === flv
                      ? 'bg-[#8C4E28] text-white border-[#8C4E28]'
                      : 'border-stone-200 hover:border-stone-400 text-stone-700'
                  }`}
                >
                  {flv}
                </button>
              ))}
            </div>
          </div>

          {/* Dietary */}
          <div className="space-y-2 pt-2 border-t border-[#F2EAE0]">
            <label className="text-xs font-bold uppercase tracking-wider text-[#361F13] block">
              3. Dietary Choice:
            </label>
            <div className="grid grid-cols-2 gap-3 max-w-sm">
              <button
                onClick={() => setIsEggless(true)}
                className={`py-2 px-3 rounded-xl text-xs font-semibold border flex items-center justify-center gap-2 ${
                  isEggless ? 'bg-emerald-700 text-white' : 'border-stone-200 text-stone-700'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                <span>100% Eggless</span>
              </button>
              <button
                onClick={() => setIsEggless(false)}
                className={`py-2 px-3 rounded-xl text-xs font-semibold border flex items-center justify-center gap-2 ${
                  !isEggless ? 'bg-amber-800 text-white' : 'border-stone-200 text-stone-700'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                <span>Contains Egg</span>
              </button>
            </div>
          </div>

          {/* Message */}
          <div className="space-y-2 pt-2 border-t border-[#F2EAE0]">
            <div className="flex justify-between items-center">
              <label htmlFor="photo-cake-message" className="text-xs font-bold uppercase tracking-wider text-[#361F13]">
                4. Custom Message To Be Printed On Cake:
              </label>
              <span className="text-[11px] text-stone-400">{cakeMessage.length}/35 chars</span>
            </div>
            <input
              id="photo-cake-message"
              type="text"
              maxLength={35}
              placeholder="e.g. Happy 5th Birthday Rahul!"
              value={cakeMessage}
              onChange={(e) => setCakeMessage(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
            />
          </div>

          {/* Button */}
          <div className="pt-4 border-t border-[#F2EAE0]">
            <button
              onClick={handleAddToCart}
              className="w-full py-4 bg-[#361F13] hover:bg-[#22120A] text-white text-sm font-semibold rounded-2xl shadow-xl flex items-center justify-center gap-2 transition-all"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>
                Add Photo Cake to Cart • {settings.currencySymbol}
                {calculatedPrice}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

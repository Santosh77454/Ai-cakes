import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { ProductCard } from '../components/products/ProductCard';
import { CategoryCard } from '../components/products/CategoryCard';
import { QuickViewModal } from '../components/products/QuickViewModal';
import { PincodeChecker } from '../components/common/PincodeChecker';
import { SafeImage } from '../components/common/SafeImage';
import { Product } from '../types';
import { FAQS } from '../data/faqs';
import { BLOG_POSTS } from '../data/blogs';
import {
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Truck,
  Heart,
  ChefHat,
  Star,
  ChevronDown,
  ChevronUp,
  Clock,
  Cake,
  Quote,
} from 'lucide-react';

interface HomePageProps {
  onNavigate: (tab: string, params?: Record<string, string>) => void;
  onOpenQuickView: (product: Product) => void;
  onSelectProduct: (productId: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onNavigate,
  onOpenQuickView,
  onSelectProduct,
}) => {
  const { products, categories, reviews, settings, recentlyViewed } = useShop();

  const [activeFaqId, setActiveFaqId] = useState<string | null>('faq-1');
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);

  const bestSellers = products.filter((p) => p.bestseller).slice(0, 8);
  const newArrivals = products.filter((p) => p.newArrival).slice(0, 4);

  const occasions = [
    { label: 'Birthday', icon: '🎂', query: 'Birthday' },
    { label: 'Anniversary', icon: '❤️', query: 'Anniversary' },
    { label: 'Wedding', icon: '💍', query: 'Wedding' },
    { label: 'Baby Shower', icon: '👶', query: 'Baby Shower' },
    { label: 'Engagement', icon: '💕', query: 'Engagement' },
    { label: 'Farewell', icon: '🎉', query: 'Farewell' },
    { label: 'Congratulations', icon: '🎊', query: 'Congratulations' },
    { label: 'Festival', icon: '✨', query: 'Festivals' },
  ];

  return (
    <div className="space-y-20 pb-16">
      {/* 1. Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-[#FAF7F2] via-[#FFFDF9] to-[#FAF7F2] pt-6 sm:pt-12 pb-16 border-b border-[#EDE3D6]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Column */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#F5ECE1] border border-[#E8DC CE] rounded-full text-xs font-semibold text-[#8C4E28] tracking-wider uppercase">
                <Sparkles className="w-3.5 h-3.5 text-[#C2872A]" />
                <span>FRESHLY BAKED • PREMIUM QUALITY</span>
              </div>

              <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold text-[#361F13] tracking-tight leading-[1.15] text-balance">
                Celebrate Every Moment with a{' '}
                <span className="text-[#8C4E28] italic underline decoration-[#F3C488]/70 decoration-wavy decoration-2">
                  Perfect Cake
                </span>
              </h1>

              <p className="text-base sm:text-lg text-[#5C4537] leading-relaxed max-w-xl">
                Delicious, freshly baked cakes made with Belgian chocolate, pure dairy cream, and 100% vegetarian options crafted especially for your sweetest celebrations.
              </p>

              {/* CTAs */}
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  onClick={() => onNavigate('cakes')}
                  className="px-7 py-3.5 bg-[#361F13] hover:bg-[#22120A] text-white text-sm font-semibold rounded-2xl shadow-lg hover:shadow-xl transition-all flex items-center gap-2 group"
                >
                  <span>Shop All Cakes</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>

                <button
                  onClick={() => onNavigate('custom-cake')}
                  className="px-7 py-3.5 bg-white hover:bg-[#FAF7F2] text-[#361F13] text-sm font-semibold rounded-2xl border border-[#D8C7B4] shadow-xs hover:border-[#8C4E28] transition-all flex items-center gap-2"
                >
                  <Cake className="w-4 h-4 text-[#8C4E28]" />
                  <span>Customize Your Cake</span>
                </button>
              </div>

              {/* Trust markers */}
              <div className="pt-6 border-t border-[#EBE1D4] grid grid-cols-3 gap-4">
                <div>
                  <span className="font-serif text-2xl font-bold text-[#361F13]">15,000+</span>
                  <p className="text-xs text-[#715848] mt-0.5">Celebrations Made Sweet</p>
                </div>
                <div>
                  <span className="font-serif text-2xl font-bold text-[#361F13]">4.9 / 5.0</span>
                  <p className="text-xs text-[#715848] mt-0.5">Customer Rating</p>
                </div>
                <div>
                  <span className="font-serif text-2xl font-bold text-[#361F13]">Same-Day</span>
                  <p className="text-xs text-[#715848] mt-0.5">Fresh Oven Delivery</p>
                </div>
              </div>
            </div>

            {/* Right Column: Hero Visual + Floating Badges */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-md lg:max-w-none">
                {/* Main Hero Cake Image */}
                <div className="aspect-4/3 sm:aspect-square rounded-3xl overflow-hidden shadow-2xl border-4 border-white bg-white">
                  <SafeImage
                    src="https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=1000&q=80"
                    alt="Signature Belgian Chocolate Truffle Cake"
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Floating Card 1: Freshly Baked */}
                <div className="absolute -top-4 -left-4 bg-white/95 backdrop-blur-md p-3 rounded-2xl shadow-lg border border-[#EDE3D6] flex items-center gap-3 hidden sm:flex">
                  <div className="w-10 h-10 rounded-xl bg-[#FAF0E6] text-[#8C4E28] flex items-center justify-center">
                    <ChefHat className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-[#361F13] block">Freshly Baked</span>
                    <span className="text-[10px] text-stone-500">Baked to order every morning</span>
                  </div>
                </div>

                {/* Floating Card 2: 100% Quality Ingredients */}
                <div className="absolute -bottom-5 -right-4 bg-white/95 backdrop-blur-md p-3.5 rounded-2xl shadow-lg border border-[#EDE3D6] flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-[#361F13] block">100% Quality Ingredients</span>
                    <span className="text-[10px] text-stone-500">Pure butter, Belgian chocolate</span>
                  </div>
                </div>

                {/* Floating Card 3: Same-Day Delivery */}
                <div className="absolute top-1/2 -right-6 -translate-y-1/2 bg-white/95 backdrop-blur-md p-2.5 rounded-xl shadow-md border border-[#EDE3D6] hidden md:flex items-center gap-2">
                  <Truck className="w-4 h-4 text-[#8C4E28]" />
                  <span className="text-xs font-semibold text-[#361F13]">Same-Day Delivery</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Shop By Category Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-[#8C4E28] block mb-1">
              Curated Collections
            </span>
            <h2 className="font-serif text-3xl font-bold text-[#361F13]">Shop By Category</h2>
            <p className="text-xs text-[#715848] mt-1">
              From birthday centerpieces to delicate afternoon tea pastries
            </p>
          </div>
          <button
            onClick={() => onNavigate('cakes')}
            className="text-xs font-semibold text-[#8C4E28] hover:text-[#361F13] flex items-center gap-1 group self-start sm:self-auto"
          >
            <span>View All Categories</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {categories.map((cat) => (
            <CategoryCard
              key={cat.id}
              category={cat}
              onClick={(name) => onNavigate('cakes', { category: name })}
            />
          ))}
        </div>
      </section>

      {/* 3. Occasion Bar */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#FAF0E6] rounded-3xl p-6 sm:p-8 border border-[#E9DFD3]">
          <div className="text-center max-w-xl mx-auto mb-6">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#8C4E28] block mb-1">
              Find Your Match
            </span>
            <h3 className="font-serif text-2xl font-bold text-[#361F13]">
              Find the Perfect Cake for Every Occasion
            </h3>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2.5">
            {occasions.map((occ) => (
              <button
                key={occ.label}
                onClick={() => onNavigate('cakes', { occasion: occ.query })}
                className="p-3 bg-white hover:bg-[#361F13] hover:text-white rounded-2xl border border-[#E2D5C7] text-center transition-all group flex flex-col items-center gap-1.5 shadow-2xs hover:shadow-md"
              >
                <span className="text-2xl group-hover:scale-110 transition-transform">
                  {occ.icon}
                </span>
                <span className="text-xs font-semibold text-[#361F13] group-hover:text-white">
                  {occ.label}
                </span>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* 4. Best Selling Cakes Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-[#8C4E28] block mb-1">
              Customer Favorites
            </span>
            <h2 className="font-serif text-3xl font-bold text-[#361F13]">Our Best Sellers</h2>
            <p className="text-xs text-[#715848] mt-1">
              Handpicked customer favourites baked fresh every single morning
            </p>
          </div>
          <button
            onClick={() => onNavigate('cakes')}
            className="text-xs font-semibold text-[#8C4E28] hover:text-[#361F13] flex items-center gap-1 group"
          >
            <span>See All Best Sellers</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {bestSellers.map((cake) => (
            <ProductCard
              key={cake.id}
              product={cake}
              onOpenDetails={onSelectProduct}
              onOpenQuickView={(prod) => setQuickViewProduct(prod)}
            />
          ))}
        </div>
      </section>

      {/* 5. Interactive Banner: Custom Cake Builder & Photo Cake Showcase */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Custom Cake Builder Card */}
          <div className="bg-[#361F13] text-[#FAF7F2] rounded-3xl p-8 sm:p-10 relative overflow-hidden flex flex-col justify-between shadow-xl">
            <div className="relative z-10 space-y-4">
              <span className="text-xs font-bold uppercase tracking-wider text-[#F3C488] bg-white/10 px-3 py-1 rounded-full">
                Interactive Studio
              </span>
              <h3 className="font-serif text-3xl font-bold text-white leading-snug">
                Design Your Own Dream Cake
              </h3>
              <p className="text-xs sm:text-sm text-[#D8C7B4] leading-relaxed max-w-sm">
                Pick your preferred shape, tier size, gourmet sponge flavour, cream palette, and handcrafted decorations. Watch your live price update instantly.
              </p>
            </div>
            <div className="relative z-10 pt-8">
              <button
                onClick={() => onNavigate('custom-cake')}
                className="px-6 py-3 bg-[#F3C488] hover:bg-[#E5B576] text-[#2D1B11] text-xs font-bold rounded-xl transition-colors shadow-md flex items-center gap-2"
              >
                <span>Launch Custom Cake Builder</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
            <div className="absolute -bottom-8 -right-8 w-48 h-48 rounded-full bg-[#8C4E28]/20 blur-2xl pointer-events-none" />
          </div>

          {/* Photo Cake Card */}
          <div className="bg-gradient-to-br from-[#FAF0E6] to-[#FFF8EE] text-[#361F13] rounded-3xl p-8 sm:p-10 relative overflow-hidden flex flex-col justify-between border border-[#E9DFD3] shadow-md">
            <div className="relative z-10 space-y-4">
              <span className="text-xs font-bold uppercase tracking-wider text-[#8C4E28] bg-white px-3 py-1 rounded-full border border-[#DECFC0]">
                Edible Memories
              </span>
              <h3 className="font-serif text-3xl font-bold text-[#361F13] leading-snug">
                Personalized Edible Photo Cakes
              </h3>
              <p className="text-xs sm:text-sm text-[#715848] leading-relaxed max-w-sm">
                Upload your family portrait, wedding photo, or cartoon graphic. Printed with pure food-grade organic inks on delicate sugar icing sheets.
              </p>
            </div>
            <div className="relative z-10 pt-8">
              <button
                onClick={() => onNavigate('photo-cake')}
                className="px-6 py-3 bg-[#361F13] hover:bg-[#22120A] text-white text-xs font-bold rounded-xl transition-colors shadow-md flex items-center gap-2"
              >
                <span>Order a Photo Cake</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 6. New Arrivals Showcase */}
      {newArrivals.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between mb-8">
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-[#8C4E28] block mb-1">
                Fresh From The Oven
              </span>
              <h2 className="font-serif text-3xl font-bold text-[#361F13]">New Arrivals</h2>
            </div>
            <button
              onClick={() => onNavigate('cakes')}
              className="text-xs font-semibold text-[#8C4E28] hover:text-[#361F13] flex items-center gap-1 group"
            >
              <span>Explore All</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {newArrivals.map((cake) => (
              <ProductCard
                key={cake.id}
                product={cake}
                onOpenDetails={onSelectProduct}
                onOpenQuickView={(prod) => setQuickViewProduct(prod)}
              />
            ))}
          </div>
        </section>
      )}

      {/* 7. Pincode & Delivery Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-[#FAF7F2] p-8 sm:p-12 rounded-3xl border border-[#E9DFD3]">
          <div className="lg:col-span-6 space-y-4">
            <span className="text-xs font-bold uppercase tracking-wider text-[#8C4E28]">
              Same-Day Express
            </span>
            <h3 className="font-serif text-3xl font-bold text-[#361F13]">
              Baking Fresh, Delivering Across Pune
            </h3>
            <p className="text-sm text-[#715848] leading-relaxed">
              We operate temperature-controlled delivery vans ensuring your multi-tier cakes, delicate cheesecakes, and chocolate ganache arrive in pristine condition.
            </p>

            <div className="grid grid-cols-2 gap-4 pt-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-[#361F13]">
                <Clock className="w-4 h-4 text-[#8C4E28]" />
                <span>Order before 2 PM for Same-Day</span>
              </div>
              <div className="flex items-center gap-2 text-xs font-semibold text-[#361F13]">
                <Truck className="w-4 h-4 text-emerald-700" />
                <span>FREE Delivery above ₹{settings.freeDeliveryThreshold}</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6">
            <PincodeChecker />
          </div>
        </div>
      </section>

      {/* 8. Why Choose Us (Item #26) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-xl mx-auto mb-12">
          <span className="text-xs font-semibold uppercase tracking-wider text-[#8C4E28] block mb-1">
            Our Promise
          </span>
          <h2 className="font-serif text-3xl font-bold text-[#361F13]">Why Sweet Delight Cakes?</h2>
          <p className="text-xs text-[#715848] mt-1">
            Every celebration deserves an authentic, artisan centerpiece
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6">
          {[
            {
              title: 'Freshly Baked',
              desc: 'Never frozen or pre-stored. Every single cake is baked from scratch on the day of delivery.',
              icon: '🎂',
            },
            {
              title: 'Premium Ingredients',
              desc: 'Imported Belgian chocolate, fresh vanilla beans, real cream cheese, and zero preservatives.',
              icon: '🍫',
            },
            {
              title: 'Reliable Delivery',
              desc: 'Carefully cushioned cake boxes and chilled transport to guarantee zero transit damage.',
              icon: '🚚',
            },
            {
              title: 'Custom Designs',
              desc: 'Tailor-made to your imagination, from intricate wedding sugar flowers to theme cartoon cakes.',
              icon: '🎨',
            },
            {
              title: 'Made With Love',
              desc: 'Passionate pastry masters who treat every cake like a personal celebration centerpiece.',
              icon: '❤️',
            },
          ].map((item, idx) => (
            <div
              key={idx}
              className="bg-white p-6 rounded-2xl border border-[#EDE3D6] hover:border-[#8C4E28] transition-colors shadow-2xs flex flex-col items-center text-center"
            >
              <div className="w-12 h-12 rounded-2xl bg-[#FAF0E6] flex items-center justify-center text-2xl mb-4">
                {item.icon}
              </div>
              <h4 className="font-serif text-base font-bold text-[#361F13] mb-1.5">
                {item.title}
              </h4>
              <p className="text-xs text-[#715848] leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 9. Customer Reviews (Item #27) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-[#8C4E28] block mb-1">
              Sweet Stories
            </span>
            <h2 className="font-serif text-3xl font-bold text-[#361F13]">Customer Reviews</h2>
            <p className="text-xs text-[#715848] mt-1">
              Read real experiences from cake lovers across Pune
            </p>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-amber-600 font-bold bg-amber-50 px-3 py-1.5 rounded-xl border border-amber-200">
            <Star className="w-4 h-4 fill-current text-amber-500" />
            <span>4.9 / 5.0 Star Rating across 2,400+ Orders</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {reviews.slice(0, 3).map((rev) => (
            <div
              key={rev.id}
              className="bg-white p-6 rounded-2xl border border-[#EDE3D6] shadow-2xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex text-amber-500">
                    {[...Array(rev.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>
                  <span className="text-[11px] text-stone-400">{rev.date}</span>
                </div>

                <Quote className="w-6 h-6 text-[#E8D9C8] mb-2" />
                <p className="text-xs sm:text-sm text-[#4A3225] leading-relaxed italic">
                  &quot;{rev.comment}&quot;
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-[#F2EAE0] flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-[#361F13]">{rev.customerName}</h4>
                  <span className="text-[11px] text-[#8C4E28] font-medium block">
                    {rev.cakePurchased}
                  </span>
                </div>
                {rev.verifiedBuyer && (
                  <span className="text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-medium border border-emerald-200">
                    Verified Buyer
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 10. Recently Viewed Cakes (Item #52) */}
      {recentlyViewed.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-6">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#8C4E28] block mb-1">
              Pick Up Where You Left Off
            </span>
            <h2 className="font-serif text-2xl font-bold text-[#361F13]">Recently Viewed Cakes</h2>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {recentlyViewed.slice(0, 6).map((cake) => (
              <ProductCard
                key={cake.id}
                product={cake}
                onOpenDetails={onSelectProduct}
                onOpenQuickView={(prod) => setQuickViewProduct(prod)}
              />
            ))}
          </div>
        </section>
      )}

      {/* 11. FAQ Section (Item #28) */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <span className="text-xs font-semibold uppercase tracking-wider text-[#8C4E28] block mb-1">
            Got Questions?
          </span>
          <h2 className="font-serif text-3xl font-bold text-[#361F13]">Frequently Asked Questions</h2>
          <p className="text-xs text-[#715848] mt-1">
            Everything you need to know about cake ordering, customizations, and delivery
          </p>
        </div>

        <div className="space-y-3">
          {FAQS.slice(0, 7).map((faq) => {
            const isOpen = activeFaqId === faq.id;
            return (
              <div
                key={faq.id}
                className="bg-white rounded-2xl border border-[#EDE3D6] overflow-hidden transition-colors"
              >
                <button
                  onClick={() => setActiveFaqId(isOpen ? null : faq.id)}
                  className="w-full text-left p-4 sm:p-5 flex items-center justify-between gap-4 font-serif text-sm sm:text-base font-bold text-[#361F13] hover:text-[#8C4E28] transition-colors"
                >
                  <span>{faq.question}</span>
                  {isOpen ? (
                    <ChevronUp className="w-4 h-4 text-[#8C4E28] shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-stone-400 shrink-0" />
                  )}
                </button>
                {isOpen && (
                  <div className="px-4 pb-5 sm:px-5 text-xs sm:text-sm text-[#715848] leading-relaxed border-t border-[#F2EAE0] pt-3">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* 12. Blog & Cake Ideas Preview (Item #30) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-[#8C4E28] block mb-1">
              Bakery Journal
            </span>
            <h2 className="font-serif text-3xl font-bold text-[#361F13]">Cake Ideas & Baking Stories</h2>
          </div>
          <button
            onClick={() => onNavigate('blog')}
            className="text-xs font-semibold text-[#8C4E28] hover:text-[#361F13] flex items-center gap-1 group"
          >
            <span>Read All Articles</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {BLOG_POSTS.slice(0, 3).map((post) => (
            <div
              key={post.id}
              onClick={() => onNavigate('blog', { postId: post.id })}
              className="bg-white rounded-2xl border border-[#EDE3D6] overflow-hidden hover:shadow-lg transition-all duration-300 cursor-pointer flex flex-col group"
            >
              <div className="aspect-16/9 overflow-hidden bg-stone-100">
                <SafeImage
                  src={post.coverImage}
                  alt={post.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-[11px] text-[#8C4E28] font-semibold uppercase tracking-wider mb-2">
                    <span>{post.category}</span>
                    <span>·</span>
                    <span>{post.readTime}</span>
                  </div>
                  <h3 className="font-serif text-base font-bold text-[#361F13] group-hover:text-[#8C4E28] transition-colors line-clamp-2">
                    {post.title}
                  </h3>
                  <p className="text-xs text-[#715848] mt-2 line-clamp-2 leading-relaxed">
                    {post.excerpt}
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-[#F2EAE0] flex items-center justify-between text-xs text-stone-400">
                  <span>{post.publishedDate}</span>
                  <span className="text-[#8C4E28] font-semibold group-hover:underline flex items-center gap-1">
                    Read More <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Quick View Modal */}
      <QuickViewModal
        product={quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
        onViewFullDetails={(id) => {
          setQuickViewProduct(null);
          onSelectProduct(id);
        }}
      />
    </div>
  );
};

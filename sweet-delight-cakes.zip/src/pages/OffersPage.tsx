import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { useCart } from '../context/CartContext';
import { useNotification } from '../context/NotificationContext';
import { Breadcrumbs } from '../components/common/Breadcrumbs';
import { Tag, Copy, Check, Sparkles, ArrowRight } from 'lucide-react';

interface OffersPageProps {
  onNavigate: (tab: string) => void;
}

export const OffersPage: React.FC<OffersPageProps> = ({ onNavigate }) => {
  const { coupons, settings } = useShop();
  const { applyCoupon, openCartDrawer } = useCart();
  const { showToast } = useNotification();
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    showToast(`Coupon code ${code} copied to clipboard!`, 'info');
    setTimeout(() => setCopiedCode(null), 2500);
  };

  const handleApplyDirect = (code: string) => {
    applyCoupon(code);
    openCartDrawer();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <Breadcrumbs
        items={[
          { label: 'Cakes', tab: 'cakes' },
          { label: 'Offers & Coupons', active: true },
        ]}
        onNavigate={onNavigate}
      />

      <div className="text-center max-w-xl mx-auto mb-10">
        <span className="text-xs font-bold uppercase tracking-wider text-[#8C4E28] block mb-1">
          Exclusive Bakery Discounts
        </span>
        <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#361F13]">
          Bakery Offers & Coupons
        </h1>
        <p className="text-xs sm:text-sm text-[#715848] mt-2">
          Make your celebrations even sweeter with exclusive discount vouchers and free delivery perks.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {coupons.map((coupon) => (
          <div
            key={coupon.id || coupon.code}
            className="bg-white rounded-3xl p-6 border-2 border-dashed border-[#DECFC0] hover:border-[#8C4E28] transition-all shadow-xs flex flex-col justify-between relative group"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-[#8C4E28] bg-[#FAF0E6] px-3 py-1 rounded-full flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5" />
                  <span>
                    {coupon.discountType === 'percent' || coupon.discountType === 'percentage'
                      ? `${coupon.discountValue}% OFF`
                      : `Flat ₹${coupon.discountValue} OFF`}
                  </span>
                </span>
                <span className="text-[11px] text-stone-400">
                  Valid till {coupon.expiryDate || coupon.validTill || '31 Dec 2026'}
                </span>
              </div>

              <h3 className="font-serif text-xl font-bold text-[#361F13] mb-1">{coupon.description}</h3>

              <div className="space-y-1 text-xs text-[#715848] mt-3">
                <p>
                  • Minimum Order: <strong>{settings.currencySymbol}{coupon.minOrderValue}</strong>
                </p>
                {coupon.maxDiscount && (
                  <p>
                    • Max Discount: <strong>{settings.currencySymbol}{coupon.maxDiscount}</strong>
                  </p>
                )}
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-[#F2EAE0] flex items-center justify-between gap-3">
              <div className="bg-[#FAF7F2] px-3 py-1.5 rounded-xl border border-[#E2D5C7] font-mono text-sm font-bold text-[#361F13] tracking-widest">
                {coupon.code}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleCopy(coupon.code)}
                  className="p-2 rounded-xl border border-stone-200 hover:bg-[#FAF7F2] text-stone-600 transition-colors"
                  title="Copy Code"
                >
                  {copiedCode === coupon.code ? (
                    <Check className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>

                <button
                  onClick={() => handleApplyDirect(coupon.code)}
                  className="px-3.5 py-2 bg-[#361F13] hover:bg-[#22120A] text-white text-xs font-semibold rounded-xl transition-colors"
                >
                  Apply
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

import React from 'react';
import { Breadcrumbs } from '../components/common/Breadcrumbs';
import { SafeImage } from '../components/common/SafeImage';
import { useShop } from '../context/ShopContext';
import { Award, Heart, Sparkles, ChefHat, ShieldCheck, Clock, Cake } from 'lucide-react';

interface AboutPageProps {
  onNavigate: (tab: string) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ onNavigate }) => {
  const { settings } = useShop();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-16">
      <Breadcrumbs
        items={[
          { label: 'Home', tab: 'home' },
          { label: 'About Us', active: true },
        ]}
        onNavigate={onNavigate}
      />

      {/* Hero Section */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
        <div className="lg:col-span-7 space-y-6">
          <span className="text-xs font-bold uppercase tracking-wider text-[#8C4E28] bg-[#FAF0E6] px-3 py-1 rounded-full">
            Our Sweet Heritage Since 2015
          </span>
          <h1 className="font-serif text-3xl sm:text-5xl font-bold text-[#361F13] leading-tight">
            Handcrafting Happiness, One Artisan Slice at a Time
          </h1>
          <p className="text-sm sm:text-base text-[#523B2D] leading-relaxed">
            Welcome to {settings.shopName}. We began in Kharadi, Pune, as a boutique family patisserie with a single purpose: to elevate celebration cakes from standard sugary confections into unforgettable culinary masterpieces.
          </p>
          <p className="text-xs sm:text-sm text-[#715848] leading-relaxed">
            Today, our certified master bakers prepare over 200 custom cakes daily, using imported Belgian couverture chocolate, pure dairy butter creams, and genuine Madagascar vanilla beans.
          </p>
        </div>

        <div className="lg:col-span-5 aspect-4/3 rounded-3xl overflow-hidden shadow-xl border-4 border-white bg-stone-100">
          <SafeImage
            src="https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&w=1000&q=80"
            alt="Bakery Kitchen Workshop"
            className="w-full h-full object-cover"
          />
        </div>
      </section>

      {/* Values Grid */}
      <section className="bg-white p-8 sm:p-12 rounded-3xl border border-[#EDE3D6] shadow-xs">
        <div className="text-center max-w-xl mx-auto mb-10">
          <span className="text-xs font-bold uppercase tracking-wider text-[#8C4E28] block mb-1">
            Our Baking Philosophy
          </span>
          <h2 className="font-serif text-3xl font-bold text-[#361F13]">Ingredients Without Compromise</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center space-y-3">
            <div className="w-14 h-14 rounded-2xl bg-[#FAF0E6] text-[#8C4E28] mx-auto flex items-center justify-center">
              <ChefHat className="w-7 h-7" />
            </div>
            <h3 className="font-serif text-lg font-bold text-[#361F13]">100% Baked Fresh To Order</h3>
            <p className="text-xs text-[#715848] leading-relaxed">
              We never keep frozen bases or pre-frosted cakes on shelves. Sponge layers are mixed and baked on the exact morning of your event.
            </p>
          </div>

          <div className="text-center space-y-3">
            <div className="w-14 h-14 rounded-2xl bg-[#FAF0E6] text-[#8C4E28] mx-auto flex items-center justify-center">
              <ShieldCheck className="w-7 h-7" />
            </div>
            <h3 className="font-serif text-lg font-bold text-[#361F13]">Pure Vegetarian Excellence</h3>
            <p className="text-xs text-[#715848] leading-relaxed">
              Over 90% of our menu is certified 100% eggless with dedicated baking equipment, ensuring fluffy, moist textures that delight every family member.
            </p>
          </div>

          <div className="text-center space-y-3">
            <div className="w-14 h-14 rounded-2xl bg-[#FAF0E6] text-[#8C4E28] mx-auto flex items-center justify-center">
              <Heart className="w-7 h-7" />
            </div>
            <h3 className="font-serif text-lg font-bold text-[#361F13]">Artisan Sugar Crafting</h3>
            <p className="text-xs text-[#715848] leading-relaxed">
              From delicate sugar flowers to edible 3D figurines, our pastry decorators bring meticulous precision to every custom tier.
            </p>
          </div>
        </div>
      </section>

      {/* Bakery Stats */}
      <section className="bg-[#FAF7F2] p-8 sm:p-10 rounded-3xl border border-[#EDE3D6] grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
        <div>
          <span className="font-serif text-3xl sm:text-4xl font-bold text-[#361F13]">15,000+</span>
          <p className="text-xs text-stone-500 mt-1">Cakes Handcrafted</p>
        </div>
        <div>
          <span className="font-serif text-3xl sm:text-4xl font-bold text-[#361F13]">4.9★</span>
          <p className="text-xs text-stone-500 mt-1">Average Google Rating</p>
        </div>
        <div>
          <span className="font-serif text-3xl sm:text-4xl font-bold text-[#361F13]">12+</span>
          <p className="text-xs text-stone-500 mt-1">Pune Hubs Served</p>
        </div>
        <div>
          <span className="font-serif text-3xl sm:text-4xl font-bold text-[#361F13]">100%</span>
          <p className="text-xs text-stone-500 mt-1">Freshness Guaranteed</p>
        </div>
      </section>
    </div>
  );
};

import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import { CartItem, Coupon } from '../types';
import { useShop } from './ShopContext';
import { useNotification } from './NotificationContext';

interface CartContextType {
  items: CartItem[];
  itemCount: number;
  subtotal: number;
  discountAmount: number;
  deliveryFee: number;
  taxAmount: number;
  grandTotal: number;
  appliedCoupon: Coupon | null;
  couponError: string | null;
  isCartDrawerOpen: boolean;
  openCartDrawer: () => void;
  closeCartDrawer: () => void;
  addToCart: (item: Omit<CartItem, 'id' | 'totalPrice'>) => void;
  removeFromCart: (cartItemId: string) => void;
  updateQuantity: (cartItemId: string, newQty: number) => void;
  clearCart: () => void;
  applyCoupon: (couponCode: string) => boolean;
  removeCoupon: () => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

const CART_STORAGE_KEY = 'sdc_cart_items';
const COUPON_STORAGE_KEY = 'sdc_applied_coupon';

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { settings, coupons } = useShop();
  const { showToast } = useNotification();

  const [items, setItems] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem(CART_STORAGE_KEY);
    return saved ? JSON.parse(saved) : [];
  });

  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(() => {
    const saved = localStorage.getItem(COUPON_STORAGE_KEY);
    return saved ? JSON.parse(saved) : null;
  });

  const [couponError, setCouponError] = useState<string | null>(null);
  const [isCartDrawerOpen, setIsCartDrawerOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items));
  }, [items]);

  useEffect(() => {
    if (appliedCoupon) {
      localStorage.setItem(COUPON_STORAGE_KEY, JSON.stringify(appliedCoupon));
    } else {
      localStorage.removeItem(COUPON_STORAGE_KEY);
    }
  }, [appliedCoupon]);

  const itemCount = useMemo(() => {
    return items.reduce((sum, item) => sum + item.quantity, 0);
  }, [items]);

  const subtotal = useMemo(() => {
    return items.reduce((sum, item) => sum + item.totalPrice, 0);
  }, [items]);

  // Recalculate discount based on applied coupon and subtotal
  const discountAmount = useMemo(() => {
    if (!appliedCoupon) return 0;
    if (subtotal < appliedCoupon.minOrderValue) return 0;

    let disc = 0;
    if (appliedCoupon.discountType === 'percentage') {
      disc = (subtotal * appliedCoupon.discountValue) / 100;
      if (appliedCoupon.maxDiscount && disc > appliedCoupon.maxDiscount) {
        disc = appliedCoupon.maxDiscount;
      }
    } else {
      disc = appliedCoupon.discountValue;
    }
    return Math.min(disc, subtotal);
  }, [appliedCoupon, subtotal]);

  // Delivery fee calculation
  const deliveryFee = useMemo(() => {
    if (items.length === 0) return 0;
    if (subtotal >= settings.freeDeliveryThreshold) {
      return 0; // Free delivery threshold met
    }
    return settings.standardDeliveryFee;
  }, [items.length, subtotal, settings]);

  // Tax calculation
  const taxableAmount = Math.max(0, subtotal - discountAmount);
  const taxAmount = useMemo(() => {
    if (items.length === 0) return 0;
    return Math.round((taxableAmount * settings.taxRatePercent) / 100);
  }, [taxableAmount, settings.taxRatePercent, items.length]);

  const grandTotal = useMemo(() => {
    if (items.length === 0) return 0;
    return taxableAmount + deliveryFee + taxAmount;
  }, [taxableAmount, deliveryFee, taxAmount, items.length]);

  const openCartDrawer = () => setIsCartDrawerOpen(true);
  const closeCartDrawer = () => setIsCartDrawerOpen(false);

  const addToCart = (newItem: Omit<CartItem, 'id' | 'totalPrice'>) => {
    const addonsKey = (newItem.selectedAddOns || []).map((a) => a.id).sort().join('-');
    const cartItemId = `${newItem.productId}_${newItem.weight}_${newItem.flavor}_${newItem.eggless ? 'eggless' : 'egg'}_${newItem.customMessage || ''}_${addonsKey}`;

    const itemTotalPrice = newItem.unitPrice * newItem.quantity;

    setItems((prev) => {
      const existingIndex = prev.findIndex((i) => i.id === cartItemId);
      if (existingIndex > -1) {
        const updated = [...prev];
        const updatedQty = updated[existingIndex].quantity + newItem.quantity;
        updated[existingIndex] = {
          ...updated[existingIndex],
          quantity: updatedQty,
          totalPrice: updated[existingIndex].unitPrice * updatedQty,
        };
        return updated;
      } else {
        const cartItem: CartItem = {
          ...newItem,
          id: cartItemId,
          totalPrice: itemTotalPrice,
        };
        return [...prev, cartItem];
      }
    });

    showToast(`Added "${newItem.name}" to cart! 🍰`, 'success');
  };

  const removeFromCart = (cartItemId: string) => {
    setItems((prev) => {
      const item = prev.find((i) => i.id === cartItemId);
      if (item) {
        showToast(`Removed "${item.name}" from cart`, 'info');
      }
      return prev.filter((i) => i.id !== cartItemId);
    });
  };

  const updateQuantity = (cartItemId: string, newQty: number) => {
    if (newQty <= 0) {
      removeFromCart(cartItemId);
      return;
    }
    setItems((prev) =>
      prev.map((i) => {
        if (i.id === cartItemId) {
          return {
            ...i,
            quantity: newQty,
            totalPrice: i.unitPrice * newQty,
          };
        }
        return i;
      })
    );
  };

  const clearCart = () => {
    setItems([]);
    setAppliedCoupon(null);
    setCouponError(null);
  };

  const applyCoupon = (code: string): boolean => {
    setCouponError(null);
    const cleanCode = code.trim().toUpperCase();
    if (!cleanCode) {
      setCouponError('Please enter a coupon code.');
      return false;
    }

    const foundCoupon = coupons.find((c) => c.code.toUpperCase() === cleanCode);
    if (!foundCoupon) {
      setCouponError('Invalid coupon code. Try FIRST10, CAKE20, or SWEET15.');
      showToast('Invalid coupon code.', 'error');
      return false;
    }

    if (!foundCoupon.isActive) {
      setCouponError('This coupon is currently inactive.');
      showToast('This coupon is inactive.', 'error');
      return false;
    }

    if (foundCoupon.expiryDate && new Date(foundCoupon.expiryDate) < new Date()) {
      setCouponError('This coupon has expired.');
      showToast('Coupon has expired.', 'error');
      return false;
    }

    if (subtotal < foundCoupon.minOrderValue) {
      const diff = foundCoupon.minOrderValue - subtotal;
      setCouponError(
        `Minimum order amount not reached. Add ₹${diff} more to use ${cleanCode}.`
      );
      showToast(`Add ₹${diff} more to apply this coupon!`, 'warning');
      return false;
    }

    setAppliedCoupon(foundCoupon);
    showToast(`Coupon "${cleanCode}" applied successfully! 🎉`, 'success');
    return true;
  };

  const removeCoupon = () => {
    if (appliedCoupon) {
      showToast(`Coupon "${appliedCoupon.code}" removed.`, 'info');
    }
    setAppliedCoupon(null);
    setCouponError(null);
  };

  return (
    <CartContext.Provider
      value={{
        items,
        itemCount,
        subtotal,
        discountAmount,
        deliveryFee,
        taxAmount,
        grandTotal,
        appliedCoupon,
        couponError,
        isCartDrawerOpen,
        openCartDrawer,
        closeCartDrawer,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        applyCoupon,
        removeCoupon,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, Category, Coupon, Review, ShopSettings } from '../types';
import { PRODUCTS } from '../data/products';
import { CATEGORIES } from '../data/categories';
import { INITIAL_COUPONS } from '../data/coupons';
import { REVIEWS } from '../data/reviews';
import { initialShopConfig } from '../config/shopConfig';

interface ShopContextType {
  products: Product[];
  categories: Category[];
  coupons: Coupon[];
  reviews: Review[];
  settings: ShopSettings;
  recentlyViewed: Product[];
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  addCoupon: (coupon: Coupon) => void;
  updateCoupon: (code: string, coupon: Partial<Coupon>) => void;
  deleteCoupon: (code: string) => void;
  updateSettings: (newSettings: Partial<ShopSettings>) => void;
  addRecentlyViewed: (product: Product) => void;
  checkPincodeDelivery: (pincode: string) => { available: boolean; message: string };
  addReview: (review: Omit<Review, 'id' | 'date'>) => void;
  deleteReview: (reviewId: string) => void;
  addSupportedPincode: (pincode: string) => void;
  removeSupportedPincode: (pincode: string) => void;
}

const ShopContext = createContext<ShopContextType | undefined>(undefined);

const STORAGE_KEYS = {
  PRODUCTS: 'sdc_products',
  CATEGORIES: 'sdc_categories',
  COUPONS: 'sdc_coupons',
  SETTINGS: 'sdc_settings',
  RECENTLY_VIEWED: 'sdc_recently_viewed',
  REVIEWS: 'sdc_reviews',
};

export const ShopProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
    return saved ? JSON.parse(saved) : PRODUCTS;
  });

  const [categories, setCategories] = useState<Category[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
    return saved ? JSON.parse(saved) : CATEGORIES;
  });

  const [coupons, setCoupons] = useState<Coupon[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.COUPONS);
    return saved ? JSON.parse(saved) : INITIAL_COUPONS;
  });

  const [reviews, setReviews] = useState<Review[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.REVIEWS);
    return saved ? JSON.parse(saved) : REVIEWS;
  });

  const [settings, setSettings] = useState<ShopSettings>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    return saved ? JSON.parse(saved) : initialShopConfig;
  });

  const [recentlyViewed, setRecentlyViewed] = useState<Product[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.RECENTLY_VIEWED);
    return saved ? JSON.parse(saved) : [];
  });

  // Persist state updates to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.COUPONS, JSON.stringify(coupons));
  }, [coupons]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.RECENTLY_VIEWED, JSON.stringify(recentlyViewed));
  }, [recentlyViewed]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.REVIEWS, JSON.stringify(reviews));
  }, [reviews]);

  const addProduct = (newProd: Omit<Product, 'id'>) => {
    const id = `cake-${Date.now().toString().slice(-4)}`;
    const product: Product = { ...newProd, id };
    setProducts((prev) => [product, ...prev]);
  };

  const updateProduct = (id: string, updated: Partial<Product>) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updated } : p))
    );
  };

  const deleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
  };

  const addCoupon = (coupon: Coupon) => {
    setCoupons((prev) => [...prev, coupon]);
  };

  const updateCoupon = (code: string, updated: Partial<Coupon>) => {
    setCoupons((prev) =>
      prev.map((c) => (c.code === code ? { ...c, ...updated } : c))
    );
  };

  const deleteCoupon = (code: string) => {
    setCoupons((prev) => prev.filter((c) => c.code !== code));
  };

  const updateSettings = (newSettings: Partial<ShopSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  const addRecentlyViewed = (product: Product) => {
    setRecentlyViewed((prev) => {
      const filtered = prev.filter((p) => p.id !== product.id);
      return [product, ...filtered].slice(0, 6);
    });
  };

  const checkPincodeDelivery = (pincode: string) => {
    const cleanPin = pincode.trim();
    if (!cleanPin || cleanPin.length !== 6 || !/^\d+$/.test(cleanPin)) {
      return { available: false, message: 'Please enter a valid 6-digit postal code.' };
    }
    const isSupported = settings.supportedPincodes.includes(cleanPin);
    if (isSupported) {
      return {
        available: true,
        message: `Great news! Same-day cake delivery is available for ${cleanPin}.`,
      };
    } else {
      return {
        available: false,
        message: `Sorry, we currently deliver only across Pune hub pincodes. Delivery to ${cleanPin} is not supported yet.`,
      };
    }
  };

  const addReview = (newReview: Omit<Review, 'id' | 'date'>) => {
    const review: Review = {
      ...newReview,
      id: `rev-${Date.now()}`,
      date: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
    };
    setReviews((prev) => [review, ...prev]);
  };

  const deleteReview = (reviewId: string) => {
    setReviews((prev) => prev.filter((r) => r.id !== reviewId));
  };

  const addSupportedPincode = (pincode: string) => {
    setSettings((prev) => ({
      ...prev,
      supportedPincodes: [...new Set([...prev.supportedPincodes, pincode])],
    }));
  };

  const removeSupportedPincode = (pincode: string) => {
    setSettings((prev) => ({
      ...prev,
      supportedPincodes: prev.supportedPincodes.filter((p) => p !== pincode),
    }));
  };

  return (
    <ShopContext.Provider
      value={{
        products,
        categories,
        coupons,
        reviews,
        settings,
        recentlyViewed,
        addProduct,
        updateProduct,
        deleteProduct,
        addCoupon,
        updateCoupon,
        deleteCoupon,
        updateSettings,
        addRecentlyViewed,
        checkPincodeDelivery,
        addReview,
        deleteReview,
        addSupportedPincode,
        removeSupportedPincode,
      }}
    >
      {children}
    </ShopContext.Provider>
  );
};

export const useShop = () => {
  const context = useContext(ShopContext);
  if (!context) {
    throw new Error('useShop must be used within a ShopProvider');
  }
  return context;
};

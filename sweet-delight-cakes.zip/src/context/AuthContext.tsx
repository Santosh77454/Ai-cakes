import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, DeliveryAddress } from '../types';
import { useNotification } from './NotificationContext';

interface AuthContextType {
  user: UserProfile | null;
  isAdmin: boolean;
  login: (emailOrPhone: string, pass: string) => boolean;
  register: (name: string, email: string, phone: string, pass: string) => boolean;
  logout: () => void;
  loginAsCustomer: () => void;
  updateProfile: (updated: Partial<UserProfile>) => void;
  addAddress: (address: DeliveryAddress) => void;
  removeAddress: (idOrIndex: string | number) => void;
  loginAsAdmin: () => void;
  logoutAdmin: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const USER_STORAGE_KEY = 'sdc_current_user';
const ADMIN_STORAGE_KEY = 'sdc_admin_auth';

const INITIAL_ADDR: DeliveryAddress = {
  id: 'addr-1',
  fullName: 'Santosh Gayake',
  phone: '+91 98230 45678',
  email: 'santoshgayake43222@gmail.com',
  street: 'Flat 402, Marvel Orchid, Kharadi Main Road',
  city: 'Pune',
  pincode: '411014',
  landmark: 'Near World Trade Center',
  label: 'Home',
  isDefault: true,
  addressType: 'home',
};

const DEFAULT_USER: UserProfile = {
  id: 'user-001',
  name: 'Santosh Gayake',
  email: 'santoshgayake43222@gmail.com',
  phone: '+91 98230 45678',
  savedAddresses: [INITIAL_ADDR],
  addresses: [INITIAL_ADDR],
  createdAt: '2026-01-10',
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { showToast } = useNotification();

  const [user, setUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem(USER_STORAGE_KEY);
    return saved ? JSON.parse(saved) : DEFAULT_USER;
  });

  const [isAdmin, setIsAdmin] = useState<boolean>(() => {
    const saved = localStorage.getItem(ADMIN_STORAGE_KEY);
    return saved === 'true';
  });

  useEffect(() => {
    if (user) {
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(USER_STORAGE_KEY);
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem(ADMIN_STORAGE_KEY, isAdmin ? 'true' : 'false');
  }, [isAdmin]);

  const login = (emailOrPhone: string, _pass: string): boolean => {
    if (!emailOrPhone.trim()) {
      showToast('Please provide an email or phone number.', 'error');
      return false;
    }
    // Mock user login
    const newUser: UserProfile = {
      id: `user-${Date.now()}`,
      name: emailOrPhone.includes('@') ? emailOrPhone.split('@')[0] : 'Valued Customer',
      email: emailOrPhone.includes('@') ? emailOrPhone : 'customer@sweetdelight.com',
      phone: emailOrPhone.includes('@') ? '+91 98230 45678' : emailOrPhone,
      savedAddresses: [],
      addresses: [],
      createdAt: new Date().toISOString().split('T')[0],
    };
    setUser(newUser);
    showToast(`Welcome back, ${newUser.name}! 🍰`, 'success');
    return true;
  };

  const register = (name: string, email: string, phone: string, _pass: string): boolean => {
    if (!name.trim() || !email.trim() || !phone.trim()) {
      showToast('Please fill all required registration fields.', 'error');
      return false;
    }
    const newUser: UserProfile = {
      id: `user-${Date.now()}`,
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      savedAddresses: [],
      addresses: [],
      createdAt: new Date().toISOString().split('T')[0],
    };
    setUser(newUser);
    showToast(`Account created successfully! Welcome, ${newUser.name}. 🎉`, 'success');
    return true;
  };

  const logout = () => {
    setUser(null);
    showToast('You have been logged out.', 'info');
  };

  const loginAsCustomer = () => {
    setUser(DEFAULT_USER);
  };

  const updateProfile = (updated: Partial<UserProfile>) => {
    setUser((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        ...updated,
        addresses: updated.savedAddresses || updated.addresses || prev.addresses || prev.savedAddresses,
        savedAddresses: updated.savedAddresses || updated.addresses || prev.savedAddresses,
      };
    });
    showToast('Profile updated successfully!', 'success');
  };

  const addAddress = (address: DeliveryAddress) => {
    const addrWithId: DeliveryAddress = {
      ...address,
      id: address.id || `addr-${Date.now()}`,
    };
    setUser((prev) => {
      if (!prev) return null;
      const list = [...(prev.savedAddresses || prev.addresses || []), addrWithId];
      return {
        ...prev,
        savedAddresses: list,
        addresses: list,
      };
    });
    showToast('New address saved!', 'success');
  };

  const removeAddress = (idOrIndex: string | number) => {
    setUser((prev) => {
      if (!prev) return null;
      const list = (prev.savedAddresses || prev.addresses || []).filter((item, i) => {
        if (typeof idOrIndex === 'number') return i !== idOrIndex;
        return item.id !== idOrIndex;
      });
      return { ...prev, savedAddresses: list, addresses: list };
    });
    showToast('Address removed.', 'info');
  };

  const loginAsAdmin = () => {
    setIsAdmin(true);
    showToast('Switched to Admin Mode ⚙️', 'info');
  };

  const logoutAdmin = () => {
    setIsAdmin(false);
    showToast('Exited Admin Mode.', 'info');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAdmin,
        login,
        register,
        logout,
        loginAsCustomer,
        updateProfile,
        addAddress,
        removeAddress,
        loginAsAdmin,
        logoutAdmin,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

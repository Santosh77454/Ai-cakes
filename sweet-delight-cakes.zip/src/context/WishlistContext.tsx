import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product } from '../types';
import { useShop } from './ShopContext';
import { useNotification } from './NotificationContext';
import { useCart } from './CartContext';

interface WishlistContextType {
  wishlistIds: string[];
  wishlistProducts: Product[];
  wishlistItems: Product[];
  isInWishlist: (productId: string) => boolean;
  toggleWishlist: (product: Product) => void;
  removeFromWishlist: (productId: string) => void;
  clearWishlist: () => void;
  moveToCart: (product: Product) => void;
}

const WishlistContext = createContext<WishlistContextType | undefined>(undefined);

const WISHLIST_STORAGE_KEY = 'sdc_wishlist_ids';

export const WishlistProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { products } = useShop();
  const { showToast } = useNotification();
  const { addToCart } = useCart();

  const [wishlistIds, setWishlistIds] = useState<string[]>(() => {
    const saved = localStorage.getItem(WISHLIST_STORAGE_KEY);
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem(WISHLIST_STORAGE_KEY, JSON.stringify(wishlistIds));
  }, [wishlistIds]);

  const wishlistProducts = products.filter((p) => wishlistIds.includes(p.id));

  const isInWishlist = (productId: string) => wishlistIds.includes(productId);

  const toggleWishlist = (product: Product) => {
    if (isInWishlist(product.id)) {
      setWishlistIds((prev) => prev.filter((id) => id !== product.id));
      showToast(`Removed "${product.name}" from wishlist.`, 'info');
    } else {
      setWishlistIds((prev) => [...prev, product.id]);
      showToast(`Added "${product.name}" to your wishlist! ❤️`, 'success');
    }
  };

  const removeFromWishlist = (productId: string) => {
    setWishlistIds((prev) => prev.filter((id) => id !== productId));
  };

  const clearWishlist = () => {
    setWishlistIds([]);
  };

  const moveToCart = (product: Product) => {
    const discountedPrice = Math.round(
      product.basePrice * (1 - (product.discountPercent || 0) / 100)
    );

    addToCart({
      productId: product.id,
      name: product.name,
      image: product.images[0] || '',
      weight: product.defaultWeight || '500g',
      flavor: product.defaultFlavor || 'Chocolate',
      eggless: product.eggless,
      selectedAddOns: [],
      unitPrice: discountedPrice,
      quantity: 1,
    });

    removeFromWishlist(product.id);
  };

  return (
    <WishlistContext.Provider
      value={{
        wishlistIds,
        wishlistProducts,
        wishlistItems: wishlistProducts,
        isInWishlist,
        toggleWishlist,
        removeFromWishlist,
        clearWishlist,
        moveToCart,
      }}
    >
      {children}
    </WishlistContext.Provider>
  );
};

export const useWishlist = () => {
  const context = useContext(WishlistContext);
  if (!context) {
    throw new Error('useWishlist must be used within a WishlistProvider');
  }
  return context;
};

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Order, OrderStatus } from '../types';
import { useNotification } from './NotificationContext';

interface OrderContextType {
  orders: Order[];
  createOrder: (orderData: Omit<Order, 'id' | 'createdAt' | 'status'>) => Order;
  updateOrderStatus: (orderId: string, status: OrderStatus) => void;
  getOrderById: (orderId: string) => Order | undefined;
  findOrderForTracking: (orderId: string, phone: string) => Order | undefined;
  findOrderBySearch: (query: string) => Order | undefined;
  latestPlacedOrder: Order | null;
}

const OrderContext = createContext<OrderContextType | undefined>(undefined);

const ORDERS_STORAGE_KEY = 'sdc_all_orders';

const SEEDED_ORDERS: Order[] = [
  {
    id: 'SDC-2026-001245',
    createdAt: '2026-09-22T14:30:00Z',
    customer: {
      name: 'Santosh Gayake',
      phone: '+91 98230 45678',
      email: 'santoshgayake43222@gmail.com',
    },
    address: {
      fullName: 'Santosh Gayake',
      phone: '+91 98230 45678',
      email: 'santoshgayake43222@gmail.com',
      houseFlat: 'Flat 402, Tower B',
      building: 'EON Waterfront Apartments',
      street: 'Kharadi Bypass Road',
      area: 'Kharadi',
      city: 'Pune',
      state: 'Maharashtra',
      pincode: '411014',
      landmark: 'Near WTC',
      addressType: 'home',
    },
    deliveryDate: '2026-09-23',
    deliveryTimeSlot: '04:00 PM – 06:00 PM (Evening Slot)',
    items: [
      {
        productId: 'cake-001',
        name: 'Belgian Chocolate Truffle Cake',
        image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80',
        weight: '1kg',
        flavor: 'Chocolate',
        eggless: true,
        customMessage: 'Happy 30th Birthday!',
        quantity: 1,
        unitPrice: 1165,
        totalPrice: 1165,
      },
    ],
    subtotal: 1165,
    discountAmount: 116,
    appliedCoupon: 'FIRST10',
    deliveryFee: 0,
    taxAmount: 52,
    grandTotal: 1101,
    paymentMethod: 'upi',
    paymentStatus: 'Paid',
    status: 'Preparing',
    notes: 'Please add birthday sparkler candle',
  },
  {
    id: 'SDC-2026-001198',
    createdAt: '2026-09-20T10:15:00Z',
    customer: {
      name: 'Pooja Kulkarni',
      phone: '+91 97654 32109',
      email: 'pooja.k@gmail.com',
    },
    address: {
      fullName: 'Pooja Kulkarni',
      phone: '+91 97654 32109',
      email: 'pooja.k@gmail.com',
      houseFlat: 'Row House 4',
      building: 'Clover Palisades',
      street: 'Kalyani Nagar Main Rd',
      area: 'Kalyani Nagar',
      city: 'Pune',
      state: 'Maharashtra',
      pincode: '411006',
      addressType: 'home',
    },
    deliveryDate: '2026-09-20',
    deliveryTimeSlot: '06:00 PM – 08:00 PM (Party Slot)',
    items: [
      {
        productId: 'cake-002',
        name: 'Royal Red Velvet Cream Cheese Cake',
        image: 'https://images.unsplash.com/photo-1586788680434-30d324b2d46f?auto=format&fit=crop&w=800&q=80',
        weight: '1kg',
        flavor: 'Red Velvet',
        eggless: true,
        customMessage: 'Happy Anniversary Mom & Dad',
        quantity: 1,
        unitPrice: 1300,
        totalPrice: 1300,
      },
    ],
    subtotal: 1300,
    discountAmount: 200,
    appliedCoupon: 'CAKE20',
    deliveryFee: 0,
    taxAmount: 55,
    grandTotal: 1155,
    paymentMethod: 'card',
    paymentStatus: 'Paid',
    status: 'Delivered',
  },
];

export const OrderProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { showToast } = useNotification();

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem(ORDERS_STORAGE_KEY);
    return saved ? JSON.parse(saved) : SEEDED_ORDERS;
  });

  const [latestPlacedOrder, setLatestPlacedOrder] = useState<Order | null>(null);

  useEffect(() => {
    localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(orders));
  }, [orders]);

  const createOrder = (orderData: Omit<Order, 'id' | 'createdAt' | 'status'>): Order => {
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const orderId = `SDC-2026-${randomSuffix}`;

    const newOrder: Order = {
      ...orderData,
      id: orderId,
      createdAt: new Date().toISOString(),
      status: 'Confirmed',
    };

    setOrders((prev) => [newOrder, ...prev]);
    setLatestPlacedOrder(newOrder);
    showToast(`Order placed successfully! Order #${orderId}`, 'success');
    return newOrder;
  };

  const updateOrderStatus = (orderId: string, status: OrderStatus) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status } : o))
    );
    showToast(`Order #${orderId} status updated to: ${status}`, 'info');
  };

  const getOrderById = (orderId: string): Order | undefined => {
    return orders.find((o) => o.id.toLowerCase() === orderId.toLowerCase().trim());
  };

  const findOrderForTracking = (orderId: string, phone: string): Order | undefined => {
    const cleanId = orderId.trim().toLowerCase();
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    return orders.find((o) => {
      const idMatches = o.id.toLowerCase() === cleanId;
      const orderPhoneClean = o.customer.phone.replace(/[^0-9]/g, '');
      const phoneMatches = !cleanPhone || orderPhoneClean.includes(cleanPhone) || cleanPhone.includes(orderPhoneClean);
      return idMatches && phoneMatches;
    });
  };

  const findOrderBySearch = (query: string): Order | undefined => {
    const clean = query.trim().toLowerCase();
    const phoneClean = query.replace(/[^0-9]/g, '');
    return orders.find((o) => {
      const matchId = o.id.toLowerCase().includes(clean);
      const matchCustomer = o.customer.name.toLowerCase().includes(clean);
      const matchPhone = phoneClean.length >= 4 && o.customer.phone.replace(/[^0-9]/g, '').includes(phoneClean);
      return matchId || matchCustomer || matchPhone;
    });
  };

  return (
    <OrderContext.Provider
      value={{
        orders,
        createOrder,
        updateOrderStatus,
        getOrderById,
        findOrderForTracking,
        findOrderBySearch,
        latestPlacedOrder,
      }}
    >
      {children}
    </OrderContext.Provider>
  );
};

export const useOrders = () => {
  const context = useContext(OrderContext);
  if (!context) {
    throw new Error('useOrders must be used within an OrderProvider');
  }
  return context;
};

export const useOrder = useOrders;

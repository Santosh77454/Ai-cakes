export interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

export const FAQS: FAQItem[] = [
  {
    id: 'faq-1',
    question: 'How early should I order a cake?',
    answer:
      'For standard cakes, we recommend ordering at least 3–4 hours in advance for same-day delivery. For custom theme cakes, 2-tier wedding cakes, or photo cakes, please order 24–48 hours ahead to allow our pastry artisans enough time to craft your design.',
  },
  {
    id: 'faq-2',
    question: 'Do you provide same-day delivery?',
    answer:
      'Yes! We provide same-day delivery across Pune for orders placed before 2:00 PM. You can choose from our convenient 2-hour delivery windows during checkout.',
  },
  {
    id: 'faq-3',
    question: 'Do you have eggless cakes?',
    answer:
      'Absolutely! Over 80% of our cake catalog is available in 100% vegetarian (eggless) preparations. Each product card clearly indicates whether it is eggless.',
  },
  {
    id: 'faq-4',
    question: 'Can I customize a cake?',
    answer:
      'Yes! You can use our interactive "Design Your Own Cake" builder to choose shape, size, flavors, cream colors, decorations, and custom messages. You can also upload a reference photo.',
  },
  {
    id: 'faq-5',
    question: 'Can I upload a photo for a photo cake?',
    answer:
      'Yes, on our Photo Cake page or custom builder, you can upload any high-resolution JPG or PNG photo. We print it on edible sugar icing sheets using certified food-grade ink.',
  },
  {
    id: 'faq-6',
    question: 'Can I add a message on the cake?',
    answer:
      'Yes, every cake order comes with a free customized message field (up to 35 characters) that our bakers will hand-pipe on the cake or chocolate placard.',
  },
  {
    id: 'faq-7',
    question: 'What payment methods are available?',
    answer:
      'We accept Cash on Delivery (COD), UPI (Google Pay, PhonePe, Paytm), Credit/Debit Cards (Visa, Mastercard, RuPay), and Net Banking across major banks.',
  },
  {
    id: 'faq-8',
    question: 'Can I cancel or modify my order?',
    answer:
      'Orders can be cancelled or rescheduled up to 4 hours before your chosen delivery slot by contacting our customer care or sending a quick WhatsApp message with your Order ID.',
  },
  {
    id: 'faq-9',
    question: 'Can I change the delivery time slot?',
    answer:
      'Yes, as long as the cake has not been dispatched with our delivery partner, we are happy to adjust your delivery window. Contact our support via WhatsApp.',
  },
  {
    id: 'faq-10',
    question: 'Do you deliver on Sundays and public holidays?',
    answer:
      'Yes! We bake and deliver 7 days a week, including Sundays and major festive holidays from 9:00 AM to 10:00 PM.',
  },
  {
    id: 'faq-11',
    question: 'Do you provide birthday decorations and add-ons?',
    answer:
      'Yes, during customization you can add sparkler candles, wooden knives, handwritten greeting cards, helium balloons, floral bouquets, and acrylic cake toppers.',
  },
  {
    id: 'faq-12',
    question: 'Do you provide bulk orders for corporate events or weddings?',
    answer:
      'Yes, we cater corporate milestones, launch parties, and weddings with special tiered discounts and custom dessert tables. Reach out via our Contact Us page or WhatsApp.',
  },
];

import { Review } from '../types';

export const REVIEWS: Review[] = [
  {
    id: 'rev-1',
    customerName: 'Aarav Sharma',
    rating: 5,
    comment:
      'Beautiful cake and amazing taste! Ordered the Belgian Chocolate Truffle for my wife’s 30th birthday in Viman Nagar. Delivered right at 7 PM in flawless condition.',
    cakePurchased: 'Belgian Chocolate Truffle Cake',
    date: '18 Sep 2026',
    verifiedBuyer: true,
  },
  {
    id: 'rev-2',
    customerName: 'Pooja Kulkarni',
    rating: 5,
    comment:
      'Ordered a custom photo cake for my daughter’s 5th birthday. The print quality on the icing was crystal clear and the cake sponge was super moist and eggless. Everyone loved it!',
    cakePurchased: 'Personalized Custom Photo Cake',
    date: '14 Sep 2026',
    verifiedBuyer: true,
  },
  {
    id: 'rev-3',
    customerName: 'Rohan Deshmukh',
    rating: 5,
    comment:
      'The cake looked exactly like the reference design we sent. Flavour was rich without being overly sugary. Sweet Delight Cakes is now our family bakery for all celebrations.',
    cakePurchased: 'Royal Red Velvet Cream Cheese Cake',
    date: '10 Sep 2026',
    verifiedBuyer: true,
  },
  {
    id: 'rev-4',
    customerName: 'Sneha Patel',
    rating: 5,
    comment:
      'Same-day delivery was a lifesaver! Placed an order at 11 AM and had a gorgeous crunchy butterscotch cake delivered to our office by 3 PM. Crisp packaging too.',
    cakePurchased: 'Crunchy Butterscotch Praline Cake',
    date: '05 Sep 2026',
    verifiedBuyer: true,
  },
  {
    id: 'rev-5',
    customerName: 'Vikram Mehta',
    rating: 4,
    comment:
      'Wild Blueberry Cheesecake was heavenly. Smooth texture, authentic graham base, and generous blueberry topping. 10/10 recommended for dessert aficionados.',
    cakePurchased: 'Wild Blueberry Glaze Cheesecake',
    date: '29 Aug 2026',
    verifiedBuyer: true,
  },
];

import { Coupon } from '../types';

export const INITIAL_COUPONS: Coupon[] = [
  {
    code: 'FIRST10',
    description: 'Get 10% flat discount on your very first cake order!',
    discountType: 'percentage',
    discountValue: 10,
    minOrderValue: 499,
    maxDiscount: 200,
    expiryDate: '2026-12-31',
    isActive: true,
  },
  {
    code: 'CAKE20',
    description: 'Flat ₹200 OFF on premium celebration cakes.',
    discountType: 'fixed',
    discountValue: 200,
    minOrderValue: 999,
    expiryDate: '2026-11-30',
    isActive: true,
  },
  {
    code: 'SWEET15',
    description: 'Get 15% OFF on luxury orders above ₹1,499.',
    discountType: 'percentage',
    discountValue: 15,
    minOrderValue: 1499,
    maxDiscount: 400,
    expiryDate: '2026-10-31',
    isActive: true,
  },
  {
    code: 'DELIGHT50',
    description: 'Enjoy ₹50 off on weekend bakery orders.',
    discountType: 'fixed',
    discountValue: 50,
    minOrderValue: 599,
    expiryDate: '2026-12-31',
    isActive: true,
  },
];

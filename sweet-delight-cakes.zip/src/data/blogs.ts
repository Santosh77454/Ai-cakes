import { BlogPost } from '../types';

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 'blog-1',
    title: '10 Best Cake Ideas for Milestone Birthday Parties',
    slug: '10-best-cake-ideas-for-birthday-parties',
    category: 'Birthday Guides',
    excerpt:
      'From theatrical chocolate drips to vintage pastel lambeth piping, discover trends turning birthday desserts into conversation starters.',
    content: `When planning a milestone celebration—be it an energetic 18th, a celebratory 30th, or a golden 50th—the cake is the undeniable centerpiece of the celebration. 

Here are top 10 trends that our master bakers swear by this year:
1. **Belgian Chocolate Truffle Drips**: Dramatic chocolate ganache drips embellished with metallic macarons and gold leaf flakes.
2. **Vintage Lambeth Frill Piping**: Intricate multi-layered ruffle shell borders reminiscent of classic Parisian patisseries.
3. **High-Definition Edible Photo Cakes**: Crisp family portraits or comic prints on silky fondant icing sheets.
4. **Minimalist Korean Bento Cakes**: Compact 300g cakes with witty pastel handwriting for intimate celebrations.
5. **Fresh Berry Towers**: Layered sponge towers crowned with fresh raspberries, blueberries, and fragrant mint leaves.

Remember to balance sweetness with sponge moisture, and always order at least 4 hours before your party schedule!`,
    coverImage: 'https://images.unsplash.com/photo-1558301211-0d8c8ddee6ec?auto=format&fit=crop&w=800&q=80',
    publishedDate: '15 Sep 2026',
    readTime: '4 min read',
    author: 'Chef Ananya Sen',
  },
  {
    id: 'blog-2',
    title: 'Chocolate Cake vs Red Velvet Cake: How to Choose',
    slug: 'chocolate-cake-vs-red-velvet-cake',
    category: 'Flavor Guide',
    excerpt:
      'Torn between the rich cocoa punch of Belgian chocolate and the velvety tang of Philadelphia cream cheese? Here is our ultimate guide.',
    content: `It is the age-old dessert debate: should you choose an indulgent dark chocolate truffle or opt for the romantic elegance of a red velvet gateau?

### The Case for Chocolate
Rich, comforting, and universally adored by kids and adults alike. A dark chocolate cake with 55% cocoa offers deep roasted undertones and satisfies serious cocoa cravings.

### The Case for Red Velvet
Red velvet is not just chocolate dyed crimson—authentic red velvet features a mild cocoa base complemented by buttermilk tang and real cream cheese frosting. It is lighter on the palate and visually stunning for anniversaries, proposals, and evening galas.`,
    coverImage: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80',
    publishedDate: '08 Sep 2026',
    readTime: '3 min read',
    author: 'Chef Rohan Verma',
  },
  {
    id: 'blog-3',
    title: 'How to Choose the Right Cake Size for Your Guests',
    slug: 'how-to-choose-the-right-cake-size',
    category: 'Baking Tips',
    excerpt:
      'Never run short or end up with massive leftovers again. Use our accurate cake weight vs guest serving calculator.',
    content: `One of the most common questions our bakery receives daily is: *"How many kilograms of cake do I need for my party?"*

Here is our quick rule of thumb for dessert portions:
- **500g (Half Kg)**: Perfect for intimate celebrations of 4 to 6 people.
- **1 Kg**: Ideal for small family gatherings and dinner parties of 8 to 12 people.
- **1.5 Kg**: Feeds 15 to 18 guests comfortably.
- **2 Kg**: Suitable for medium gatherings of 20 to 25 people.
- **3 Kg to 5 Kg**: Designed for grand birthday bashes, corporate milestones, or multi-tier wedding celebrations with 30+ attendees.

*Pro tip: If your menu already features other desserts like ice cream or gulab jamun, count on 80g per guest!*`,
    coverImage: 'https://images.unsplash.com/photo-1535141192574-5d4897c13136?auto=format&fit=crop&w=800&q=80',
    publishedDate: '01 Sep 2026',
    readTime: '3 min read',
    author: 'Sweet Delight Editorial',
  },
  {
    id: 'blog-4',
    title: 'Best Eggless Cake Options That Taste Incredible',
    slug: 'best-eggless-cake-options',
    category: 'Dietary Insights',
    excerpt:
      'Debunking the myth that eggless cakes are dense or dry. Learn how our yogurt and buttermilk sponges achieve melt-in-mouth softness.',
    content: `For decades, the word 'eggless' was unfairly associated with heavy sponges or rubbery textures. At Sweet Delight Cakes, 85% of our entire range is 100% pure vegetarian and eggless—without sacrificing a crumb of fluffiness!

Using cultured yogurt, condensed milk reductions, and premium cold-pressed bakery emulsions, our eggless cakes boast high moisture retention and feather-light textures that leave even traditional egg cake lovers in awe.`,
    coverImage: 'https://images.unsplash.com/photo-1563729784474-d77dbb933a9e?auto=format&fit=crop&w=800&q=80',
    publishedDate: '24 Aug 2026',
    readTime: '4 min read',
    author: 'Chef Ananya Sen',
  },
  {
    id: 'blog-5',
    title: 'How to Store and Serve Your Cake Properly',
    slug: 'how-to-store-a-cake-properly',
    category: 'Storage Guide',
    excerpt:
      'Temperature matters! Learn the exact degrees and prep times to ensure your frosting is silky and the sponge is at peak flavor.',
    content: `Ever cut into a cake straight out of the fridge and found the sponge firm and cold? 

**The Golden 20-Minute Rule:**
Always pull fresh cream and buttercream cakes out of the refrigerator 20–30 minutes before serving. This allows the dairy fats in the ganache and buttercream to soften to room temperature (22°C–24°C), releasing their aromatic bouquet.

*Exception*: Pure fresh fruit gateaux and whipped cream cakes in hot summers should be kept chilled until 10 minutes before candle lighting.`,
    coverImage: 'https://images.unsplash.com/photo-1606890737304-57a1ca8a5b62?auto=format&fit=crop&w=800&q=80',
    publishedDate: '18 Aug 2026',
    readTime: '3 min read',
    author: 'Sweet Delight Editorial',
  },
];

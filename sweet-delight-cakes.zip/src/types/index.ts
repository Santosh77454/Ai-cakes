export type WeightOption = '500g' | '1kg' | '1.5kg' | '2kg' | '3kg' | '5kg';

export type FlavorOption =
  | 'Chocolate'
  | 'Vanilla'
  | 'Strawberry'
  | 'Red Velvet'
  | 'Butterscotch'
  | 'Black Forest'
  | 'Pineapple'
  | 'Mango'
  | 'Blueberry'
  | 'Coffee Mousse'
  | 'Pistachio Rose';

export interface CakeAddOn {
  id: string;
  name: string;
  price: number;
  iconName: string;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  category: string;
  flavors: FlavorOption[];
  defaultFlavor: FlavorOption;
  weights: WeightOption[];
  defaultWeight: WeightOption;
  basePrice: number; // For 500g
  discountPercent: number; // e.g. 10 for 10%
  rating: number;
  reviewCount: number;
  images: string[];
  eggless: boolean;
  bestseller: boolean;
  featured: boolean;
  newArrival: boolean;
  stock: number;
  tags: string[];
  occasion?: string[];
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  image: string;
  productCount: number;
  featured?: boolean;
}

export interface CartItem {
  id: string; // Unique cart item ID (combining product ID + weight + flavor + custom message)
  productId: string;
  name: string;
  image: string;
  weight: WeightOption;
  flavor: FlavorOption;
  eggless: boolean;
  customMessage?: string;
  customPhoto?: string; // Base64 data URL for photo cakes
  selectedAddOns: { id: string; name: string; price: number }[];
  unitPrice: number;
  quantity: number;
  totalPrice: number;
}

export type DeliverySlot =
  | 'Morning (9 AM - 12 PM)'
  | 'Afternoon (12 PM - 3 PM)'
  | 'Evening (3 PM - 7 PM)'
  | 'Midnight (11 PM - 12 AM)'
  | string;

export interface Coupon {
  id?: string;
  code: string;
  description: string;
  discountType: 'percentage' | 'fixed' | 'percent' | 'flat';
  discountValue: number; // 10% or ₹200
  minOrderValue: number;
  maxDiscount?: number;
  expiryDate?: string;
  validTill?: string;
  isActive?: boolean;
  active?: boolean;
}

export interface DeliveryAddress {
  id?: string;
  label?: 'Home' | 'Office' | 'Other' | string;
  street?: string;
  isDefault?: boolean;
  fullName?: string;
  phone?: string;
  email?: string;
  houseFlat?: string;
  building?: string;
  area?: string;
  city: string;
  state?: string;
  pincode: string;
  landmark?: string;
  addressType?: 'home' | 'work' | 'other';
}

export type OrderStatus =
  | 'Pending'
  | 'Placed'
  | 'Confirmed'
  | 'Preparing'
  | 'Baking'
  | 'Ready'
  | 'Out for Delivery'
  | 'Delivered'
  | 'Cancelled';

export type PaymentMethod =
  | 'cod'
  | 'upi'
  | 'card'
  | 'netbanking'
  | 'COD'
  | 'UPI'
  | 'Card'
  | 'NetBanking';

export interface OrderItem {
  productId: string;
  name: string;
  image: string;
  weight: string;
  flavor: string;
  eggless: boolean;
  customMessage?: string;
  customPhoto?: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  selectedAddOns?: { id: string; name: string; price: number }[];
}

export interface OrderCustomer {
  name: string;
  phone: string;
  email?: string;
  address?: string;
  city?: string;
  pincode?: string;
}

export interface Order {
  id: string; // e.g. SDC-2026-001245
  createdAt: string;
  customer: OrderCustomer;
  address?: DeliveryAddress;
  deliveryDate: string;
  deliveryTimeSlot?: string;
  deliverySlot?: string;
  items: OrderItem[];
  subtotal: number;
  discount?: number;
  discountAmount?: number;
  appliedCoupon?: string;
  couponCode?: string;
  deliveryFee: number;
  tax?: number;
  taxAmount?: number;
  grandTotal: number;
  paymentMethod: PaymentMethod | string;
  paymentStatus: 'Paid' | 'Pending' | 'COD' | 'Completed';
  status: OrderStatus;
  specialInstructions?: string;
  notes?: string;
}

export interface Review {
  id: string;
  customerName: string;
  rating: number;
  comment: string;
  cakePurchased: string;
  date: string;
  verifiedBuyer: boolean;
  avatar?: string;
}

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  category: string;
  excerpt: string;
  content: string;
  coverImage: string;
  publishedDate: string;
  readTime: string;
  author: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  savedAddresses: DeliveryAddress[];
  addresses: DeliveryAddress[];
  createdAt: string;
}

export interface ShopSettings {
  shopName: string;
  tagline: string;
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
  city: string;
  currency: string;
  currencySymbol: string;
  taxRatePercent: number; // e.g. 5%
  standardDeliveryFee: number;
  freeDeliveryThreshold: number;
  sameDayCutoffTime: string; // e.g. "14:00"
  announcementBarMessage: string;
  announcementActive: boolean;
  supportedPincodes: string[];
  deliveryAreas: string[];
}

import { ShopSettings, CakeAddOn } from '../types';

export const initialShopConfig: ShopSettings = {
  shopName: 'Sweet Delight Cakes',
  tagline: 'Made with Love, Baked with Happiness.',
  phone: '+91 98230 45678',
  whatsapp: '+91 98230 45678',
  email: 'hello@sweetdelightcakes.com',
  address: 'Shop 12, Royale Palms Avenue, East Pune, Maharashtra 411014',
  city: 'Pune',
  currency: 'INR',
  currencySymbol: '₹',
  taxRatePercent: 5,
  standardDeliveryFee: 50,
  freeDeliveryThreshold: 999,
  sameDayCutoffTime: '14:00',
  announcementBarMessage: '🎂 Same-Day Delivery in Pune | Order Before 2 PM | Free Delivery Above ₹999',
  announcementActive: true,
  supportedPincodes: [
    '411014', // Viman Nagar
    '411006', // Yerwada / Airport
    '411011', // Camp
    '411028', // Hadapsar
    '411036', // Mundhwa
    '412207', // Wagholi
    '411014', // Kharadi
    '411028', // Magarpatta
    '411036', // Keshav Nagar
    '411001', // Pune Station
    '411016', // Shivaji Nagar
    '411004', // Deccan
  ],
  deliveryAreas: [
    'Kharadi',
    'Viman Nagar',
    'Hadapsar',
    'Wagholi',
    'Keshav Nagar',
    'Magarpatta',
    'Koregaon Park',
    'Kalyani Nagar',
    'Camp',
    'Yerawada',
  ],
};

export const AVAILABLE_ADDONS: CakeAddOn[] = [
  { id: 'addon-candles', name: 'Premium Sparkler Candles (Pack of 4)', price: 49, iconName: 'Flame' },
  { id: 'addon-knife', name: 'Decorative Wooden Cake Knife', price: 29, iconName: 'Scissors' },
  { id: 'addon-card', name: 'Handwritten Message Greeting Card', price: 39, iconName: 'Mail' },
  { id: 'addon-flowers', name: 'Fresh Rose Bouquet (6 Stems)', price: 299, iconName: 'Flower2' },
  { id: 'addon-chocolates', name: 'Belgian Truffle Box (4 pcs)', price: 199, iconName: 'Gift' },
  { id: 'addon-balloon', name: 'Metallic Helium Birthday Balloon', price: 99, iconName: 'PartyPopper' },
  { id: 'addon-topper', name: 'Golden Acrylic "Happy Birthday" Topper', price: 79, iconName: 'Sparkles' },
];

export const WEIGHT_PRICE_MULTIPLIERS: Record<string, number> = {
  '500g': 1.0,
  '1kg': 1.85,
  '1.5kg': 2.7,
  '2kg': 3.5,
  '3kg': 5.1,
  '5kg': 8.2,
};

export const DELIVERY_TIME_SLOTS = [
  '10:00 AM – 12:00 PM (Morning Slot)',
  '12:00 PM – 02:00 PM (Lunch Slot)',
  '02:00 PM – 04:00 PM (Afternoon Slot)',
  '04:00 PM – 06:00 PM (Evening Slot)',
  '06:00 PM – 08:00 PM (Party Slot)',
  '08:00 PM – 10:00 PM (Celebration Night Slot)',
];

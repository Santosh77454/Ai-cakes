import React from 'react';
import { Home, Grid, Search, ShoppingBag, User } from 'lucide-react';
import { useCart } from '../../context/CartContext';

interface MobileBottomNavProps {
  currentTab: string;
  onNavigate: (tab: string) => void;
  onOpenSearch: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  currentTab,
  onNavigate,
  onOpenSearch,
}) => {
  const { itemCount, openCartDrawer } = useCart();

  return (
    <nav
      aria-label="Mobile navigation bar"
      className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-[#EBE3D7] py-2 px-3 flex items-center justify-around shadow-lg"
    >
      <button
        onClick={() => onNavigate('home')}
        className={`flex flex-col items-center gap-1 text-[11px] font-medium transition-colors ${
          currentTab === 'home' ? 'text-[#8C4E28]' : 'text-stone-500 hover:text-stone-900'
        }`}
      >
        <Home className="w-5 h-5" />
        <span>Home</span>
      </button>

      <button
        onClick={() => onNavigate('cakes')}
        className={`flex flex-col items-center gap-1 text-[11px] font-medium transition-colors ${
          currentTab === 'cakes' ? 'text-[#8C4E28]' : 'text-stone-500 hover:text-stone-900'
        }`}
      >
        <Grid className="w-5 h-5" />
        <span>Cakes</span>
      </button>

      <button
        onClick={onOpenSearch}
        className="flex flex-col items-center gap-1 text-[11px] font-medium text-stone-500 hover:text-stone-900 transition-colors"
      >
        <Search className="w-5 h-5" />
        <span>Search</span>
      </button>

      <button
        onClick={openCartDrawer}
        className="flex flex-col items-center gap-1 text-[11px] font-medium text-stone-500 hover:text-stone-900 transition-colors relative"
      >
        <ShoppingBag className="w-5 h-5" />
        {itemCount > 0 && (
          <span className="absolute -top-1 right-2 w-4 h-4 bg-[#361F13] text-[#FAF7F2] text-[10px] font-bold rounded-full flex items-center justify-center">
            {itemCount}
          </span>
        )}
        <span>Cart</span>
      </button>

      <button
        onClick={() => onNavigate('account')}
        className={`flex flex-col items-center gap-1 text-[11px] font-medium transition-colors ${
          currentTab === 'account' ? 'text-[#8C4E28]' : 'text-stone-500 hover:text-stone-900'
        }`}
      >
        <User className="w-5 h-5" />
        <span>Account</span>
      </button>
    </nav>
  );
};

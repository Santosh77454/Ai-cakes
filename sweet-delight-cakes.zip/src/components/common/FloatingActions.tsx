import React from 'react';
import { Phone, MessageCircle } from 'lucide-react';
import { useShop } from '../../context/ShopContext';

interface FloatingActionsProps {
  productContextName?: string;
}

export const FloatingActions: React.FC<FloatingActionsProps> = ({ productContextName }) => {
  const { settings } = useShop();

  const cleanPhone = settings.phone.replace(/[^0-9+]/g, '');
  const cleanWhatsapp = settings.whatsapp.replace(/[^0-9]/g, '');

  const whatsappMessage = encodeURIComponent(
    productContextName
      ? `Hello Sweet Delight Cakes! I am interested in ordering: ${productContextName}.`
      : 'Hello Sweet Delight Cakes! I would like to order a fresh cake.'
  );

  const whatsappUrl = `https://wa.me/${cleanWhatsapp}?text=${whatsappMessage}`;

  return (
    <div className="fixed bottom-20 lg:bottom-6 left-4 z-40 flex flex-col gap-2.5">
      {/* Floating WhatsApp Action */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="w-12 h-12 rounded-full bg-[#25D366] text-white flex items-center justify-center shadow-lg hover:scale-110 active:scale-95 transition-all group relative"
        aria-label="Chat with our bakery on WhatsApp"
      >
        <MessageCircle className="w-6 h-6 fill-current" />
        <span className="hidden group-hover:block absolute left-14 bg-white text-[#2D1B11] text-xs font-semibold px-2.5 py-1 rounded-md shadow-md whitespace-nowrap border border-stone-200">
          WhatsApp Bakery Chat
        </span>
      </a>

      {/* Floating Call Button on Mobile */}
      <a
        href={`tel:${cleanPhone}`}
        className="lg:hidden w-12 h-12 rounded-full bg-[#361F13] text-[#F3C488] flex items-center justify-center shadow-lg active:scale-95 transition-transform"
        aria-label={`Call bakery at ${settings.phone}`}
      >
        <Phone className="w-5 h-5" />
      </a>
    </div>
  );
};

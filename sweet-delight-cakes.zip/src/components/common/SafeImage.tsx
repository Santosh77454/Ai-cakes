import React, { useState } from 'react';
import { Cake } from 'lucide-react';

interface SafeImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  fallbackText?: string;
  className?: string;
}

export const SafeImage: React.FC<SafeImageProps> = ({
  src,
  alt = 'Cake presentation',
  className = '',
  fallbackText,
  ...props
}) => {
  const [hasError, setHasError] = useState(false);

  if (hasError || !src) {
    return (
      <div
        className={`bg-gradient-to-br from-[#FCEBEB] to-[#FCEFD9] flex flex-col items-center justify-center text-[#8C4E28] p-4 text-center select-none ${className}`}
      >
        <div className="w-10 h-10 rounded-full bg-white/80 shadow-xs flex items-center justify-center mb-1 text-[#C2872A]">
          <Cake className="w-5 h-5" />
        </div>
        <span className="text-xs font-medium tracking-tight text-[#361F13] line-clamp-1">
          {fallbackText || alt}
        </span>
        <span className="text-[10px] text-[#8C4E28]/70">Freshly Baked</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={className}
      loading="lazy"
      {...props}
    />
  );
};

import React, { useState } from 'react';
import { useShop } from '../../context/ShopContext';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';
import { useAuth } from '../../context/AuthContext';
import {
  Search,
  Heart,
  ShoppingBag,
  User,
  Menu,
  X,
  Sparkles,
  Cake,
  ShieldCheck,
} from 'lucide-react';

interface HeaderProps {
  currentTab: string;
  onNavigate: (tab: string, params?: Record<string, string>) => void;
  onOpenSearch: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onNavigate,
  onOpenSearch,
}) => {
  const { settings } = useShop();
  const { itemCount, openCartDrawer } = useCart();
  const { wishlistIds } = useWishlist();
  const { user, isAdmin, loginAsAdmin, logoutAdmin } = useAuth();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (tab: string) => {
    onNavigate(tab);
    setMobileMenuOpen(false);
  };

  return (
    <>
      {/* Top Announcement Bar */}
      {settings.announcementActive && (
        <aside
          aria-label="Promotional announcements"
          className="bg-[#361F13] text-[#FAF7F2] text-xs py-2 px-4 text-center font-medium tracking-wide flex items-center justify-center gap-2 border-b border-[#4A2D1E]"
        >
          <Sparkles className="w-3.5 h-3.5 text-[#F3C488] shrink-0" />
          <span className="truncate max-w-3xl">{settings.announcementBarMessage}</span>
          <span className="hidden md:inline-block text-[#D8C7B4] text-[11px] ml-2 font-normal">
            Call: {settings.phone}
          </span>
        </aside>
      )}

      {/* Main Sticky Header */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-[#EBE3D7] transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
          {/* Zone 1: Brand Wordmark (Single Text Element) */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => handleNavClick('home')}
              className="text-left group flex items-center gap-2.5 focus:outline-hidden"
              aria-label="Sweet Delight Cakes - Home"
            >
              <div className="w-10 h-10 rounded-xl bg-[#361F13] text-[#F3C488] flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform">
                <Cake className="w-5 h-5" />
              </div>
              <span className="font-serif text-2xl font-bold tracking-tight text-[#361F13] group-hover:text-[#8C4E28] transition-colors whitespace-nowrap">
                {settings.shopName}
              </span>
            </button>
          </div>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-[#4A3225]">
            <button
              onClick={() => handleNavClick('home')}
              className={`transition-colors hover:text-[#361F13] relative py-1 ${
                currentTab === 'home'
                  ? 'text-[#8C4E28] font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-[#8C4E28]'
                  : ''
              }`}
            >
              Home
            </button>
            <button
              onClick={() => handleNavClick('cakes')}
              className={`transition-colors hover:text-[#361F13] relative py-1 ${
                currentTab === 'cakes'
                  ? 'text-[#8C4E28] font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-[#8C4E28]'
                  : ''
              }`}
            >
              All Cakes
            </button>
            <button
              onClick={() => handleNavClick('custom-cake')}
              className={`transition-colors hover:text-[#361F13] relative py-1 ${
                currentTab === 'custom-cake'
                  ? 'text-[#8C4E28] font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-[#8C4E28]'
                  : ''
              }`}
            >
              Design Your Cake
            </button>
            <button
              onClick={() => handleNavClick('photo-cake')}
              className={`transition-colors hover:text-[#361F13] relative py-1 ${
                currentTab === 'photo-cake'
                  ? 'text-[#8C4E28] font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-[#8C4E28]'
                  : ''
              }`}
            >
              Photo Cakes
            </button>
            <button
              onClick={() => handleNavClick('offers')}
              className={`transition-colors hover:text-[#361F13] relative py-1 ${
                currentTab === 'offers'
                  ? 'text-[#8C4E28] font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-[#8C4E28]'
                  : ''
              }`}
            >
              Offers
            </button>
            <button
              onClick={() => handleNavClick('track-order')}
              className={`transition-colors hover:text-[#361F13] relative py-1 ${
                currentTab === 'track-order'
                  ? 'text-[#8C4E28] font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-[#8C4E28]'
                  : ''
              }`}
            >
              Track Order
            </button>
            <button
              onClick={() => handleNavClick('about')}
              className={`transition-colors hover:text-[#361F13] relative py-1 ${
                currentTab === 'about'
                  ? 'text-[#8C4E28] font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-[#8C4E28]'
                  : ''
              }`}
            >
              About
            </button>
            <button
              onClick={() => handleNavClick('contact')}
              className={`transition-colors hover:text-[#361F13] relative py-1 ${
                currentTab === 'contact'
                  ? 'text-[#8C4E28] font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-[#8C4E28]'
                  : ''
              }`}
            >
              Contact
            </button>
          </nav>

          {/* Zone 3: Interactive Actions */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Search Trigger */}
            <button
              onClick={onOpenSearch}
              className="p-2.5 text-[#4A3225] hover:text-[#361F13] hover:bg-[#FAF7F2] rounded-xl transition-colors"
              aria-label="Search cakes"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Wishlist */}
            <button
              onClick={() => handleNavClick('wishlist')}
              className="p-2.5 text-[#4A3225] hover:text-[#361F13] hover:bg-[#FAF7F2] rounded-xl transition-colors relative"
              aria-label={`Wishlist with ${wishlistIds.length} items`}
            >
              <Heart className="w-5 h-5" />
              {wishlistIds.length > 0 && (
                <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-[#8C4E28] text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                  {wishlistIds.length}
                </span>
              )}
            </button>

            {/* Cart Trigger */}
            <button
              onClick={openCartDrawer}
              className="p-2.5 text-[#4A3225] hover:text-[#361F13] hover:bg-[#FAF7F2] rounded-xl transition-colors relative"
              aria-label={`Cart with ${itemCount} items`}
            >
              <ShoppingBag className="w-5 h-5" />
              {itemCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-[#361F13] text-[#FAF7F2] text-[10px] font-bold rounded-full flex items-center justify-center">
                  {itemCount}
                </span>
              )}
            </button>

            {/* Account / Profile */}
            <button
              onClick={() => handleNavClick('account')}
              className="hidden sm:flex items-center gap-1.5 p-2 text-[#4A3225] hover:text-[#361F13] hover:bg-[#FAF7F2] rounded-xl transition-colors text-xs font-medium"
              aria-label="Customer account"
            >
              <User className="w-5 h-5" />
              <span className="truncate max-w-[80px]">
                {user ? user.name.split(' ')[0] : 'Sign In'}
              </span>
            </button>

            {/* Admin Switcher Toggle */}
            <button
              onClick={() => {
                if (isAdmin) {
                  onNavigate('admin');
                } else {
                  loginAsAdmin();
                  onNavigate('admin');
                }
              }}
              title={isAdmin ? 'Go to Admin Dashboard' : 'Open Admin Panel'}
              className="hidden md:flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-[#8C4E28] border border-[#E2D5C7] rounded-lg hover:bg-[#F8EFE4] transition-colors"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Admin</span>
            </button>

            {/* Primary Order Now Button */}
            <button
              onClick={() => handleNavClick('cakes')}
              className="hidden sm:inline-flex items-center justify-center px-4 py-2.5 text-xs font-semibold tracking-wide text-white bg-[#361F13] hover:bg-[#22120A] rounded-xl shadow-xs transition-colors whitespace-nowrap"
            >
              Order Now
            </button>

            {/* Mobile Hamburger Menu */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-[#4A3225] hover:text-[#361F13] hover:bg-[#FAF7F2] rounded-xl transition-colors"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-[#EBE3D7] bg-white px-4 py-5 shadow-xl animate-in slide-in-from-top-2">
            <div className="flex flex-col gap-3 text-sm font-medium text-[#4A3225]">
              <button
                onClick={() => handleNavClick('home')}
                className="text-left py-2 px-3 rounded-lg hover:bg-[#FAF7F2]"
              >
                Home
              </button>
              <button
                onClick={() => handleNavClick('cakes')}
                className="text-left py-2 px-3 rounded-lg hover:bg-[#FAF7F2]"
              >
                All Cakes Catalog
              </button>
              <button
                onClick={() => handleNavClick('custom-cake')}
                className="text-left py-2 px-3 rounded-lg hover:bg-[#FAF7F2]"
              >
                Design Your Own Cake
              </button>
              <button
                onClick={() => handleNavClick('photo-cake')}
                className="text-left py-2 px-3 rounded-lg hover:bg-[#FAF7F2]"
              >
                Personalized Photo Cakes
              </button>
              <button
                onClick={() => handleNavClick('offers')}
                className="text-left py-2 px-3 rounded-lg hover:bg-[#FAF7F2]"
              >
                Offers & Coupons
              </button>
              <button
                onClick={() => handleNavClick('track-order')}
                className="text-left py-2 px-3 rounded-lg hover:bg-[#FAF7F2]"
              >
                Track Your Order
              </button>
              <button
                onClick={() => handleNavClick('gallery')}
                className="text-left py-2 px-3 rounded-lg hover:bg-[#FAF7F2]"
              >
                Bakery Gallery
              </button>
              <button
                onClick={() => handleNavClick('blog')}
                className="text-left py-2 px-3 rounded-lg hover:bg-[#FAF7F2]"
              >
                Cake Ideas & Guides
              </button>
              <button
                onClick={() => handleNavClick('about')}
                className="text-left py-2 px-3 rounded-lg hover:bg-[#FAF7F2]"
              >
                About Our Bakery
              </button>
              <button
                onClick={() => handleNavClick('contact')}
                className="text-left py-2 px-3 rounded-lg hover:bg-[#FAF7F2]"
              >
                Contact & Timings
              </button>

              <div className="pt-3 border-t border-[#EBE3D7] flex items-center justify-between">
                <button
                  onClick={() => handleNavClick('account')}
                  className="flex items-center gap-2 py-2 px-3 text-[#361F13] font-semibold"
                >
                  <User className="w-4 h-4" />
                  <span>{user ? user.name : 'Sign In / Account'}</span>
                </button>

                <button
                  onClick={() => {
                    if (!isAdmin) loginAsAdmin();
                    handleNavClick('admin');
                  }}
                  className="flex items-center gap-1.5 py-1.5 px-3 bg-[#FAF7F2] text-[#8C4E28] rounded-lg text-xs font-semibold"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Admin Panel</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </header>
    </>
  );
};

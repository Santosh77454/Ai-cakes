import React, { useState } from 'react';
import { useShop } from '../../context/ShopContext';
import { useNotification } from '../../context/NotificationContext';
import {
  Cake,
  Phone,
  Mail,
  MapPin,
  Clock,
  Heart,
  Instagram,
  Facebook,
  ShieldCheck,
  Send,
} from 'lucide-react';

interface FooterProps {
  onNavigate: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const { settings } = useShop();
  const { showToast } = useNotification();
  const [newsletterEmail, setNewsletterEmail] = useState('');

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim() || !newsletterEmail.includes('@')) {
      showToast('Please enter a valid email address.', 'error');
      return;
    }
    showToast('Subscribed to sweet secret offers & recipes! 🧁', 'success');
    setNewsletterEmail('');
  };

  return (
    <footer className="bg-[#2D1B11] text-[#FAF7F2] border-t border-[#4A2D1E] pt-16 pb-24 lg:pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Col 1: Brand & Story */}
          <div className="space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-[#F3C488] text-[#361F13] flex items-center justify-center font-bold">
                <Cake className="w-5 h-5" />
              </div>
              <span className="font-serif text-2xl font-bold tracking-tight text-white">
                {settings.shopName}
              </span>
            </div>
            <p className="text-xs text-[#D8C7B4] leading-relaxed">
              &quot;{settings.tagline}&quot; Handcrafting artisan celebration cakes, designer wedding cakes, and fresh fruit pastries since 2015.
            </p>
            <div className="pt-2 flex items-center gap-3">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Instagram"
                className="w-8 h-8 rounded-lg bg-white/10 hover:bg-[#F3C488] hover:text-[#361F13] text-white flex items-center justify-center transition-colors"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Facebook"
                className="w-8 h-8 rounded-lg bg-white/10 hover:bg-[#F3C488] hover:text-[#361F13] text-white flex items-center justify-center transition-colors"
              >
                <Facebook className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div>
            <h4 className="font-serif text-sm font-bold uppercase tracking-wider text-[#F3C488] mb-4">
              Explore Cakes
            </h4>
            <ul className="space-y-2.5 text-xs text-[#D8C7B4]">
              <li>
                <button
                  onClick={() => onNavigate('cakes')}
                  className="hover:text-white transition-colors"
                >
                  All Cakes Catalog
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('custom-cake')}
                  className="hover:text-white transition-colors"
                >
                  Design Your Own Cake
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('photo-cake')}
                  className="hover:text-white transition-colors"
                >
                  Edible Photo Cakes
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('offers')}
                  className="hover:text-white transition-colors"
                >
                  Bakery Coupons & Offers
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('gallery')}
                  className="hover:text-white transition-colors"
                >
                  Celebration Gallery
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('blog')}
                  className="hover:text-white transition-colors"
                >
                  Cake Inspiration & Tips
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Customer Care & Hours */}
          <div>
            <h4 className="font-serif text-sm font-bold uppercase tracking-wider text-[#F3C488] mb-4">
              Bakery Information
            </h4>
            <ul className="space-y-3 text-xs text-[#D8C7B4]">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#F3C488] shrink-0 mt-0.5" />
                <span>{settings.address}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#F3C488] shrink-0" />
                <a href={`tel:${settings.phone}`} className="hover:text-white">
                  {settings.phone}
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#F3C488] shrink-0" />
                <a href={`mailto:${settings.email}`} className="hover:text-white">
                  {settings.email}
                </a>
              </li>
              <li className="flex items-start gap-2.5">
                <Clock className="w-4 h-4 text-[#F3C488] shrink-0 mt-0.5" />
                <div>
                  <span className="block">Mon – Sat: 9:00 AM – 10:00 PM</span>
                  <span className="block">Sunday: 10:00 AM – 10:00 PM</span>
                </div>
              </li>
            </ul>
          </div>

          {/* Col 4: Newsletter */}
          <div>
            <h4 className="font-serif text-sm font-bold uppercase tracking-wider text-[#F3C488] mb-4">
              Join The Cake Club
            </h4>
            <p className="text-xs text-[#D8C7B4] leading-relaxed mb-3">
              Subscribe for secret weekend discount codes, seasonal berry specials, and complimentary birthday perks.
            </p>
            <form onSubmit={handleNewsletterSubmit} className="flex gap-2">
              <input
                type="email"
                placeholder="Enter your email"
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                className="flex-1 px-3 py-2 bg-white/10 border border-white/20 rounded-xl text-xs text-white placeholder-stone-400 focus:outline-hidden focus:border-[#F3C488]"
              />
              <button
                type="submit"
                className="p-2 bg-[#F3C488] hover:bg-[#E5B576] text-[#2D1B11] rounded-xl transition-colors shrink-0"
                aria-label="Subscribe"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>

            <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between">
              <span className="text-[11px] text-stone-400">Owner / Staff Access</span>
              <button
                onClick={() => onNavigate('admin')}
                className="text-[11px] text-[#F3C488] hover:underline flex items-center gap-1"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Admin Console</span>
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#A69382]">
          <p>© {new Date().getFullYear()} {settings.shopName}. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <button onClick={() => onNavigate('about')} className="hover:text-white">
              Privacy Policy
            </button>
            <span>·</span>
            <button onClick={() => onNavigate('contact')} className="hover:text-white">
              Terms of Delivery
            </button>
            <span>·</span>
            <button onClick={() => onNavigate('track-order')} className="hover:text-white">
              Order Tracking
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};

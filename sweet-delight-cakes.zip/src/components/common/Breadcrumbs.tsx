import React from 'react';
import { ChevronRight, Home } from 'lucide-react';

interface BreadcrumbItem {
  label: string;
  tab?: string;
  active?: boolean;
}

interface BreadcrumbsProps {
  items: BreadcrumbItem[];
  onNavigate: (tab: string) => void;
}

export const Breadcrumbs: React.FC<BreadcrumbsProps> = ({ items, onNavigate }) => {
  return (
    <nav aria-label="Breadcrumbs" className="flex items-center gap-1.5 text-xs text-[#715848] mb-6">
      <button
        onClick={() => onNavigate('home')}
        className="flex items-center gap-1 hover:text-[#361F13] transition-colors"
        aria-label="Home"
      >
        <Home className="w-3.5 h-3.5" />
        <span>Home</span>
      </button>

      {items.map((item, index) => (
        <React.Fragment key={index}>
          <ChevronRight className="w-3 h-3 text-[#B8A494] shrink-0" />
          {item.tab && !item.active ? (
            <button
              onClick={() => onNavigate(item.tab!)}
              className="hover:text-[#361F13] transition-colors truncate max-w-[150px]"
            >
              {item.label}
            </button>
          ) : (
            <span className="font-semibold text-[#361F13] truncate max-w-[200px]" aria-current="page">
              {item.label}
            </span>
          )}
        </React.Fragment>
      ))}
    </nav>
  );
};

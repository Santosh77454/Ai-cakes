import React, { useState, useMemo } from 'react';
import { useShop } from '../../context/ShopContext';
import { Search, X, ArrowRight, Cake, Sparkles } from 'lucide-react';
import { SafeImage } from './SafeImage';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectProduct: (productId: string) => void;
  onSelectCategory: (categoryName: string) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectProduct,
  onSelectCategory,
}) => {
  const { products, settings } = useShop();
  const [query, setQuery] = useState('');

  const filteredProducts = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];
    return products.filter((p) => {
      const matchName = p.name.toLowerCase().includes(q);
      const matchCat = p.category.toLowerCase().includes(q);
      const matchFlavor = p.flavors.some((f) => f.toLowerCase().includes(q));
      const matchTags = p.tags.some((t) => t.toLowerCase().includes(q));
      const matchOccasion = p.occasion?.some((o) => o.toLowerCase().includes(q));
      return matchName || matchCat || matchFlavor || matchTags || matchOccasion;
    });
  }, [query, products]);

  if (!isOpen) return null;

  const popularSearches = ['Chocolate', 'Birthday', 'Red Velvet', 'Eggless', 'Photo Cake', 'Pineapple'];

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-start justify-center pt-16 px-4 animate-in fade-in duration-200"
    >
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-[#EBE3D7] overflow-hidden flex flex-col max-h-[80vh]">
        {/* Search Input Bar */}
        <div className="p-4 border-b border-[#ECE2D6] flex items-center gap-3">
          <Search className="w-5 h-5 text-[#8C4E28] shrink-0" />
          <input
            type="text"
            autoFocus
            placeholder="Search by cake name, flavor, category, occasion (e.g. Chocolate, Birthday)..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1 text-base text-[#2D1B11] placeholder-stone-400 focus:outline-hidden bg-transparent"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-stone-400 hover:text-stone-700 p-1"
              aria-label="Clear search"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="text-xs font-semibold text-stone-500 hover:text-stone-900 px-2 py-1 rounded-md"
          >
            ESC
          </button>
        </div>

        {/* Content Area */}
        <div className="overflow-y-auto p-4 flex-1">
          {query.trim() === '' ? (
            <div>
              <div className="mb-4">
                <span className="text-xs font-semibold uppercase tracking-wider text-[#8C4E28] block mb-2">
                  Popular Searches
                </span>
                <div className="flex flex-wrap gap-2">
                  {popularSearches.map((term) => (
                    <button
                      key={term}
                      onClick={() => setQuery(term)}
                      className="px-3 py-1.5 bg-[#FAF7F2] hover:bg-[#F3EBE1] text-[#361F13] text-xs font-medium rounded-lg border border-[#E9DFD3] transition-colors"
                    >
                      {term}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <span className="text-xs font-semibold uppercase tracking-wider text-[#8C4E28] block mb-2">
                  Trending Best Sellers
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {products.filter((p) => p.bestseller).slice(0, 4).map((cake) => (
                    <div
                      key={cake.id}
                      onClick={() => {
                        onSelectProduct(cake.id);
                        onClose();
                      }}
                      className="flex items-center gap-3 p-2 rounded-xl hover:bg-[#FAF7F2] cursor-pointer transition-colors border border-transparent hover:border-[#E9DFD3]"
                    >
                      <SafeImage
                        src={cake.images[0]}
                        alt={cake.name}
                        className="w-12 h-12 rounded-lg object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold text-[#361F13] truncate">{cake.name}</p>
                        <p className="text-[11px] text-[#8C4E28] font-bold">
                          {settings.currencySymbol}
                          {cake.basePrice}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : filteredProducts.length > 0 ? (
            <div className="space-y-2">
              <span className="text-xs font-medium text-stone-500 block mb-2">
                Found {filteredProducts.length} matching cakes:
              </span>
              {filteredProducts.map((cake) => {
                const discountedPrice = Math.round(
                  cake.basePrice * (1 - cake.discountPercent / 100)
                );
                return (
                  <div
                    key={cake.id}
                    onClick={() => {
                      onSelectProduct(cake.id);
                      onClose();
                    }}
                    className="flex items-center justify-between p-2.5 rounded-xl hover:bg-[#FAF7F2] cursor-pointer border border-stone-100 hover:border-[#E8DDD1] transition-all group"
                  >
                    <div className="flex items-center gap-3">
                      <SafeImage
                        src={cake.images[0]}
                        alt={cake.name}
                        className="w-14 h-14 rounded-xl object-cover shrink-0"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-semibold text-[#361F13] group-hover:text-[#8C4E28] transition-colors">
                            {cake.name}
                          </h4>
                          {cake.eggless && (
                            <span className="text-[10px] text-emerald-700 bg-emerald-50 border border-emerald-200 px-1.5 rounded">
                              Eggless
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-stone-500 line-clamp-1">{cake.description}</p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-xs font-bold text-[#8C4E28]">
                            {settings.currencySymbol}
                            {discountedPrice}
                          </span>
                          {cake.discountPercent > 0 && (
                            <span className="text-[11px] text-stone-400 line-through">
                              {settings.currencySymbol}
                              {cake.basePrice}
                            </span>
                          )}
                          <span className="text-[11px] text-stone-400">· {cake.category}</span>
                        </div>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-stone-300 group-hover:text-[#8C4E28] group-hover:translate-x-1 transition-all shrink-0 ml-2" />
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="py-12 text-center">
              <div className="w-14 h-14 rounded-full bg-[#FAF7F2] text-[#8C4E28] mx-auto flex items-center justify-center mb-3">
                <Cake className="w-7 h-7" />
              </div>
              <h4 className="font-serif text-lg font-bold text-[#361F13]">No cakes found</h4>
              <p className="text-xs text-stone-500 max-w-xs mx-auto mt-1">
                We couldn&apos;t find any cake matching &quot;{query}&quot;. Try searching for &quot;Truffle&quot;, &quot;Fruit&quot;, or request a custom cake!
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

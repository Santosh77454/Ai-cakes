import React, { useState } from 'react';
import { useShop } from '../../context/ShopContext';
import { MapPin, CheckCircle, AlertCircle, Clock } from 'lucide-react';

export const PincodeChecker: React.FC = () => {
  const { settings, checkPincodeDelivery } = useShop();
  const [pincode, setPincode] = useState('');
  const [result, setResult] = useState<{ available: boolean; message: string } | null>(null);

  const handleCheck = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pincode.trim()) return;
    const res = checkPincodeDelivery(pincode);
    setResult(res);
  };

  return (
    <div className="bg-white rounded-2xl p-6 border border-[#E9DFD3] shadow-xs">
      <div className="flex items-start gap-3 mb-4">
        <div className="w-10 h-10 rounded-xl bg-[#FAF7F2] text-[#8C4E28] flex items-center justify-center shrink-0">
          <MapPin className="w-5 h-5" />
        </div>
        <div>
          <h3 className="font-serif text-lg font-bold text-[#361F13]">
            Check Delivery In Your Area
          </h3>
          <p className="text-xs text-[#715848] mt-0.5">
            Same-day delivery available across Pune for orders before {settings.sameDayCutoffTime}
          </p>
        </div>
      </div>

      <form onSubmit={handleCheck} className="flex gap-2">
        <input
          type="text"
          maxLength={6}
          placeholder="Enter 6-digit Pincode (e.g. 411014)"
          value={pincode}
          onChange={(e) => {
            setPincode(e.target.value.replace(/[^0-9]/g, ''));
            setResult(null);
          }}
          className="flex-1 px-3.5 py-2.5 bg-[#FAF7F2] border border-[#E2D5C7] rounded-xl text-sm focus:outline-hidden focus:border-[#8C4E28] focus:bg-white transition-colors"
        />
        <button
          type="submit"
          className="px-4 py-2.5 bg-[#361F13] hover:bg-[#22120A] text-white text-xs font-semibold rounded-xl transition-colors whitespace-nowrap"
        >
          Check
        </button>
      </form>

      {result && (
        <div
          className={`mt-3.5 p-3 rounded-xl text-xs flex items-start gap-2 ${
            result.available
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-amber-50 text-amber-800 border border-amber-200'
          }`}
        >
          {result.available ? (
            <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          ) : (
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          )}
          <span>{result.message}</span>
        </div>
      )}

      <div className="mt-4 pt-3 border-t border-[#F2EAE0]">
        <span className="text-[11px] font-semibold text-[#8C4E28] block mb-1.5 uppercase tracking-wider">
          Popular Daily Delivery Hubs:
        </span>
        <div className="flex flex-wrap gap-1.5 text-xs text-[#523B2D]">
          {settings.deliveryAreas.slice(0, 7).map((area) => (
            <span
              key={area}
              className="bg-[#FAF7F2] px-2 py-0.5 rounded-md border border-[#ECE2D6] text-[11px]"
            >
              {area}
            </span>
          ))}
          <span className="text-[11px] text-stone-400 self-center">+ more</span>
        </div>
      </div>
    </div>
  );
};

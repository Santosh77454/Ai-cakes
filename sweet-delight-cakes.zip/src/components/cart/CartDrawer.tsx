import React, { useState } from 'react';
import { useCart } from '../../context/CartContext';
import { useShop } from '../../context/ShopContext';
import { useWishlist } from '../../context/WishlistContext';
import { SafeImage } from '../common/SafeImage';
import {
  X,
  ShoppingBag,
  Trash2,
  Plus,
  Minus,
  ArrowRight,
  Tag,
  CheckCircle,
  AlertCircle,
  Heart,
  Gift,
} from 'lucide-react';

interface CartDrawerProps {
  onProceedToCheckout: () => void;
  onContinueShopping: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  onProceedToCheckout,
  onContinueShopping,
}) => {
  const {
    items,
    isCartDrawerOpen,
    closeCartDrawer,
    removeFromCart,
    updateQuantity,
    subtotal,
    discountAmount,
    deliveryFee,
    taxAmount,
    grandTotal,
    appliedCoupon,
    applyCoupon,
    removeCoupon,
    couponError,
  } = useCart();

  const { settings, products } = useShop();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const [couponInput, setCouponInput] = useState('');

  if (!isCartDrawerOpen) return null;

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponInput.trim()) return;
    const ok = applyCoupon(couponInput);
    if (ok) setCouponInput('');
  };

  const freeDeliveryRemaining = Math.max(0, settings.freeDeliveryThreshold - subtotal);

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex justify-end animate-in fade-in duration-200"
    >
      <div className="w-full max-w-md bg-white h-full flex flex-col justify-between shadow-2xl animate-in slide-in-from-right duration-250">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#EBE3D7] flex items-center justify-between bg-[#FAF7F2]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#361F13] text-[#F3C488] flex items-center justify-center">
              <ShoppingBag className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-serif text-lg font-bold text-[#361F13]">Your Cake Cart</h2>
              <span className="text-xs text-[#715848] font-medium">
                {items.length} {items.length === 1 ? 'item' : 'items'}
              </span>
            </div>
          </div>
          <button
            onClick={closeCartDrawer}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-800 hover:bg-white transition-colors"
            aria-label="Close cart"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Delivery Bar */}
        {items.length > 0 && (
          <div className="bg-[#FAF0E6] px-4 py-2 border-b border-[#E8DDD1] text-xs text-[#523B2D] flex items-center justify-between">
            {freeDeliveryRemaining > 0 ? (
              <span>
                Add{' '}
                <strong className="text-[#8C4E28] font-bold">
                  {settings.currencySymbol}
                  {freeDeliveryRemaining}
                </strong>{' '}
                more for <strong className="text-emerald-700">FREE Delivery</strong>
              </span>
            ) : (
              <span className="text-emerald-800 font-semibold flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                Congratulations! You unlocked FREE Delivery 🚚
              </span>
            )}
            <span className="text-[10px] text-stone-500">Above {settings.currencySymbol}{settings.freeDeliveryThreshold}</span>
          </div>
        )}

        {/* Cart Items List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {items.length === 0 ? (
            <div className="py-20 text-center flex flex-col items-center">
              <div className="w-16 h-16 rounded-full bg-[#FAF7F2] text-[#8C4E28] flex items-center justify-center mb-4">
                <ShoppingBag className="w-8 h-8 stroke-[1.5]" />
              </div>
              <h3 className="font-serif text-xl font-bold text-[#361F13]">Your cart is empty</h3>
              <p className="text-xs text-[#715848] max-w-xs mt-1 leading-relaxed">
                Looks like you haven&apos;t added any delicious cakes yet. Check out our bestselling cakes!
              </p>
              <button
                onClick={() => {
                  closeCartDrawer();
                  onContinueShopping();
                }}
                className="mt-6 px-6 py-2.5 bg-[#361F13] text-white text-xs font-semibold rounded-xl hover:bg-[#22120A] shadow-md transition-colors"
              >
                Browse Our Cakes
              </button>
            </div>
          ) : (
            items.map((item) => {
              const baseProduct = products.find((p) => p.id === item.productId);
              const isWishlisted = baseProduct ? isInWishlist(baseProduct.id) : false;

              return (
                <div
                  key={item.id}
                  className="flex gap-3.5 p-3 rounded-2xl border border-[#EDE3D6] bg-white hover:border-[#DECFC0] transition-colors"
                >
                  <SafeImage
                    src={item.image}
                    alt={item.name}
                    className="w-20 h-20 rounded-xl object-cover shrink-0 bg-stone-100"
                  />

                  <div className="flex-1 min-w-0 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between gap-1">
                        <h4 className="font-serif text-sm font-bold text-[#361F13] truncate">
                          {item.name}
                        </h4>
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="text-stone-400 hover:text-rose-600 p-1 transition-colors"
                          aria-label="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Customization Badges */}
                      <div className="flex flex-wrap gap-1 text-[11px] text-[#715848] mt-1">
                        <span className="bg-[#FAF7F2] px-1.5 py-0.5 rounded border border-[#E9DFD3] font-medium">
                          {item.weight}
                        </span>
                        <span className="bg-[#FAF7F2] px-1.5 py-0.5 rounded border border-[#E9DFD3] font-medium">
                          {item.flavor}
                        </span>
                        {item.eggless && (
                          <span className="bg-emerald-50 text-emerald-800 px-1.5 py-0.5 rounded border border-emerald-200">
                            Eggless
                          </span>
                        )}
                      </div>

                      {item.customMessage && (
                        <p className="text-[11px] text-[#8C4E28] italic mt-1 truncate">
                          &quot;{item.customMessage}&quot;
                        </p>
                      )}

                      {item.selectedAddOns && item.selectedAddOns.length > 0 && (
                        <p className="text-[10px] text-stone-500 mt-0.5">
                          + {item.selectedAddOns.map((a) => a.name).join(', ')}
                        </p>
                      )}
                    </div>

                    {/* Quantity & Item Subtotal */}
                    <div className="flex items-center justify-between mt-3 pt-2 border-t border-stone-100">
                      <div className="flex items-center gap-2">
                        <div className="flex items-center border border-[#E2D5C7] rounded-lg overflow-hidden bg-[#FAF7F2]">
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="p-1 hover:bg-[#EAE0D4] text-[#361F13] transition-colors"
                            aria-label="Decrease quantity"
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <span className="px-2 text-xs font-bold text-[#361F13] font-mono tabular-nums">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="p-1 hover:bg-[#EAE0D4] text-[#361F13] transition-colors"
                            aria-label="Increase quantity"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {baseProduct && (
                          <button
                            onClick={() => toggleWishlist(baseProduct)}
                            className={`p-1.5 text-xs rounded-lg transition-colors ${
                              isWishlisted
                                ? 'text-rose-600 bg-rose-50'
                                : 'text-stone-400 hover:text-stone-700'
                            }`}
                            title="Save to wishlist"
                          >
                            <Heart className={`w-3.5 h-3.5 ${isWishlisted ? 'fill-current' : ''}`} />
                          </button>
                        )}
                      </div>

                      <span className="text-sm font-bold text-[#361F13] font-mono tabular-nums">
                        {settings.currencySymbol}
                        {item.totalPrice}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer & Calculations */}
        {items.length > 0 && (
          <div className="p-4 sm:p-5 border-t border-[#EBE3D7] bg-[#FAF7F2] space-y-3">
            {/* Coupon Code Section */}
            <div>
              {appliedCoupon ? (
                <div className="flex items-center justify-between p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs">
                  <div className="flex items-center gap-1.5 text-emerald-800">
                    <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>
                      Coupon <strong className="font-bold">{appliedCoupon.code}</strong> applied (-
                      {settings.currencySymbol}
                      {discountAmount})
                    </span>
                  </div>
                  <button
                    onClick={removeCoupon}
                    className="text-stone-400 hover:text-stone-700 text-xs font-semibold px-1"
                  >
                    Remove
                  </button>
                </div>
              ) : (
                <form onSubmit={handleApplyCoupon} className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-3" />
                    <input
                      type="text"
                      placeholder="Coupon Code (e.g. FIRST10, CAKE20)"
                      value={couponInput}
                      onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
                      className="w-full pl-8 pr-3 py-2 bg-white border border-[#E2D5C7] rounded-xl text-xs focus:outline-hidden focus:border-[#8C4E28]"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-3.5 py-2 bg-[#8C4E28] hover:bg-[#6E3C1E] text-white text-xs font-semibold rounded-xl transition-colors"
                  >
                    Apply
                  </button>
                </form>
              )}

              {couponError && (
                <p className="text-[11px] text-rose-600 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{couponError}</span>
                </p>
              )}
            </div>

            {/* Price Calculations */}
            <div className="space-y-1.5 text-xs text-[#523B2D] pt-2 border-t border-[#E8DDD1]">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-mono tabular-nums">
                  {settings.currencySymbol}
                  {subtotal}
                </span>
              </div>

              {discountAmount > 0 && (
                <div className="flex justify-between text-emerald-700 font-medium">
                  <span>Discount</span>
                  <span className="font-mono tabular-nums">
                    -{settings.currencySymbol}
                    {discountAmount}
                  </span>
                </div>
              )}

              <div className="flex justify-between">
                <span>Estimated Delivery Fee</span>
                <span className="font-mono tabular-nums">
                  {deliveryFee === 0 ? (
                    <span className="text-emerald-700 font-semibold">FREE</span>
                  ) : (
                    `${settings.currencySymbol}${deliveryFee}`
                  )}
                </span>
              </div>

              <div className="flex justify-between">
                <span>GST ({settings.taxRatePercent}%)</span>
                <span className="font-mono tabular-nums">
                  {settings.currencySymbol}
                  {taxAmount}
                </span>
              </div>

              <div className="flex justify-between pt-2 border-t border-[#DECFC0] text-base font-bold text-[#361F13]">
                <span>Grand Total</span>
                <span className="font-mono tabular-nums">
                  {settings.currencySymbol}
                  {grandTotal}
                </span>
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-2 pt-2">
              <button
                onClick={() => {
                  closeCartDrawer();
                  onProceedToCheckout();
                }}
                className="w-full py-3 bg-[#361F13] hover:bg-[#22120A] text-white text-sm font-semibold rounded-xl flex items-center justify-center gap-2 shadow-md transition-colors"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  closeCartDrawer();
                  onContinueShopping();
                }}
                className="w-full py-2 text-xs font-semibold text-[#8C4E28] hover:text-[#361F13] transition-colors"
              >
                Continue Shopping
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

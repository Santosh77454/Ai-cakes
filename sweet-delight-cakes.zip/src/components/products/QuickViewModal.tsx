import React, { useState } from 'react';
import { Product, WeightOption, FlavorOption } from '../../types';
import { useShop } from '../../context/ShopContext';
import { useCart } from '../../context/CartContext';
import { WEIGHT_PRICE_MULTIPLIERS } from '../../config/shopConfig';
import { SafeImage } from '../common/SafeImage';
import { X, Star, ShoppingBag, ArrowRight } from 'lucide-react';

interface QuickViewModalProps {
  product: Product | null;
  onClose: () => void;
  onViewFullDetails: (productId: string) => void;
}

export const QuickViewModal: React.FC<QuickViewModalProps> = ({
  product,
  onClose,
  onViewFullDetails,
}) => {
  const { settings } = useShop();
  const { addToCart } = useCart();

  const [selectedWeight, setSelectedWeight] = useState<WeightOption>('500g');
  const [selectedFlavor, setSelectedFlavor] = useState<FlavorOption>('Chocolate');
  const [isEggless, setIsEggless] = useState<boolean>(true);
  const [activeImageIndex, setActiveImageIndex] = useState(0);

  // Sync defaults when product changes
  React.useEffect(() => {
    if (product) {
      setSelectedWeight(product.defaultWeight || '500g');
      setSelectedFlavor(product.defaultFlavor || product.flavors[0] || 'Chocolate');
      setIsEggless(product.eggless);
      setActiveImageIndex(0);
    }
  }, [product]);

  if (!product) return null;

  const multiplier = WEIGHT_PRICE_MULTIPLIERS[selectedWeight] || 1;
  const baseDiscounted = Math.round(
    product.basePrice * (1 - (product.discountPercent || 0) / 100)
  );
  const calculatedPrice = Math.round(baseDiscounted * multiplier);

  const handleAddToCart = () => {
    addToCart({
      productId: product.id,
      name: product.name,
      image: product.images[activeImageIndex] || product.images[0],
      weight: selectedWeight,
      flavor: selectedFlavor,
      eggless: isEggless,
      selectedAddOns: [],
      unitPrice: calculatedPrice,
      quantity: 1,
    });
    onClose();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200"
    >
      <div className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl border border-[#EBE3D7] overflow-hidden flex flex-col md:flex-row max-h-[90vh] relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close modal"
          className="absolute top-3 right-3 z-10 w-9 h-9 rounded-full bg-white/80 hover:bg-white text-stone-600 flex items-center justify-center shadow-md transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Left: Gallery */}
        <div className="md:w-1/2 p-6 bg-[#FAF7F2] flex flex-col justify-between">
          <div className="aspect-square rounded-2xl overflow-hidden bg-white shadow-xs border border-[#EFE5D9]">
            <SafeImage
              src={product.images[activeImageIndex] || product.images[0]}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>

          {product.images.length > 1 && (
            <div className="flex gap-2 mt-4 overflow-x-auto pb-1">
              {product.images.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setActiveImageIndex(i)}
                  className={`w-14 h-14 rounded-xl overflow-hidden shrink-0 border-2 transition-all ${
                    activeImageIndex === i ? 'border-[#8C4E28] scale-105' : 'border-transparent opacity-70'
                  }`}
                >
                  <SafeImage src={img} alt="Thumbnail" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right: Details & Options */}
        <div className="md:w-1/2 p-6 overflow-y-auto flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs text-[#8C4E28] mb-1 font-semibold uppercase tracking-wider">
              <span>{product.category}</span>
              <span>·</span>
              <span>{isEggless ? '100% Eggless' : 'With Egg'}</span>
            </div>

            <h2 className="font-serif text-2xl font-bold text-[#361F13]">{product.name}</h2>

            <div className="flex items-center gap-2 mt-2 text-xs text-stone-500">
              <div className="flex items-center gap-0.5 text-amber-500">
                <Star className="w-4 h-4 fill-current" />
                <span className="font-bold text-stone-800">{product.rating.toFixed(1)}</span>
              </div>
              <span>·</span>
              <span>{product.reviewCount} customer reviews</span>
            </div>

            <p className="text-xs text-[#715848] mt-3 line-clamp-3 leading-relaxed">
              {product.description}
            </p>

            {/* Price Preview */}
            <div className="mt-4 p-3 rounded-xl bg-[#FAF7F2] border border-[#EFE5D9] flex items-baseline gap-2">
              <span className="font-mono text-2xl font-bold text-[#361F13]">
                {settings.currencySymbol}
                {calculatedPrice}
              </span>
              {product.discountPercent > 0 && (
                <span className="text-xs text-stone-400 line-through font-mono">
                  {settings.currencySymbol}
                  {Math.round(product.basePrice * multiplier)}
                </span>
              )}
              <span className="text-xs text-[#8C4E28] font-medium">({selectedWeight})</span>
            </div>

            {/* Weight Selector */}
            <div className="mt-4">
              <label className="text-xs font-semibold text-[#361F13] block mb-1.5">
                Select Cake Size:
              </label>
              <div className="flex flex-wrap gap-2">
                {product.weights.map((wt) => (
                  <button
                    key={wt}
                    onClick={() => setSelectedWeight(wt)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                      selectedWeight === wt
                        ? 'bg-[#361F13] text-white border-[#361F13]'
                        : 'bg-white text-stone-700 border-stone-200 hover:border-stone-400'
                    }`}
                  >
                    {wt}
                  </button>
                ))}
              </div>
            </div>

            {/* Flavor Selector */}
            <div className="mt-3">
              <label className="text-xs font-semibold text-[#361F13] block mb-1.5">
                Choose Flavor:
              </label>
              <div className="flex flex-wrap gap-1.5">
                {product.flavors.map((flv) => (
                  <button
                    key={flv}
                    onClick={() => setSelectedFlavor(flv)}
                    className={`px-2.5 py-1 rounded-md text-xs font-medium border transition-colors ${
                      selectedFlavor === flv
                        ? 'bg-[#8C4E28] text-white border-[#8C4E28]'
                        : 'bg-[#FAF7F2] text-stone-700 border-stone-200 hover:border-stone-400'
                    }`}
                  >
                    {flv}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Bottom Actions */}
          <div className="mt-6 pt-4 border-t border-[#F2EAE0] flex flex-col gap-2">
            <button
              onClick={handleAddToCart}
              className="w-full py-3 bg-[#361F13] hover:bg-[#22120A] text-white text-sm font-semibold rounded-xl flex items-center justify-center gap-2 shadow-md transition-colors"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Add to Cart ({settings.currencySymbol}{calculatedPrice})</span>
            </button>

            <button
              onClick={() => {
                onClose();
                onViewFullDetails(product.id);
              }}
              className="w-full py-2 text-xs font-semibold text-[#8C4E28] hover:text-[#361F13] flex items-center justify-center gap-1 transition-colors"
            >
              <span>View Full Customization Options</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

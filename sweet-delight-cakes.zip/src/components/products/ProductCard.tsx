import React from 'react';
import { Product } from '../../types';
import { useShop } from '../../context/ShopContext';
import { useWishlist } from '../../context/WishlistContext';
import { useCart } from '../../context/CartContext';
import { SafeImage } from '../common/SafeImage';
import { Heart, Star, ShoppingBag, Eye } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onOpenDetails: (productId: string) => void;
  onOpenQuickView?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onOpenDetails,
  onOpenQuickView,
}) => {
  const { settings } = useShop();
  const { isInWishlist, toggleWishlist } = useWishlist();
  const { addToCart } = useCart();

  const isLiked = isInWishlist(product.id);
  const discountedPrice = Math.round(
    product.basePrice * (1 - (product.discountPercent || 0) / 100)
  );

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart({
      productId: product.id,
      name: product.name,
      image: product.images[0],
      weight: product.defaultWeight || '500g',
      flavor: product.defaultFlavor || 'Chocolate',
      eggless: product.eggless,
      selectedAddOns: [],
      unitPrice: discountedPrice,
      quantity: 1,
    });
  };

  const handleWishlistClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleWishlist(product);
  };

  const handleQuickViewClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onOpenQuickView) {
      onOpenQuickView(product);
    } else {
      onOpenDetails(product.id);
    }
  };

  return (
    <div
      onClick={() => onOpenDetails(product.id)}
      className="group bg-white rounded-2xl border border-[#EDE3D6] overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col cursor-pointer"
    >
      {/* Visual Image Container (65%-70% focus) */}
      <div className="relative aspect-4/3 sm:aspect-square bg-[#FBF9F6] overflow-hidden">
        <SafeImage
          src={product.images[0]}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />

        {/* Floating Top Badges (Subtle & clean) */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 items-start">
          {product.bestseller && (
            <span className="bg-[#361F13] text-[#FAF7F2] text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-sm shadow-xs">
              Bestseller
            </span>
          )}
          {product.newArrival && !product.bestseller && (
            <span className="bg-[#8C4E28] text-white text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-sm shadow-xs">
              New
            </span>
          )}
          {product.discountPercent > 0 && (
            <span className="bg-[#C2872A] text-white text-[10px] font-bold px-1.5 py-0.5 rounded-sm">
              {product.discountPercent}% OFF
            </span>
          )}
        </div>

        {/* Top-Right Action Buttons */}
        <div className="absolute top-2.5 right-2.5 flex flex-col gap-1.5">
          <button
            onClick={handleWishlistClick}
            aria-label={isLiked ? 'Remove from wishlist' : 'Add to wishlist'}
            className={`w-8 h-8 rounded-full flex items-center justify-center backdrop-blur-xs transition-colors shadow-xs ${
              isLiked
                ? 'bg-rose-50 text-rose-600'
                : 'bg-white/90 text-stone-600 hover:text-rose-600 hover:bg-white'
            }`}
          >
            <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
          </button>

          <button
            onClick={handleQuickViewClick}
            aria-label="Quick preview"
            className="w-8 h-8 rounded-full bg-white/90 hover:bg-white text-stone-600 hover:text-[#361F13] flex items-center justify-center backdrop-blur-xs transition-colors shadow-xs opacity-0 group-hover:opacity-100 hidden sm:flex"
          >
            <Eye className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Add Overlay on Hover */}
        <div className="absolute bottom-2.5 left-2.5 right-2.5 opacity-0 group-hover:opacity-100 transition-opacity duration-200 hidden sm:block">
          <button
            onClick={handleQuickAdd}
            className="w-full py-2 bg-[#361F13]/90 hover:bg-[#22120A] text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 backdrop-blur-xs shadow-md transition-colors"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Quick Add (500g)</span>
          </button>
        </div>
      </div>

      {/* Content Metadata */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Category & Diet Label */}
          <div className="flex items-center justify-between text-xs text-[#8C4E28] mb-1">
            <span className="uppercase tracking-wider text-[11px] font-semibold truncate max-w-[140px]">
              {product.category}
            </span>
            {product.eggless ? (
              <span className="text-[11px] text-emerald-700 flex items-center gap-1 font-medium">
                <span className="w-2 h-2 rounded-full bg-emerald-600 inline-block"></span>
                Eggless
              </span>
            ) : (
              <span className="text-[11px] text-amber-800 flex items-center gap-1 font-medium">
                <span className="w-2 h-2 rounded-full bg-amber-700 inline-block"></span>
                With Egg
              </span>
            )}
          </div>

          {/* Product Name */}
          <h3 className="font-serif text-base font-bold text-[#361F13] group-hover:text-[#8C4E28] transition-colors line-clamp-1">
            {product.name}
          </h3>

          {/* Rating */}
          <div className="flex items-center gap-1.5 mt-1.5 text-xs text-stone-500">
            <div className="flex items-center gap-0.5 text-amber-500">
              <Star className="w-3.5 h-3.5 fill-current" />
              <span className="font-semibold text-stone-800">{product.rating.toFixed(1)}</span>
            </div>
            <span>·</span>
            <span>{product.reviewCount} reviews</span>
          </div>
        </div>

        {/* Pricing & Mobile Quick Add */}
        <div className="mt-3 pt-3 border-t border-[#F2EAE0] flex items-center justify-between">
          <div className="flex items-baseline gap-1.5">
            <span className="text-base font-bold text-[#2D1B11] font-mono tabular-nums">
              {settings.currencySymbol}
              {discountedPrice}
            </span>
            {product.discountPercent > 0 && (
              <span className="text-xs text-stone-400 line-through font-mono tabular-nums">
                {settings.currencySymbol}
                {product.basePrice}
              </span>
            )}
            <span className="text-[10px] text-stone-400">/ 500g</span>
          </div>

          <button
            onClick={handleQuickAdd}
            className="sm:hidden p-2 rounded-lg bg-[#361F13] text-white active:scale-95 transition-transform"
            aria-label="Add to cart"
          >
            <ShoppingBag className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

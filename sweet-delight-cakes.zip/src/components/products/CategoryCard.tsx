import React from 'react';
import { Category } from '../../types';
import { SafeImage } from '../common/SafeImage';
import { ArrowUpRight } from 'lucide-react';

interface CategoryCardProps {
  category: Category;
  onClick: (categoryName: string) => void;
}

export const CategoryCard: React.FC<CategoryCardProps> = ({ category, onClick }) => {
  return (
    <div
      onClick={() => onClick(category.name)}
      className="group relative rounded-2xl overflow-hidden cursor-pointer bg-white border border-[#EBE3D7] hover:border-[#8C4E28] hover:shadow-lg transition-all duration-300 flex flex-col"
    >
      <div className="relative aspect-4/3 overflow-hidden bg-stone-100">
        <SafeImage
          src={category.image}
          alt={category.name}
          className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />

        <div className="absolute bottom-3 left-3 right-3 text-white flex items-end justify-between">
          <div>
            <h4 className="font-serif text-base font-bold tracking-tight drop-shadow-xs">
              {category.name}
            </h4>
            <span className="text-[11px] text-white/80 font-medium">
              {category.productCount} varieties
            </span>
          </div>

          <div className="w-7 h-7 rounded-full bg-white/20 backdrop-blur-xs flex items-center justify-center group-hover:bg-white group-hover:text-[#361F13] text-white transition-colors shadow-xs">
            <ArrowUpRight className="w-3.5 h-3.5" />
          </div>
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { WeightOption } from '../../types';
import { X, RotateCcw, Star, Check } from 'lucide-react';

export interface FilterState {
  category: string;
  flavor: string;
  dietary: 'all' | 'eggless' | 'egg';
  priceRange: 'all' | 'under500' | '500-750' | '750-1000' | 'above1000';
  minRating: number;
  weight: string;
}

interface FilterSidebarProps {
  filters: FilterState;
  onChange: (updated: Partial<FilterState>) => void;
  onClear: () => void;
  categoriesList: string[];
  flavorsList: string[];
  isMobileDrawer?: boolean;
  onCloseMobileDrawer?: () => void;
}

export const FilterSidebar: React.FC<FilterSidebarProps> = ({
  filters,
  onChange,
  onClear,
  categoriesList,
  flavorsList,
  isMobileDrawer,
  onCloseMobileDrawer,
}) => {
  const weights: WeightOption[] = ['500g', '1kg', '1.5kg', '2kg', '3kg'];

  const content = (
    <div className="space-y-6 text-sm">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-[#EBE3D7]">
        <h3 className="font-serif text-lg font-bold text-[#361F13]">Filters</h3>
        <button
          onClick={onClear}
          className="text-xs font-semibold text-[#8C4E28] hover:text-[#361F13] flex items-center gap-1 transition-colors"
        >
          <RotateCcw className="w-3 h-3" />
          <span>Clear All</span>
        </button>
      </div>

      {/* Dietary Preference (Egg / Eggless) */}
      <div>
        <span className="text-xs font-semibold uppercase tracking-wider text-[#8C4E28] block mb-2">
          Dietary Preference
        </span>
        <div className="grid grid-cols-3 gap-1.5 p-1 bg-[#FAF7F2] rounded-xl border border-[#E9DFD3]">
          <button
            onClick={() => onChange({ dietary: 'all' })}
            className={`py-1.5 text-xs font-medium rounded-lg transition-colors ${
              filters.dietary === 'all'
                ? 'bg-[#361F13] text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            All
          </button>
          <button
            onClick={() => onChange({ dietary: 'eggless' })}
            className={`py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center justify-center gap-1 ${
              filters.dietary === 'eggless'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-emerald-800 hover:text-emerald-950'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            Eggless
          </button>
          <button
            onClick={() => onChange({ dietary: 'egg' })}
            className={`py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center justify-center gap-1 ${
              filters.dietary === 'egg'
                ? 'bg-amber-800 text-white shadow-xs'
                : 'text-amber-800 hover:text-amber-950'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
            With Egg
          </button>
        </div>
      </div>

      {/* Category Filter */}
      <div>
        <span className="text-xs font-semibold uppercase tracking-wider text-[#8C4E28] block mb-2">
          Category
        </span>
        <div className="space-y-1 max-h-48 overflow-y-auto pr-1">
          <button
            onClick={() => onChange({ category: 'all' })}
            className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center justify-between transition-colors ${
              filters.category === 'all'
                ? 'bg-[#361F13] text-white'
                : 'text-stone-700 hover:bg-[#FAF7F2]'
            }`}
          >
            <span>All Categories</span>
            {filters.category === 'all' && <Check className="w-3.5 h-3.5" />}
          </button>

          {categoriesList.map((cat) => (
            <button
              key={cat}
              onClick={() => onChange({ category: cat })}
              className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center justify-between transition-colors ${
                filters.category === cat
                  ? 'bg-[#361F13] text-white'
                  : 'text-stone-700 hover:bg-[#FAF7F2]'
              }`}
            >
              <span className="truncate">{cat}</span>
              {filters.category === cat && <Check className="w-3.5 h-3.5" />}
            </button>
          ))}
        </div>
      </div>

      {/* Flavor Filter */}
      <div>
        <span className="text-xs font-semibold uppercase tracking-wider text-[#8C4E28] block mb-2">
          Flavor
        </span>
        <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto">
          <button
            onClick={() => onChange({ flavor: 'all' })}
            className={`px-2.5 py-1 rounded-md text-xs font-medium border transition-colors ${
              filters.flavor === 'all'
                ? 'bg-[#8C4E28] text-white border-[#8C4E28]'
                : 'bg-white text-stone-700 border-stone-200 hover:border-stone-400'
            }`}
          >
            All Flavors
          </button>
          {flavorsList.map((flv) => (
            <button
              key={flv}
              onClick={() => onChange({ flavor: flv })}
              className={`px-2.5 py-1 rounded-md text-xs font-medium border transition-colors ${
                filters.flavor === flv
                  ? 'bg-[#8C4E28] text-white border-[#8C4E28]'
                  : 'bg-white text-stone-700 border-stone-200 hover:border-stone-400'
              }`}
            >
              {flv}
            </button>
          ))}
        </div>
      </div>

      {/* Price Range */}
      <div>
        <span className="text-xs font-semibold uppercase tracking-wider text-[#8C4E28] block mb-2">
          Price (500g Base)
        </span>
        <div className="space-y-1 text-xs">
          {[
            { id: 'all', label: 'All Prices' },
            { id: 'under500', label: 'Under ₹500' },
            { id: '500-750', label: '₹500 – ₹750' },
            { id: '750-1000', label: '₹750 – ₹1,000' },
            { id: 'above1000', label: 'Above ₹1,000' },
          ].map((item) => (
            <label
              key={item.id}
              className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-[#FAF7F2] cursor-pointer"
            >
              <input
                type="radio"
                name="priceRange"
                checked={filters.priceRange === item.id}
                onChange={() => onChange({ priceRange: item.id as FilterState['priceRange'] })}
                className="text-[#8C4E28] focus:ring-[#8C4E28]"
              />
              <span className="text-stone-700">{item.label}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Weight Filter */}
      <div>
        <span className="text-xs font-semibold uppercase tracking-wider text-[#8C4E28] block mb-2">
          Available Size
        </span>
        <div className="flex flex-wrap gap-1.5">
          <button
            onClick={() => onChange({ weight: 'all' })}
            className={`px-2.5 py-1 rounded-md text-xs font-medium border ${
              filters.weight === 'all'
                ? 'bg-[#361F13] text-white border-[#361F13]'
                : 'bg-white text-stone-700 border-stone-200 hover:border-stone-400'
            }`}
          >
            All Sizes
          </button>
          {weights.map((wt) => (
            <button
              key={wt}
              onClick={() => onChange({ weight: wt })}
              className={`px-2.5 py-1 rounded-md text-xs font-medium border ${
                filters.weight === wt
                  ? 'bg-[#361F13] text-white border-[#361F13]'
                  : 'bg-white text-stone-700 border-stone-200 hover:border-stone-400'
              }`}
            >
              {wt}
            </button>
          ))}
        </div>
      </div>

      {/* Customer Rating Filter */}
      <div>
        <span className="text-xs font-semibold uppercase tracking-wider text-[#8C4E28] block mb-2">
          Rating
        </span>
        <div className="space-y-1 text-xs">
          <button
            onClick={() => onChange({ minRating: 0 })}
            className={`w-full text-left px-2 py-1.5 rounded-md flex items-center justify-between ${
              filters.minRating === 0 ? 'bg-[#FAF7F2] font-semibold text-[#8C4E28]' : 'text-stone-700'
            }`}
          >
            <span>All Ratings</span>
          </button>
          <button
            onClick={() => onChange({ minRating: 4 })}
            className={`w-full text-left px-2 py-1.5 rounded-md flex items-center gap-1.5 ${
              filters.minRating === 4 ? 'bg-[#FAF7F2] font-semibold text-[#8C4E28]' : 'text-stone-700'
            }`}
          >
            <div className="flex text-amber-500">
              <Star className="w-3.5 h-3.5 fill-current" />
              <Star className="w-3.5 h-3.5 fill-current" />
              <Star className="w-3.5 h-3.5 fill-current" />
              <Star className="w-3.5 h-3.5 fill-current" />
            </div>
            <span>4★ and above</span>
          </button>
          <button
            onClick={() => onChange({ minRating: 3 })}
            className={`w-full text-left px-2 py-1.5 rounded-md flex items-center gap-1.5 ${
              filters.minRating === 3 ? 'bg-[#FAF7F2] font-semibold text-[#8C4E28]' : 'text-stone-700'
            }`}
          >
            <div className="flex text-amber-500">
              <Star className="w-3.5 h-3.5 fill-current" />
              <Star className="w-3.5 h-3.5 fill-current" />
              <Star className="w-3.5 h-3.5 fill-current" />
            </div>
            <span>3★ and above</span>
          </button>
        </div>
      </div>
    </div>
  );

  if (isMobileDrawer) {
    return (
      <div
        role="dialog"
        aria-modal="true"
        className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex justify-end animate-in fade-in"
      >
        <div className="w-full max-w-xs bg-white h-full p-5 overflow-y-auto flex flex-col justify-between shadow-2xl animate-in slide-in-from-right">
          <div>
            <div className="flex justify-between items-center mb-4">
              <span className="font-serif text-lg font-bold text-[#361F13]">Filter Cakes</span>
              <button
                onClick={onCloseMobileDrawer}
                className="p-1 rounded-lg hover:bg-stone-100 text-stone-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            {content}
          </div>
          <div className="pt-4 border-t border-stone-200 mt-6">
            <button
              onClick={onCloseMobileDrawer}
              className="w-full py-2.5 bg-[#361F13] text-white text-xs font-semibold rounded-xl"
            >
              Apply Filters
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <aside className="w-64 shrink-0 bg-white p-5 rounded-2xl border border-[#EBE3D7] shadow-xs sticky top-24 self-start">
      {content}
    </aside>
  );
};
